#include "chibicc.h"

#define GP_MAX 6
#define FP_MAX 8

static FILE *output_file;
static FILE *output_file1;

#define vmmvi 0
#define vmmov 1
#define vmadd 2
#define vmsub 3
#define vmand 4
#define vmior 5
#define vmnot 6
#define vmldm 7
#define vmstm 8
#define vmshl 9
#define vmshr 10
#define vmcmp 11
#define vmjmp 12
#define vmbrn 13
#define vmtgl 14
#define vmsys 15

#define vmr0 0
#define vmr1 1
#define vmr2 2
#define vmr3 3
#define vmip 4
#define vmsp 5
#define vmfp 6
#define vmtp 7
#define vmr8 8
#define vmr9 9
#define vmr10 10
#define vmr11 11
#define vmr12 12
#define vmr13 13
#define vmr14 14
#define vmr15 15

#define vmmvil 0
#define vmmvih 1
#define vmdmvi 2
#define vmzero 3

#define vmajmp 0
#define vmrjmp 1
#define vmcall 2
#define vmret 3

#define vmebrn 0
#define vmqbrn 1
#define vmpbrn 2
#define vmnbrn 3

unsigned short encodeA(unsigned char Opcode, unsigned char rX, unsigned char rY, unsigned char inm)
{
  return ( (( (Opcode & 0x0f) << 4) | ((rX & 0x03) << 2) | (rY & 0x03) ) << 8) | inm;
}
unsigned short encodeB(unsigned char Opcode, unsigned char rX, unsigned char rY)
{
  return (((Opcode & 0x0f) << 12) | ((rX & 0xf) << 4) | (rY & 0xf));
}

int ecc = 0;

int elkc = 0;
unsigned short elkp[128] = {0};
char *elks[128] = {NULL};

int efnc = 0;
unsigned short efnp[128] = {0};
char *efns[128] = {NULL};

void emitCode(unsigned short instruction)
{
  // if(opt_S)
  // return;
  unsigned short ins = __builtin_bswap16(instruction);
  //printf("0x%04X: 0x%04X\n", ecc, instruction);
  fwrite(&ins, sizeof(unsigned short), 1, output_file1);
  ecc += 2;
}

static int depth;
static char *argreg8[] = {"2:r9", "2:r12", "2:r8", "2:r13", "2:r10", "2:r11"};
static char *argreg16[] = {"2:r9", "2:r12", "2:r8", "2:r13", "2:r10", "2:r11"};
static char *argreg32[] = {"2:r9", "2:r12", "2:r8", "2:r13", "2:r10", "2:r11"};
static char *argreg64[] = {"2:r9", "2:r12", "2:r8", "2:r13", "2:r10", "2:r11"};
static Obj *current_fn;

static void gen_expr(Node *node);
static void gen_stmt(Node *node);

__attribute__((format(printf, 1, 2))) static void println(char *fmt, ...)
{
  va_list ap;
  va_start(ap, fmt);
  vfprintf(output_file, fmt, ap);
  va_end(ap);
  fprintf(output_file, "\n");
}

static int count(void)
{
  static int i = 1;
  return i++;
}

static void push(void)
{
  emitCode(encodeB(vmmov, vmr15, vmr3));
  println("  mov r15, r3");

  emitCode(encodeB(vmmov, vmr2, vmsp));
  emitCode(encodeA(vmstm, vmr2, vmr3, 0));
  println("  stm [2$sp], r3");
  emitCode(encodeA(vmshr, vmr3, vmr0, 8));
  println("  shr r3, r0+8");
  emitCode(encodeA(vmstm, vmr2, vmr3, -1));
  println("  stm [r2+-1], r3");
  emitCode(encodeA(vmsub, vmr2, vmr0, 2));
  emitCode(encodeB(vmmov, vmsp, vmr2));
  println("  sub sp@2, r0+2");

  emitCode(encodeB(vmmov, vmr3, vmr15));
  println("  mov r3, r15");
  depth++;
}

static void pop(int reg)
{
  emitCode(encodeB(vmmov, vmr11, reg));
  println("  mov r15, r%d", reg);

  emitCode(encodeB(vmmov, vmr2, vmsp));
  emitCode(encodeA(vmldm, vmr2, reg, 0));
  println("  ldm [2$sp], r%d", reg);
  emitCode(encodeA(vmshl, reg, vmr0, 8));
  println("  shl r%d, r0+8", reg);
  emitCode(encodeA(vmldm, vmr2, reg, 1));
  println("  ldm [r2+1], r%d", reg);
  emitCode(encodeA(vmadd, vmr2, vmr0, 2));
  emitCode(encodeB(vmmov, vmsp, vmr2));
  println("  add sp@2, r0+2");

  emitCode(encodeB(vmmov, reg, vmr15));
  println("  mov r%d, r15", reg);
  depth--;
}

static void pushf(void)
{
  depth++;
}

static void popf(int reg)
{
  depth--;
}

// Round up `n` to the nearest multiple of `align`. For instance,
// align_to(5, 8) returns 8 and align_to(11, 8) returns 16.
int align_to(int n, int align)
{
  return (n + align - 1) / align * align;
}

static char *reg_dx(int sz)
{
  switch (sz)
  {
  case 2:
    return "2:r8";
  }
  unreachable();
}

static char *reg_ax(int sz)
{
  switch (sz)
  {
  case 2:
    return "r3";
  }
  unreachable();
}

// Compute the absolute address of a given node.
// It's an error if a given node does not reside in memory.
static void gen_addr(Node *node)
{
  switch (node->kind)
  {
  case ND_VAR:
    // Variable-length array, which is always local.
    emitCode(encodeB(vmmov, vmr1, vmfp));
    println("  mov r1, fp");
    if (node->var->ty->kind == TY_VLA)
    {
      emitCode(encodeA(vmldm, vmr1, vmr3, node->var->offset));
      println("  ldm [r1+%d], r3", node->var->offset);
      emitCode(encodeA(vmshr, vmr3, vmr0, 8));
      println("  shr r3, r0+8");
      emitCode(encodeA(vmldm, vmr1, vmr3, node->var->offset + 1));
      println("  ldm [r1+%d], r3", node->var->offset + 1);
      return;
    }

    // Local variable
    if (node->var->is_local)
    {
      emitCode(encodeB(vmldm, vmr3, vmfp));
      emitCode(encodeA(vmadd, vmr3, vmr0, node->var->offset));
      println("  add 3$fp, r0+%d", node->var->offset);
      return;
    }

    if (opt_fpic)
    {
      // Thread-local variable
      if (node->var->is_tls)
      {
        println("  ;!!!data16 lea %s@tlsgd(%%rip), %%rdi", node->var->name);
        println("  ;!!!.value 0x6666");
        println("  ;!!!rex64");
        println("  ;!!!call __tls_get_addr@PLT");
        return;
      }

      // Function or global variable
      println("  ;!!!mov %s@GOTPCREL(%%rip), %%rax", node->var->name);
      return;
    }

    // Thread-local variable
    if (node->var->is_tls)
    {
      println("  ;!!!mov %%fs:0, %%rax");
      println("  ;!!!add $%s@tpoff, %%rax", node->var->name);
      return;
    }

    // Here, we generate an absolute address of a function or a global
    // variable. Even though they exist at a certain address at runtime,
    // their addresses are not known at link-time for the following
    // two reasons.
    //
    //  - Address randomization: Executables are loaded to memory as a
    //    whole but it is not known what address they are loaded to.
    //    Therefore, at link-time, relative address in the same
    //    exectuable (i.e. the distance between two functions in the
    //    same executable) is known, but the absolute address is not
    //    known.
    //
    //  - Dynamic linking: Dynamic shared objects (DSOs) or .so files
    //    are loaded to memory alongside an executable at runtime and
    //    linked by the runtime loader in memory. We know nothing
    //    about addresses of global stuff that may be defined by DSOs
    //    until the runtime relocation is complete.
    //
    // In order to deal with the former case, we use RIP-relative
    // addressing, denoted by `(%rip)`. For the latter, we obtain an
    // address of a stuff that may be in a shared object file from the
    // Global Offset Table using `@GOTPCREL(%rip)` notation.

    // Function
    if (node->ty->kind == TY_FUNC)
    {
      if (node->var->is_definition)
      {
        elkp[elkc++] = ecc;
        emitCode(encodeA(vmmvi, vmmvil, vmr3, 0));
        emitCode(encodeA(vmmvi, vmmvih, vmr3, 0)); // <:TOLINK:>
        println("  mvi r3, #%s", node->var->name);
        elks[elkc - 1] = node->var->name;
      }
      else
        println("  ;!!!mov %s@GOTPCREL(%%rip), %%rax", node->var->name);
      return;
    }

    // Global variable
    elkp[elkc++] = ecc;
    emitCode(encodeA(vmmvi, vmmvil, vmr3, 0));
    emitCode(encodeA(vmmvi, vmmvih, vmr3, 0)); // <:TOLINK:>
    println("  mvi r3, #%s", node->var->name);
    elks[elkc - 1] = node->var->name;
    return;
  case ND_DEREF:
    gen_expr(node->lhs);
    return;
  case ND_COMMA:
    gen_expr(node->lhs);
    gen_addr(node->rhs);
    return;
  case ND_MEMBER:
    gen_addr(node->lhs);
    emitCode(encodeA(vmadd, vmr3, vmr0, node->member->offset));
    println("  add r3, r0+%d", node->member->offset);
    return;
  case ND_FUNCALL:
    if (node->ret_buffer)
    {
      gen_expr(node);
      return;
    }
    break;
  case ND_ASSIGN:
  case ND_COND:
    if (node->ty->kind == TY_STRUCT || node->ty->kind == TY_UNION)
    {
      gen_expr(node);
      return;
    }
    break;
  case ND_VLA_PTR:
    emitCode(encodeB(vmmov, vmr3, vmfp));
    println("  mov r3, fp");
    emitCode(encodeA(vmadd, vmr3, vmr0, node->var->offset));
    println("  add r3, r0+%d", node->var->offset);
    return;
  }

  error_tok(node->tok, "not an lvalue");
}

// Load a value from where %rax is pointing to.
static void load(Type *ty)
{
  switch (ty->kind)
  {
  case TY_ARRAY:
  case TY_STRUCT:
  case TY_UNION:
  case TY_FUNC:
  case TY_VLA:
    // If it is an array, do not attempt to load a value to the
    // register because in general we can't load an entire array to a
    // register. As a result, the result of an evaluation of an array
    // becomes not the array itself but the address of the array.
    // This is where "array is automatically converted to a pointer to
    // the first element of the array in C" occurs.
    return;
  case TY_FLOAT:
    return;
  case TY_DOUBLE:
    return;
  case TY_LDOUBLE:
    return;
  }

  // When we load a char or a short value to a register, we always
  // extend them to the size of int, so we can assume the lower half of
  // a register always contains a valid value. The upper half of a
  // register for char, short and int may contain garbage. When we load
  // a long value to a register, it simply occupies the entire register.
  if (ty->size == 1)
  {
    emitCode(encodeA(vmldm, vmr3, vmr3, 0));
    println("  ldm [r3], r3");
  }
  else
  {
    emitCode(encodeB(vmmov, vmr1, vmr3));
    println("  mov r1, r3");
    emitCode(encodeA(vmldm, vmr1, vmr3, 0));
    println("  ldm [r1], r3");
    emitCode(encodeA(vmshr, vmr3, vmr0, 8));
    println("  shr r3, r0+8");
    emitCode(encodeA(vmldm, vmr1, vmr3, 1));
    println("  ldm [r1+1], r3");
  }
}

// Store %rax to an address that the stack top is pointing to.
static void store(Type *ty)
{
  pop(2);

  switch (ty->kind)
  {
  case TY_STRUCT:
  case TY_UNION:
    for (int i = 0; i < ty->size; i++)
    {
      emitCode(encodeA(vmldm, vmr3, vmr1, i));
      println("  ldm [r3+%d], r1", i);
      emitCode(encodeA(vmstm, vmr2, vmr1, i));
      println("  stm [r2+%d], r1", i);
    }
    return;
  case TY_FLOAT:
    return;
  case TY_DOUBLE:
    return;
  case TY_LDOUBLE:
    return;
  }

  if (ty->size == 1)
  {
    emitCode(encodeA(vmstm, vmr2, vmr3, 0));
    println("  stm [r2], r3");
  }
  else
  {
    emitCode(encodeB(vmstm, vmr1, vmr3));
    println("  mov r1, r3");
    emitCode(encodeA(vmshr, vmr1, vmr0, 8));
    println("  shr r1, r0+8");
    emitCode(encodeA(vmstm, vmr2, vmr1, 0));
    println("  stm [r2], r1");
    emitCode(encodeA(vmstm, vmr2, vmr3, 1));
    println("  stm [r2+1], r3");
  }
}

static void cmp_zero(Type *ty)
{
  switch (ty->kind)
  {
  case TY_FLOAT:
    return;
  case TY_DOUBLE:
    return;
  case TY_LDOUBLE:
    return;
  }

  if (is_integer(ty))
  {
    emitCode(encodeA(vmcmp, vmr0, vmr3, 0));
    println("  cmp r0, r3");
  }
}

enum
{
  I8,
  I16,
  I32,
  I64,
  U8,
  U16,
  U32,
  U64,
  F32,
  F64,
  F80
};

static int getTypeId(Type *ty)
{
  switch (ty->kind)
  {
  case TY_CHAR:
    return ty->is_unsigned ? U8 : I8;
  case TY_SHORT:
    return ty->is_unsigned ? U16 : I16;
  case TY_INT:
    return ty->is_unsigned ? U32 : I32;
  case TY_LONG:
    return ty->is_unsigned ? U64 : I64;
  case TY_FLOAT:
    return F32;
  case TY_DOUBLE:
    return F64;
  case TY_LDOUBLE:
    return F80;
  }
  return U64;
}

// The table for type casts
static char i32i8[] = "and r3, r0+256";
static char i32u8[] = "and r3, r0+256";
static char i32i16[] = "";
static char i32u16[] = "";
static char i32f32[] = "";
static char i32i64[] = "";
static char i32f64[] = "";
static char i32f80[] = "";

static char u32f32[] = "";
static char u32i64[] = "";
static char u32f64[] = "";
static char u32f80[] = "";

static char i64f32[] = "";
static char i64f64[] = "";
static char i64f80[] = "";

static char u64f32[] = "";
static char u64f64[] = "";
static char u64f80[] = "";

static char f32i8[] = "";
static char f32u8[] = "";
static char f32i16[] = "";
static char f32u16[] = "";
static char f32i32[] = "";
static char f32u32[] = "";
static char f32i64[] = "";
static char f32u64[] = "";
static char f32f64[] = "";
static char f32f80[] = "";

static char f64i8[] = "";
static char f64u8[] = "";
static char f64i16[] = "";
static char f64u16[] = "";
static char f64i32[] = "";
static char f64u32[] = "";
static char f64i64[] = "";
static char f64u64[] = "";
static char f64f32[] = "";
static char f64f80[] = "";

#define FROM_F80_1 ""

#define FROM_F80_2 ""

static char f80i8[] = "";
static char f80u8[] = "";
static char f80i16[] = "";
static char f80u16[] = "";
static char f80i32[] = "";
static char f80u32[] = "";
static char f80i64[] = "";
static char f80u64[] = "";
static char f80f32[] = "";
static char f80f64[] = "";

static char *cast_table[][11] = {
    // i8   i16     i32     i64     u8     u16     u32     u64     f32     f64     f80
    {NULL, NULL, NULL, i32i64, i32u8, i32u16, NULL, i32i64, i32f32, i32f64, i32f80},    // i8
    {i32i8, NULL, NULL, i32i64, i32u8, i32u16, NULL, i32i64, i32f32, i32f64, i32f80},   // i16
    {i32i8, i32i16, NULL, i32i64, i32u8, i32u16, NULL, i32i64, i32f32, i32f64, i32f80}, // i32
    {i32i8, i32i16, NULL, NULL, i32u8, i32u16, NULL, NULL, i64f32, i64f64, i64f80},     // i64

    {i32i8, NULL, NULL, i32i64, NULL, NULL, NULL, i32i64, i32f32, i32f64, i32f80},      // u8
    {i32i8, i32i16, NULL, i32i64, i32u8, NULL, NULL, i32i64, i32f32, i32f64, i32f80},   // u16
    {i32i8, i32i16, NULL, u32i64, i32u8, i32u16, NULL, u32i64, u32f32, u32f64, u32f80}, // u32
    {i32i8, i32i16, NULL, NULL, i32u8, i32u16, NULL, NULL, u64f32, u64f64, u64f80},     // u64

    {f32i8, f32i16, f32i32, f32i64, f32u8, f32u16, f32u32, f32u64, NULL, f32f64, f32f80}, // f32
    {f64i8, f64i16, f64i32, f64i64, f64u8, f64u16, f64u32, f64u64, f64f32, NULL, f64f80}, // f64
    {f80i8, f80i16, f80i32, f80i64, f80u8, f80u16, f80u32, f80u64, f80f32, f80f64, NULL}, // f80
};

// The table for type casts
const static short i32i8b = 0x4CFF;
const static short i32u8b = 0x4CFF;
const static short i32i16b = 0x0C00;
const static short i32u16b = 0x0C00;
const static short i32f32b = 0x0C00;
const static short i32i64b = 0x0C00;
const static short i32f64b = 0x0C00;
const static short i32f80b = 0x0C00;

const static short u32f32b = 0x0C00;
const static short u32i64b = 0x0C00;
const static short u32f64b = 0x0C00;
const static short u32f80b = 0x0C00;

const static short i64f32b = 0x0C00;
const static short i64f64b = 0x0C00;
const static short i64f80b = 0x0C00;

const static short u64f32b = 0x0C00;
const static short u64f64b = 0x0C00;
const static short u64f80b = 0x0C00;

const static short f32i8b = 0x0C00;
const static short f32u8b = 0x0C00;
const static short f32i16b = 0x0C00;
const static short f32u16b = 0x0C00;
const static short f32i32b = 0x0C00;
const static short f32u32b = 0x0C00;
const static short f32i64b = 0x0C00;
const static short f32u64b = 0x0C00;
const static short f32f64b = 0x0C00;
const static short f32f80b = 0x0C00;

const static short f64i8b = 0x0C00;
const static short f64u8b = 0x0C00;
const static short f64i16b = 0x0C00;
const static short f64u16b = 0x0C00;
const static short f64i32b = 0x0C00;
const static short f64u32b = 0x0C00;
const static short f64i64b = 0x0C00;
const static short f64u64b = 0x0C00;
const static short f64f32b = 0x0C00;
const static short f64f80b = 0x0C00;

#define FROM_F80_1 0x0C00

#define FROM_F80_2 0x0C00

const static short f80i8b = 0x0C00;
const static short f80u8b = 0x0C00;
const static short f80i16b = 0x0C00;
const static short f80u16b = 0x0C00;
const static short f80i32b = 0x0C00;
const static short f80u32b = 0x0C00;
const static short f80i64b = 0x0C00;
const static short f80u64b = 0x0C00;
const static short f80f32b = 0x0C00;
const static short f80f64b = 0x0C00;

const static short *cast_tableb[][11] = {
    // i8   i16     i32     i64     u8     u16     u32     u64     f32     f64     f80
    {NULL, NULL, NULL, i32i64b, i32u8b, i32u16b, NULL, i32i64b, i32f32b, i32f64b, i32f80b},      // i8
    {i32i8b, NULL, NULL, i32i64b, i32u8b, i32u16b, NULL, i32i64b, i32f32b, i32f64b, i32f80b},    // i16
    {i32i8b, i32i16b, NULL, i32i64b, i32u8b, i32u16b, NULL, i32i64b, i32f32b, i32f64b, i32f80b}, // i32
    {i32i8b, i32i16b, NULL, NULL, i32u8b, i32u16b, NULL, NULL, i64f32b, i64f64b, i64f80b},       // i64

    {i32i8b, NULL, NULL, i32i64b, NULL, NULL, NULL, i32i64b, i32f32b, i32f64b, i32f80b},         // u8
    {i32i8b, i32i16b, NULL, i32i64b, i32u8b, NULL, NULL, i32i64b, i32f32b, i32f64b, i32f80b},    // u16
    {i32i8b, i32i16b, NULL, u32i64b, i32u8b, i32u16b, NULL, u32i64b, u32f32b, u32f64b, u32f80b}, // u32
    {i32i8b, i32i16b, NULL, NULL, i32u8b, i32u16b, NULL, NULL, u64f32b, u64f64b, u64f80b},       // u64

    {f32i8b, f32i16b, f32i32b, f32i64b, f32u8b, f32u16b, f32u32b, f32u64b, NULL, f32f64b, f32f80b}, // f32
    {f64i8b, f64i16b, f64i32b, f64i64b, f64u8b, f64u16b, f64u32b, f64u64b, f64f32b, NULL, f64f80b}, // f64
    {f80i8b, f80i16b, f80i32b, f80i64b, f80u8b, f80u16b, f80u32b, f80u64b, f80f32b, f80f64b, NULL}, // f80
};

static void cast(Type *from, Type *to)
{
  if (to->kind == TY_VOID)
    return;

  if (to->kind == TY_BOOL)
  {
    cmp_zero(from);
    emitCode(encodeA(vmmvi, vmmvil, vmr1, 0xFE));
    emitCode(encodeA(vmmvi, vmmvih, vmr1, 0x00));
    println("  mvi r1, 0xFE");
    emitCode(encodeA(vmsys, vmr1, vmr3, 0));
    println("  sys r1, r3");
    emitCode(encodeA(vmand, vmr3, vmr0, 1));
    println("  and r3, r0+1");
    emitCode(encodeA(vmsub, vmr3, vmr0, 1));
    println("  sub r3, r0+1");
    emitCode(encodeA(vmnot, vmr3, vmr0, 0));
    println("  not r3");
    return;
  }

  int t1 = getTypeId(from);
  int t2 = getTypeId(to);
  if (cast_table[t1][t2])
  {
    emitCode(cast_tableb[t1][t2]);
    println("  %s", cast_table[t1][t2]);
  }
}

// Structs or unions equal or smaller than 16 bytes are passed
// using up to two registers.
//
// If the first 8 bytes contains only floating-point type members,
// they are passed in an XMM register. Otherwise, they are passed
// in a general-purpose register.
//
// If a struct/union is larger than 8 bytes, the same rule is
// applied to the the next 8 byte chunk.
//
// This function returns true if `ty` has only floating-point
// members in its byte range [lo, hi).
static bool has_flonum(Type *ty, int lo, int hi, int offset)
{
  if (ty->kind == TY_STRUCT || ty->kind == TY_UNION)
  {
    for (Member *mem = ty->members; mem; mem = mem->next)
      if (!has_flonum(mem->ty, lo, hi, offset + mem->offset))
        return false;
    return true;
  }

  if (ty->kind == TY_ARRAY)
  {
    for (int i = 0; i < ty->array_len; i++)
      if (!has_flonum(ty->base, lo, hi, offset + ty->base->size * i))
        return false;
    return true;
  }

  return offset < lo || hi <= offset || ty->kind == TY_FLOAT || ty->kind == TY_DOUBLE;
}

static bool has_flonum1(Type *ty)
{
  return has_flonum(ty, 0, 8, 0);
}

static bool has_flonum2(Type *ty)
{
  return has_flonum(ty, 8, 16, 0);
}

static void push_struct(Type *ty)
{
  int sz = align_to(ty->size, 8);
  emitCode(encodeB(vmmov, vmr1, vmsp));
  println("  mov r1, sp");
  emitCode(encodeA(vmsub, vmr1, vmr0, sz));
  println("  sub r1, r0+%d", sz);
  emitCode(encodeB(vmmov, vmsp, vmr1));
  println("  mov sp, r1");
  depth += sz / 8;

  emitCode(encodeB(vmmov, vmr1, vmsp));
  println("  mov r1, sp");
  for (int i = 0; i < ty->size; i++)
  {
    emitCode(encodeA(vmldm, vmr3, vmr2, i));
    println("  ldm [r3+%d], r2", i);
    emitCode(encodeA(vmstm, vmr1, vmr2, i));
    println("  stm [r1+%d], r2", i);
  }
}

static void push_args2(Node *args, bool first_pass)
{
  if (!args)
    return;
  push_args2(args->next, first_pass);

  if ((first_pass && !args->pass_by_stack) || (!first_pass && args->pass_by_stack))
    return;

  gen_expr(args);

  switch (args->ty->kind)
  {
  case TY_STRUCT:
  case TY_UNION:
    push_struct(args->ty);
    break;
  case TY_FLOAT:
  case TY_DOUBLE:
    pushf();
    break;
  case TY_LDOUBLE:
    depth += 2;
    break;
  default:
    push();
  }
}

// Load function call arguments. Arguments are already evaluated and
// stored to the stack as local variables. What we need to do in this
// function is to load them to registers or push them to the stack as
// specified by the x86-64 psABI. Here is what the spec says:
//
// - Up to 6 arguments of integral type are passed using RDI, RSI,
//   RDX, RCX, R8 and R9.
//
// - Up to 8 arguments of floating-point type are passed using XMM0 to
//   XMM7.
//
// - If all registers of an appropriate type are already used, push an
//   argument to the stack in the right-to-left order.
//
// - Each argument passed on the stack takes 8 bytes, and the end of
//   the argument area must be aligned to a 16 byte boundary.
//
// - If a function is variadic, set the number of floating-point type
//   arguments to RAX.
static int push_args(Node *node)
{
  int stack = 0, gp = 0, fp = 0;

  // If the return type is a large struct/union, the caller passes
  // a pointer to a buffer as if it were the first argument.
  if (node->ret_buffer && node->ty->size > 16)
    gp++;

  // Load as many arguments to the registers as possible.
  for (Node *arg = node->args; arg; arg = arg->next)
  {
    Type *ty = arg->ty;

    switch (ty->kind)
    {
    case TY_STRUCT:
    case TY_UNION:
      if (ty->size > 16)
      {
        arg->pass_by_stack = true;
        stack += align_to(ty->size, 8) / 8;
      }
      else
      {
        bool fp1 = has_flonum1(ty);
        bool fp2 = has_flonum2(ty);

        if (fp + fp1 + fp2 < FP_MAX && gp + !fp1 + !fp2 < GP_MAX)
        {
          fp = fp + fp1 + fp2;
          gp = gp + !fp1 + !fp2;
        }
        else
        {
          arg->pass_by_stack = true;
          stack += align_to(ty->size, 8) / 8;
        }
      }
      break;
    case TY_FLOAT:
    case TY_DOUBLE:
      if (fp++ >= FP_MAX)
      {
        arg->pass_by_stack = true;
        stack++;
      }
      break;
    case TY_LDOUBLE:
      arg->pass_by_stack = true;
      stack += 2;
      break;
    default:
      if (gp++ >= GP_MAX)
      {
        arg->pass_by_stack = true;
        stack++;
      }
    }
  }

  if ((depth + stack) % 2 == 1)
  {
    emitCode(encodeB(vmmov, vmr1, vmsp));
    println("  mov r1, sp");
    emitCode(encodeA(vmsub, vmr1, vmr0, 8));
    println("  sub r1, r0+8");
    emitCode(encodeB(vmmov, vmsp, vmr1));
    println("  mov sp, r1");
    depth++;
    stack++;
  }

  push_args2(node->args, true);
  push_args2(node->args, false);

  // If the return type is a large struct/union, the caller passes
  // a pointer to a buffer as if it were the first argument.
  if (node->ret_buffer && node->ty->size > 16)
  {
    emitCode(encodeB(vmmov, vmr3, vmr2));
    println("  mov r3, r2");
    emitCode(encodeA(vmadd, vmr3, vmr0, node->ret_buffer->offset));
    println("  add r3, r0+%d", node->ret_buffer->offset);
    push();
  }

  return stack;
}

static void copy_ret_buffer(Obj *var)
{
  Type *ty = var->ty;
  int gp = 0, fp = 0;

  if (has_flonum1(ty))
  {
    assert(ty->size == 4 || 8 <= ty->size);
    // if (ty->size == 4)
    //   println("  movss %%xmm0, %d(%%rbp)", var->offset);
    // else
    //   println("  movsd %%xmm0, %d(%%rbp)", var->offset);
    fp++;
  }
  else
  {
    for (int i = 0; i < MIN(8, ty->size); i++)
    {
      emitCode(encodeA(vmstm, vmr1, vmr3, var->offset + i));
      println("  stm [r1+%d], r3", var->offset + i);
      emitCode(encodeA(vmshr, vmr3, vmr0, 8));
      println("  shr r3, r0+8");
    }
    gp++;
  }

  if (ty->size > 8)
  {
    if (has_flonum2(ty))
    {
      assert(ty->size == 12 || ty->size == 16);
      // if (ty->size == 12)
      //   println("  movss %%xmm%d, %d(%%rbp)", fp, var->offset + 8);
      // else
      //   println("  movsd %%xmm%d, %d(%%rbp)", fp, var->offset + 8);
    }
    else
    {
      char *reg1 = (gp == 0) ? "r3" : "r2";
      char *reg2 = (gp == 0) ? "r3" : "r2";
      char reg1b = (gp == 0) ? vmr3 : vmr2;
      char reg2b = (gp == 0) ? vmr3 : vmr2;

      emitCode(encodeB(vmmov, vmr1, vmfp));
      println("  mov r1, fp");
      for (int i = 8; i < MIN(16, ty->size); i++)
      {
        emitCode(encodeA(vmldm, vmr1, reg1b, var->offset + i));
        println("  ldm [r1+%d], %s", var->offset + i, reg1);
        emitCode(encodeA(vmshr, reg2b, vmr0, 8));
        println("  shr %s, r0+8", reg2);
      }
    }
  }
}

static void copy_struct_reg(void)
{
  Type *ty = current_fn->ty->return_ty;
  int gp = 0, fp = 0;
  emitCode(encodeB(vmmov, vmr3, vmr2));
  println("  mov r3, r2");

  if (has_flonum(ty, 0, 8, 0))
  {
    assert(ty->size == 4 || 8 <= ty->size);
    // if (ty->size == 4)
    //   println("  movss (%%rdi), %%xmm0");
    // else
    //   println("  movsd (%%rdi), %%xmm0");
    fp++;
  }
  else
  {
    emitCode(encodeA(vmmvi, vmzero, vmr3, 0));
    println("  zero r3");
    for (int i = MIN(8, ty->size) - 1; i >= 0; i--)
    {
      emitCode(encodeA(vmshl, vmr3, vmr0, 8));
      println("  shl r3, r0+8");
      emitCode(encodeA(vmldm, vmr2, vmr3, i));
      println("  ldm [r2+%d], r3", i);
    }
    gp++;
  }

  if (ty->size > 8)
  {
    if (has_flonum(ty, 8, 16, 0))
    {
      assert(ty->size == 12 || ty->size == 16);
      // if (ty->size == 4)
      //   println("  movss 8(%%rdi), %%xmm%d", fp);
      // else
      //   println("  movsd 8(%%rdi), %%xmm%d", fp);
    }
    else
    {
      char *reg1 = (gp == 0) ? "r3" : "r2";
      char *reg2 = (gp == 0) ? "r3" : "r2";
      char reg1b = (gp == 0) ? vmr3 : vmr2;
      char reg2b = (gp == 0) ? vmr3 : vmr2;

      emitCode(encodeA(vmmvi, vmzero, reg2b, 0));
      println("  zero %s", reg2);
      for (int i = MIN(16, ty->size) - 1; i >= 8; i--)
      {
        emitCode(encodeA(vmshl, reg2b, vmr0, 8));
        println("  shl %s, r0+8", reg2);
        emitCode(encodeA(vmldm, vmr2, reg1b, i));
        println("  ldm [r2+%d], %s", i, reg1);
      }
    }
  }
}

static void copy_struct_mem(void)
{
  Type *ty = current_fn->ty->return_ty;
  Obj *var = current_fn->params;

  emitCode(encodeB(vmmov, vmr1, vmfp));
  println("  mov r1, fp");
  emitCode(encodeA(vmldm, vmr1, vmr2, var->offset));
  println("  ldm [r1+%d], r2", var->offset);

  for (int i = 0; i < ty->size; i++)
  {
    emitCode(encodeA(vmldm, vmr3, vmr0, i));
    println("  ldm [r3+%d], r<---", i);
    emitCode(encodeA(vmstm, vmr2, vmr0, i));
    println("  stm [r2+%d], r<---", i);
  }
}

static void builtin_alloca(void)
{
  // Align size to 16 bytes.
  emitCode(encodeA(vmadd, vmr2, vmr0, 0x0f));
  println("  add r2, r0+15");
  emitCode(encodeA(vmmvi, vmmvil, vmr1, 0xf0));
  emitCode(encodeA(vmmvi, vmmvih, vmr1, 0xff));
  println("  mvi r1, 0xfff0");
  emitCode(encodeA(vmand, vmr2, vmr1, 0));
  println("  and r2, r1");

  // Shift the temporary area by %rdi.
  println("  mov %d(%%rbp), %%rcx", current_fn->alloca_bottom->offset);
  println("  sub %%rsp, %%rcx");
  println("  mov %%rsp, %%rax");
  println("  sub %%rdi, %%rsp");
  println("  mov %%rsp, %%rdx");
  println("1:");
  println("  cmp $0, %%rcx");
  println("  je 2f");
  println("  mov (%%rax), %%r8b");
  println("  mov %%r8b, (%%rdx)");
  println("  inc %%rdx");
  println("  inc %%rax");
  println("  dec %%rcx");
  println("  jmp 1b");
  println("2:");

  // Move alloca_bottom pointer.
  emitCode(encodeB(vmmov, vmr2, vmfp));
  emitCode(encodeA(vmstm, vmr2, vmr3, current_fn->alloca_bottom->offset));
  println("  mov [2$fp+%d], r3", current_fn->alloca_bottom->offset);
  emitCode(encodeB(vmmov, vmr2, vmr9));
  emitCode(encodeA(vmsub, vmr2, vmr3, 0));
  emitCode(encodeB(vmmov, vmr2, vmr9));
  println("  sub 2:r9, r3");
  emitCode(encodeA(vmstm, vmr2, vmr3, current_fn->alloca_bottom->offset));
  emitCode(encodeB(vmmov, vmr2, vmfp));
  println("  stm [2$fp+%d], r3", current_fn->alloca_bottom->offset);
}

// Generate code for a given node.
static void gen_expr(Node *node)
{
  // println("  .loc %d %d", node->tok->file->file_no, node->tok->line_no);

  switch (node->kind)
  {
  case ND_NULL_EXPR:
    return;
  case ND_NUM:
  {
    switch (node->ty->kind)
    {
    case TY_FLOAT:
    {
      union
      {
        float f32;
        uint32_t u32;
      } u = {node->fval};
      // println("  mov $%u, %%eax  # float %Lf", u.u32, node->fval);
      // println("  movq %%rax, %%xmm0");
      return;
    }
    case TY_DOUBLE:
    {
      union
      {
        double f64;
        uint64_t u64;
      } u = {node->fval};
      // println("  mov $%lu, %%rax  # double %Lf", u.u64, node->fval);
      // println("  movq %%rax, %%xmm0");
      return;
    }
    case TY_LDOUBLE:
    {
      union
      {
        long double f80;
        uint64_t u64[2];
      } u;
      memset(&u, 0, sizeof(u));
      u.f80 = node->fval;
      // println("  mov $%lu, %%rax  # long double %Lf", u.u64[0], node->fval);
      // println("  mov %%rax, -16(%%rsp)");
      // println("  mov $%lu, %%rax", u.u64[1]);
      // println("  mov %%rax, -8(%%rsp)");
      // println("  fldt -16(%%rsp)");
      return;
    }
    }

    emitCode(encodeA(vmmvi, vmmvil, vmr3, (unsigned char)node->val));
    emitCode(encodeA(vmmvi, vmmvih, vmr3, (unsigned char)(node->val >> 8)));
    println("  mvi r3, %ld", node->val);
    return;
  }
  case ND_NEG:
    gen_expr(node->lhs);

    switch (node->ty->kind)
    {
    case TY_FLOAT:
      // println("  mov $1, %%rax");
      // println("  shl $31, %%rax");
      // println("  movq %%rax, %%xmm1");
      // println("  xorps %%xmm1, %%xmm0");
      return;
    case TY_DOUBLE:
      // println("  mov $1, %%rax");
      // println("  shl $63, %%rax");
      // println("  movq %%rax, %%xmm1");
      // println("  xorpd %%xmm1, %%xmm0");
      return;
    case TY_LDOUBLE:
      // println("  fchs");
      return;
    }

    emitCode(encodeA(vmnot, vmr3, vmr0, 0));
    println("  not r3");
    return;
  case ND_VAR:
    gen_addr(node);
    load(node->ty);
    return;
  case ND_MEMBER:
  {
    gen_addr(node);
    load(node->ty);

    Member *mem = node->member;
    if (mem->is_bitfield)
    {
      emitCode(encodeA(vmshl, vmr3, vmr0, 64 - mem->bit_width - mem->bit_offset));
      println("  shl r3, r0+%d", 64 - mem->bit_width - mem->bit_offset);
      if (mem->ty->is_unsigned)
      {
        emitCode(encodeA(vmshr, vmr3, vmr0, mem->bit_width));
        println("  shr r3, r0+%d", 64 - mem->bit_width);
      }
      else
      {
        emitCode(encodeA(vmshr, vmr3, vmr0, 64 - mem->bit_width));
        println("  shr r3, r0+%d", 64 - mem->bit_width);
      }
    }
    return;
  }
  case ND_DEREF:
    gen_expr(node->lhs);
    load(node->ty);
    return;
  case ND_ADDR:
    gen_addr(node->lhs);
    return;
  case ND_ASSIGN:
    gen_addr(node->lhs);
    push();
    gen_expr(node->rhs);

    if (node->lhs->kind == ND_MEMBER && node->lhs->member->is_bitfield)
    {
      emitCode(encodeB(vmmov, vmr10, vmr3));
      println("  mov r10, r3");

      // If the lhs is a bitfield, we need to read the current value
      // from memory and merge it with a new value.
      Member *mem = node->lhs->member;
      emitCode(encodeB(vmmov, vmr9, vmr3));
      println("  mov r9, r3");
      emitCode(encodeB(vmmov, vmr2, vmr9));
      emitCode(encodeA(vmand, vmr2, vmr0, (1L << mem->bit_width) - 1));
      println("  and 2$r9, r0+%ld", (1L << mem->bit_width) - 1);
      emitCode(encodeA(vmshl, vmr2, vmr0, mem->bit_offset));
      emitCode(encodeB(vmmov, vmr9, vmr2));
      println("  shl r9@2, r0+%d", mem->bit_offset);

      emitCode(encodeB(vmmov, vmr2, vmsp));
      emitCode(encodeA(vmldm, vmr2, vmr3, 0));
      println("  ldm [2$sp], r3");
      load(mem->ty);

      long mask = ((1L << mem->bit_width) - 1) << mem->bit_offset;
      emitCode(encodeA(vmmvi, vmmvil, vmr2, ~mask));
      emitCode(encodeA(vmmvi, vmmvih, vmr2, (~mask)>>8));
      emitCode(encodeB(vmmov, vmr12, vmr2));
      println("  mvi r12@2, %ld", ~mask);
      emitCode(encodeB(vmmov, vmr2, vmr12));
      emitCode(encodeA(vmand, vmr2, vmr3, 0));
      emitCode(encodeB(vmmov, vmr12, vmr2));
      println("  and 2:r12, r3");
      emitCode(encodeB(vmmov, vmr2, vmr9));
      emitCode(encodeA(vmior, vmr2, vmr3, 0));
      emitCode(encodeB(vmmov, vmr9, vmr2));
      println("  ior 2:r9, r3");
      store(node->ty);
      emitCode(encodeB(vmmov, vmr3, vmr10));
      println("  mov r3, r10");
      return;
    }

    store(node->ty);
    return;
  case ND_STMT_EXPR:
    for (Node *n = node->body; n; n = n->next)
      gen_stmt(n);
    return;
  case ND_COMMA:
    gen_expr(node->lhs);
    gen_expr(node->rhs);
    return;
  case ND_CAST:
    gen_expr(node->lhs);
    cast(node->lhs->ty, node->ty);
    return;
  case ND_MEMZERO:
    // `rep stosb` is equivalent to `memset(%rdi, %al, %rcx)`.
    println("  mvi r13@2 %d", node->var->ty->size);
    println("  add 2:fp+%d 1:r9", node->var->offset);
    println("  shr r3, r0+8");
    println("  shl r3, r0+8");
    println("  call 1$rep_stosb");
    return;
  case ND_COND:
  {
    int c = count();
    gen_expr(node->cond);
    cmp_zero(node->cond->ty);
    println("  ebrn 1$.L.else.%d", c);
    gen_expr(node->then);
    println("  jmp 1$.L.end.%d", c);
    println(".L.else.%d:", c);
    gen_expr(node->els);
    println(".L.end.%d:", c);
    return;
  }
  case ND_NOT:
    gen_expr(node->lhs);
    cmp_zero(node->lhs->ty);
    println("  sete %%al<---");
    println("  and r3, r0+255");
    return;
  case ND_BITNOT:
    gen_expr(node->lhs);
    println("  not r3");
    return;
  case ND_LOGAND:
  {
    int c = count();
    gen_expr(node->lhs);
    cmp_zero(node->lhs->ty);
    println("  ebrn 1$.L.false.%d", c);
    gen_expr(node->rhs);
    cmp_zero(node->rhs->ty);
    println("  ebrn 1$.L.false.%d", c);
    println("  mvi r3, 1");
    println("  jmp 1$.L.end.%d", c);
    println(".L.false.%d:", c);
    println("  zero r3");
    println(".L.end.%d:", c);
    return;
  }
  case ND_LOGOR:
  {
    int c = count();
    gen_expr(node->lhs);
    cmp_zero(node->lhs->ty);
    println("  qbrn 1$.L.true.%d", c);
    gen_expr(node->rhs);
    cmp_zero(node->rhs->ty);
    println("  qbrn 1$.L.true.%d", c);
    println("  zero r3");
    println("  jmp 1$.L.end.%d", c);
    println(".L.true.%d:", c);
    println("  mvi r3, 1");
    println(".L.end.%d:", c);
    return;
  }
  case ND_FUNCALL:
  {
    if (node->lhs->kind == ND_VAR && !strcmp(node->lhs->var->name, "alloca"))
    {
      gen_expr(node->args);
      println("  mov r3, r9");
      builtin_alloca();
      return;
    }

    int stack_args = push_args(node);
    gen_expr(node->lhs);

    int gp = 0, fp = 0;

    // If the return type is a large struct/union, the caller passes
    // a pointer to a buffer as if it were the first argument.
    if (node->ret_buffer && node->ty->size > 16)
      pop(argreg64[gp++]);

    for (Node *arg = node->args; arg; arg = arg->next)
    {
      Type *ty = arg->ty;

      switch (ty->kind)
      {
      case TY_STRUCT:
      case TY_UNION:
        if (ty->size > 16)
          continue;

        bool fp1 = has_flonum1(ty);
        bool fp2 = has_flonum2(ty);

        if (fp + fp1 + fp2 < FP_MAX && gp + !fp1 + !fp2 < GP_MAX)
        {
          if (fp1)
            popf(fp++);
          else
            pop(argreg64[gp++]);

          if (ty->size > 8)
          {
            if (fp2)
              popf(fp++);
            else
              pop(argreg64[gp++]);
          }
        }
        break;
      case TY_FLOAT:
      case TY_DOUBLE:
        if (fp < FP_MAX)
          popf(fp++);
        break;
      case TY_LDOUBLE:
        break;
      default:
        if (gp < GP_MAX)
          pop(argreg64[gp++]);
      }
    }

    println("  mov r13, r3");
    println("  mvi r3, %d", fp);
    println("  call 2$r13");
    println("  add 2:sp, r0+%d", stack_args * 8);

    depth -= stack_args;

    // It looks like the most significant 48 or 56 bits in RAX may
    // contain garbage if a function return type is short or bool/char,
    // respectively. We clear the upper bits here.
    switch (node->ty->kind)
    {
    case TY_BOOL:
      println("  and r3, r0+255");
      return;
    case TY_CHAR:
      if (node->ty->is_unsigned)
        println("  and r3, r0+255");
      else
        println("  and r3, r0+255");
      return;
    case TY_SHORT:
      if (node->ty->is_unsigned)
        ;
      else
        ;
      return;
    }

    // If the return type is a small struct, a value is returned
    // using up to two registers.
    if (node->ret_buffer && node->ty->size <= 16)
    {
      copy_ret_buffer(node->ret_buffer);
      println("  add 3$fp, r0+%d", node->ret_buffer->offset);
    }

    return;
  }
  case ND_LABEL_VAL:
    println("  add 3$ip, r0+%d", node->unique_label);
    return;
  case ND_CAS:
  {
    gen_expr(node->cas_addr);
    push();
    gen_expr(node->cas_new);
    push();
    gen_expr(node->cas_old);
    println("  mov %%rax, %%r8");
    load(node->cas_old->ty->base);
    pop("%rdx"); // new
    pop("%rdi"); // addr

    int sz = node->cas_addr->ty->base->size;
    println("  lock cmpxchg %s, (%%rdi)", reg_dx(sz));
    println("  sete %%cl");
    println("  je 1f");
    println("  mov %s, (%%r8)", reg_ax(sz));
    println("1:");
    println("  movzbl %%cl, %%eax");
    return;
  }
  case ND_EXCH:
  {
    gen_expr(node->lhs);
    push();
    gen_expr(node->rhs);
    pop("r");

    int sz = node->lhs->ty->base->size;
    println("  xchg %s, (%%rdi)<---", reg_ax(sz));
    return;
  }
  }

  switch (node->lhs->ty->kind)
  {
  case TY_FLOAT:
  case TY_DOUBLE:
  {
    gen_expr(node->rhs);
    pushf();
    gen_expr(node->lhs);
    popf(1);

    char *sz = (node->lhs->ty->kind == TY_FLOAT) ? "ss" : "sd";

    switch (node->kind)
    {
    case ND_ADD:
      return;
    case ND_SUB:
      return;
    case ND_MUL:
      return;
    case ND_DIV:
      return;
    case ND_EQ:
    case ND_NE:
    case ND_LT:
    case ND_LE:
      return;
      println("  ucomi%s %%xmm0, %%xmm1", sz);

      if (node->kind == ND_EQ)
      {
        println("  sete %%al");
        println("  setnp %%dl");
        println("  and %%dl, %%al");
      }
      else if (node->kind == ND_NE)
      {
        println("  setne %%al");
        println("  setp %%dl");
        println("  or %%dl, %%al");
      }
      else if (node->kind == ND_LT)
      {
        println("  seta %%al");
      }
      else
      {
        println("  setae %%al");
      }

      println("  and $1, %%al");
      println("  movzb %%al, %%rax");
      return;
    }

    error_tok(node->tok, "invalid expression");
  }
  case TY_LDOUBLE:
  {
    gen_expr(node->lhs);
    gen_expr(node->rhs);

    switch (node->kind)
    {
    case ND_ADD:
      return;
    case ND_SUB:
      return;
    case ND_MUL:
      return;
    case ND_DIV:
      return;
    case ND_EQ:
    case ND_NE:
    case ND_LT:
    case ND_LE:
      return;

      println("  fcomip<---");
      println("  fstp %%st(0)<---");

      if (node->kind == ND_EQ)
        println("  sete %%al<---");
      else if (node->kind == ND_NE)
        println("  setne %%al<---");
      else if (node->kind == ND_LT)
        println("  seta %%al<---");
      else
        println("  setae %%al<---");

      println("  and r3, r0+255");
      return;
    }

    error_tok(node->tok, "invalid expression");
  }
  }

  gen_expr(node->rhs);
  push();
  gen_expr(node->lhs);
  pop("r");

  char *ax, *di, *dx;

  if (node->lhs->ty->kind == TY_LONG || node->lhs->ty->base)
  {
    ax = "r3";
    di = "r";
    dx = "r";
  }
  else
  {
    ax = "r3";
    di = "r";
    dx = "r";
  }

  switch (node->kind)
  {
  case ND_ADD:
    println("  add %s, %s", di, ax);
    return;
  case ND_SUB:
    println("  sub %s, %s", di, ax);
    return;
  case ND_MUL:
    println("  imul %s, %s<---", di, ax);
    return;
  case ND_DIV:
  case ND_MOD:
    if (node->ty->is_unsigned)
    {
      println("  zero %s", dx);
      println("  div %s<---", di);
    }
    else
    {
      if (node->lhs->ty->size == 8)
        println("  cqo<---");
      else
        println("  cdq<---");
      println("  idiv %s<---", di);
    }

    if (node->kind == ND_MOD)
      println("  mov r3, r");
    return;
  case ND_BITAND:
    println("  and %s, %s", di, ax);
    return;
  case ND_BITOR:
    println("  ior %s, %s", di, ax);
    return;
  case ND_BITXOR:
    println("  xor %s, %s<---", di, ax);
    return;
  case ND_EQ:
  case ND_NE:
  case ND_LT:
  case ND_LE:
    println("  cmp %s, %s", di, ax);

    if (node->kind == ND_EQ)
    {
      println("  sete %%al<---");
    }
    else if (node->kind == ND_NE)
    {
      println("  setne %%al<---");
    }
    else if (node->kind == ND_LT)
    {
      if (node->lhs->ty->is_unsigned)
        println("  setb %%al<---");
      else
        println("  setl %%al<---");
    }
    else if (node->kind == ND_LE)
    {
      if (node->lhs->ty->is_unsigned)
        println("  setbe %%al<---");
      else
        println("  setle %%al<---");
    }

    println("  and r3, r0+255");
    return;
  case ND_SHL:
    println("  mov r1, r");
    println("  shr %s, r1", ax);
    return;
  case ND_SHR:
    println("  mov r1, r");
    if (node->lhs->ty->is_unsigned)
      println("  shr %s, r1", ax);
    else
      println("  shr %s, r1", ax);
    return;
  }

  error_tok(node->tok, "invalid expression");
}

static void gen_stmt(Node *node)
{
  char *lnss = NULL;
  // println("  .loc %d %d", node->tok->file->file_no, node->tok->line_no);

  switch (node->kind)
  {
  case ND_IF:
  {
    int c = count();
    gen_expr(node->cond);
    cmp_zero(node->cond->ty);
    elkp[elkc++] = ecc;
    emitCode(encodeA(vmmvi, vmmvil, vmr1, 0)); // <:TOLINK:>
    emitCode(encodeA(vmmvi, vmmvih, vmr1, 0));
    emitCode(encodeA(vmbrn, vmebrn, vmr1, 0));
    println("  ebrn 1$.L.else.%d", c);
    lnss = malloc(128);
    sprintf(lnss, ".L.else.%d", c);
    elks[elkc - 1] = lnss;
    gen_stmt(node->then);
    elkp[elkc++] = ecc;
    emitCode(encodeA(vmmvi, vmmvil, vmr1, 0)); // <:TOLINK:>
    emitCode(encodeA(vmmvi, vmmvih, vmr1, 0));
    emitCode(encodeA(vmjmp, vmajmp, vmr1, 0));
    println("  jmp 1$.L.end.%d", c);
    lnss = malloc(128);
    sprintf(lnss, ".L.end.%d", c);
    elks[elkc - 1] = lnss;
    println(".L.else.%d:", c);
    lnss = malloc(128);
    sprintf(lnss, ".L.else.%d", c);
    efnp[efnc++] = ecc;
    efns[efnc - 1] = lnss;
    if (node->els)
      gen_stmt(node->els);
    println(".L.end.%d:", c);
    lnss = malloc(128);
    sprintf(lnss, ".L.end.%d", c);
    efnp[efnc++] = ecc;
    efns[efnc - 1] = lnss;
    return;
  }
  case ND_FOR:
  {
    int c = count();
    if (node->init)
      gen_stmt(node->init);
    println(".L.begin.%d:", c);
    lnss = malloc(128);
    sprintf(lnss, ".L.begin.%d", c);
    efnp[efnc++] = ecc;
    efns[efnc - 1] = lnss;
    if (node->cond)
    {
      gen_expr(node->cond);
      cmp_zero(node->cond->ty);
      elkp[elkc++] = ecc;
      emitCode(encodeA(vmmvi, vmmvil, vmr1, 0)); // <:TOLINK:>
      emitCode(encodeA(vmmvi, vmmvih, vmr1, 0));
      emitCode(encodeA(vmbrn, vmebrn, vmr1, 0));
      println("  ebrn 1$%s", node->brk_label);
      elks[elkc - 1] = node->brk_label;
    }
    gen_stmt(node->then);
    println("%s:", node->cont_label);
    efnp[efnc++] = ecc;
    efns[efnc - 1] = node->cont_label;
    if (node->inc)
      gen_expr(node->inc);
    elkp[elkc++] = ecc;
    emitCode(encodeA(vmmvi, vmmvil, vmr1, 0)); // <:TOLINK:>
    emitCode(encodeA(vmmvi, vmmvih, vmr1, 0));
    emitCode(encodeA(vmjmp, vmajmp, vmr1, 0));
    println("  jmp 1$.L.begin.%d", c);
    lnss = malloc(128);
    sprintf(lnss, ".L.begin.%d", c);
    elks[elkc - 1] = lnss;
    println("%s:", node->brk_label);
    efnp[efnc++] = ecc;
    efns[efnc - 1] = node->brk_label;
    return;
  }
  case ND_DO:
  {
    int c = count();
    println(".L.begin.%d:", c);
    lnss = malloc(128);
    sprintf(lnss, ".L.begin.%d", c);
    efnp[efnc++] = ecc;
    efns[efnc - 1] = lnss;
    gen_stmt(node->then);
    println("%s:", node->cont_label);
    efnp[efnc++] = ecc;
    efns[efnc - 1] = node->cont_label;
    gen_expr(node->cond);
    cmp_zero(node->cond->ty);
    elkp[elkc++] = ecc;
    emitCode(encodeA(vmmvi, vmmvil, vmr1, 0)); // <:TOLINK:>
    emitCode(encodeA(vmmvi, vmmvih, vmr1, 0));
    emitCode(encodeA(vmbrn, vmqbrn, vmr1, 0));
    println("  qbrn 1$.L.begin.%d", c);
    lnss = malloc(128);
    sprintf(lnss, ".L.begin.%d", c);
    elks[elkc - 1] = lnss;
    println("%s:", node->brk_label);
    efnp[efnc++] = ecc;
    efns[efnc - 1] = node->brk_label;
    return;
  }
  case ND_SWITCH:
    gen_expr(node->cond);

    for (Node *n = node->case_next; n; n = n->case_next)
    {
      char *ax = (node->cond->ty->size == 8) ? "r3" : "r3";
      char *di = (node->cond->ty->size == 8) ? "r" : "r";

      if (n->begin == n->end)
      {
        println("  mvi r1, %ld", n->begin);
        println("  cmp r1, %s", ax);
        println("  ebrn 1$%s", n->label);
        continue;
      }

      // [GNU] Case ranges
      println("  mov %s, %s", di, ax);
      println("  sub %s, 1$%ld", di, n->begin);
      println("  cmp %s, 1$%ld", di, n->end - n->begin);
      elkp[elkc++] = ecc;
      emitCode(encodeA(vmmvi, vmmvil, vmr1, 0)); // <:TOLINK:>
      emitCode(encodeA(vmmvi, vmmvih, vmr1, 0));
      emitCode(encodeA(vmjmp, vmajmp, vmr1, 0));
      println("  jbe 1$%s<---", n->label);
      elks[elkc - 1] = n->label;
    }

    if (node->default_case)
    {
      elkp[elkc++] = ecc;
      emitCode(encodeA(vmmvi, vmmvil, vmr1, 0)); // <:TOLINK:>
      emitCode(encodeA(vmmvi, vmmvih, vmr1, 0));
      emitCode(encodeA(vmjmp, vmajmp, vmr1, 0));
      println("  jmp 1$%s", node->default_case->label);
      elks[elkc - 1] = node->default_case->label;
    }

    elkp[elkc++] = ecc;
    emitCode(encodeA(vmmvi, vmmvil, vmr1, 0)); // <:TOLINK:>
    emitCode(encodeA(vmmvi, vmmvih, vmr1, 0));
    emitCode(encodeA(vmjmp, vmajmp, vmr1, 0));
    println("  jmp 1$%s", node->brk_label);
    elks[elkc - 1] = node->brk_label;
    gen_stmt(node->then);
    println("%s:", node->brk_label);
    efnp[efnc++] = ecc;
    efns[efnc - 1] = node->brk_label;
    return;
  case ND_CASE:
    println("%s:", node->label);
    efnp[efnc++] = ecc;
    efns[efnc - 1] = node->label;
    gen_stmt(node->lhs);
    return;
  case ND_BLOCK:
    for (Node *n = node->body; n; n = n->next)
      gen_stmt(n);
    return;
  case ND_GOTO:
    elkp[elkc++] = ecc;
    emitCode(encodeA(vmmvi, vmmvil, vmr1, 0)); // <:TOLINK:>
    emitCode(encodeA(vmmvi, vmmvih, vmr1, 0));
    emitCode(encodeA(vmjmp, vmajmp, vmr1, 0));
    println("  jmp 1$%s", node->unique_label);
    elks[elkc - 1] = node->unique_label;
    return;
  case ND_GOTO_EXPR:
    gen_expr(node->lhs);
    emitCode(encodeA(vmjmp, vmr3, vmr0, 0));
    println("  jmp r3");
    return;
  case ND_LABEL:
    println("%s:", node->unique_label);
    efnp[efnc++] = ecc;
    efns[efnc - 1] = node->unique_label;
    gen_stmt(node->lhs);
    return;
  case ND_RETURN:
    if (node->lhs)
    {
      gen_expr(node->lhs);
      Type *ty = node->lhs->ty;

      switch (ty->kind)
      {
      case TY_STRUCT:
      case TY_UNION:
        if (ty->size <= 16)
          copy_struct_reg();
        else
          copy_struct_mem();
        break;
      }
    }

    elkp[elkc++] = ecc;
    emitCode(encodeA(vmmvi, vmmvil, vmr1, 0)); // <:TOLINK:>
    emitCode(encodeA(vmmvi, vmmvih, vmr1, 0));
    emitCode(encodeA(vmjmp, vmajmp, vmr1, 0));
    println("  jmp 1$.L.return.%s", current_fn->name);
    lnss = malloc(128);
    sprintf(lnss, ".L.return.%s", current_fn->name);
    elks[elkc - 1] = lnss;
    return;
  case ND_EXPR_STMT:
    gen_expr(node->lhs);
    return;
  case ND_ASM:
    println("  %s", node->asm_str);
    return;
  }

  error_tok(node->tok, "invalid statement");
}

// Assign offsets to local variables.
static void assign_lvar_offsets(Obj *prog)
{
  for (Obj *fn = prog; fn; fn = fn->next)
  {
    if (!fn->is_function)
      continue;

    // If a function has many parameters, some parameters are
    // inevitably passed by stack rather than by register.
    // The first passed-by-stack parameter resides at RBP+16.
    int top = 16;
    int bottom = 0;

    int gp = 0, fp = 0;

    // Assign offsets to pass-by-stack parameters.
    for (Obj *var = fn->params; var; var = var->next)
    {
      Type *ty = var->ty;

      switch (ty->kind)
      {
      case TY_STRUCT:
      case TY_UNION:
        if (ty->size <= 16)
        {
          bool fp1 = has_flonum(ty, 0, 8, 0);
          bool fp2 = has_flonum(ty, 8, 16, 8);
          if (fp + fp1 + fp2 < FP_MAX && gp + !fp1 + !fp2 < GP_MAX)
          {
            fp = fp + fp1 + fp2;
            gp = gp + !fp1 + !fp2;
            continue;
          }
        }
        break;
      case TY_FLOAT:
      case TY_DOUBLE:
        if (fp++ < FP_MAX)
          continue;
        break;
      case TY_LDOUBLE:
        break;
      default:
        if (gp++ < GP_MAX)
          continue;
      }

      top = align_to(top, 8);
      var->offset = top;
      top += var->ty->size;
    }

    // Assign offsets to pass-by-register parameters and local variables.
    for (Obj *var = fn->locals; var; var = var->next)
    {
      if (var->offset)
        continue;

      // AMD64 System V ABI has a special alignment rule for an array of
      // length at least 16 bytes. We need to align such array to at least
      // 16-byte boundaries. See p.14 of
      // https://github.com/hjl-tools/x86-psABI/wiki/x86-64-psABI-draft.pdf.
      int align = (var->ty->kind == TY_ARRAY && var->ty->size >= 16)
                      ? MAX(16, var->align)
                      : var->align;

      bottom += var->ty->size;
      bottom = align_to(bottom, align);
      var->offset = -bottom;
    }

    fn->stack_size = align_to(bottom, 16);
  }
}

static void emit_data(Obj *prog)
{
  for (Obj *var = prog; var; var = var->next)
  {
    if (var->is_function || !var->is_definition)
      continue;

    if (var->is_static)
      println("  .local: %s", var->name);
    else
      println("  .global: %s", var->name);

    int align = (var->ty->kind == TY_ARRAY && var->ty->size >= 16)
                    ? MAX(16, var->align)
                    : var->align;

    // Common symbol
    if (opt_fcommon && var->is_tentative)
    {
      println("  .comm %s, %d, %d", var->name, var->ty->size, align);
      continue;
    }

    // .data or .tdata
    if (var->init_data)
    {
      if (0) // var->is_tls)
        ;    // println("  .section .tdata,\"awT\",@progbits");
      else
        println("  .data:");

      println("  .type: %s, @object", var->name);
      println("  .size: %s, %d", var->name, var->ty->size);
      println("  .align: %d", align);
      println("%s:", var->name);

      Relocation *rel = var->rel;
      int pos = 0;
      while (pos < var->ty->size)
      {
        if (rel && rel->offset == pos)
        {
          println("  .quad: %s%+ld", *rel->label, rel->addend);
          rel = rel->next;
          pos += 8;
        }
        else
        {
          println("  .byte: %d", var->init_data[pos++]);
        }
      }
      continue;
    }

    // .bss or .tbss
    if (0) // var->is_tls)
      ;    // println("  .section .tbss,\"awT\",@nobits");
    else
      println("  .bss:");

    println("  .align: %d", align);
    println("%s:", var->name);
    println("  .zero: %d", var->ty->size);
  }
}

static void store_fp(int r, int offset, int sz)
{
  switch (sz)
  {
  }
  unreachable();
}

static void store_gp(int r, int offset, int sz)
{
  switch (sz)
  {
  case 1:
    println("  stm [1$sp+%d], %s", offset, argreg8[r]);
    return;
  case 2:
    println("  stm [1$sp+%d], %s", offset, argreg8[r]);
    println("  mov 2:r8, %s", argreg8[r]);
    println("  shr 2:r8, r0+8");
    println("  stm [r1+%d], %s", offset, argreg8[r]);
    return;
  default:
    println("  mov r1, sp");
    for (int i = 0; i < sz; i++)
    {
      println("  stm [r1+%d], %s", offset + 1, argreg8[r]);
      println("  shr %s, r0+8", argreg64[r]);
    }
    return;
  }
}

static void emit_text(Obj *prog)
{
  emitCode(('Z' << 8) | 'O');
  emitCode(('B' << 8) | 'J');
  emitCode(0);
  emitCode(0);
  emitCode(0);
  emitCode(0);
  emitCode(0x0C00);
  for (Obj *fn = prog; fn; fn = fn->next)
  {
    if (!fn->is_function || !fn->is_definition)
      continue;

    // No code is emitted for "static inline" functions
    // if no one is referencing them.
    if (!fn->is_live)
      continue;

    if (fn->is_static)
      println("  .local %s", fn->name);
    else
      println("  .globl %s", fn->name);

    println("  .text");
    println("  .type %s, @function", fn->name);
    println("%s:", fn->name);
    efnp[efnc++] = ecc;
    efns[efnc - 1] = fn->name;
    current_fn = fn;

    // Prologue
    /*println("  mov r3, fp");
    println("  mov r1, sp");
    println("  stm [r1], r3");
    println("  mov r8, r3");
    println("  shr r3, r0+8");
    println("  stm [r1-1], r3");
    println("  sub r1, r0+1");
    println("  mov sp, r1");
    println("  mov r3, r8");

    println("  mov sp, fp");

    println("  mov r1, sp");
    println("  sub r1, r0+%d", fn->stack_size);
    println("  mov sp, r1");

    println("  mov r2, fp");
    println("  stm [r2+%d], r1", fn->alloca_bottom->offset);
    */

    // Save arg registers if function is variadic
    if (fn->va_area)
    {
      int gp = 0, fp = 0;
      for (Obj *var = fn->params; var; var = var->next)
      {
        if (is_flonum(var->ty))
          fp++;
        else
          gp++;
      }

      int off = fn->va_area->offset;

      // va_elem
      /*println("  mvi r1, 0x%02X", gp * 8);
      println("  stm [r2+%d], r1", off); // gp_offset
      println("  mvi r1, 0x%02X", fp * 8 + 48);
      println("  stm [r2+%d], r1", off + 4); // fp_offset
      println("  stm [r2+%d], r2", off + 8); // overflow_arg_area
      println("  ldm [r2+%d], r1", off + 8);
      println("  add r1, r0+16");
      println("  stm [r2+%d], r2", off + 16); // reg_save_area
      println("  add [r2+%d], r0+%d", off + 16, off + 24);

      // __reg_save_area__
      println("  stm [r2+%d], r1", off + 24);
      println("  stm [r2+%d], r2", off + 32);
      println("  stm [r2+%d], r3", off + 40);
      */
    }

    // Save passed-by-register arguments to the stack
    int gp = 0, fp = 0;
    for (Obj *var = fn->params; var; var = var->next)
    {
      if (var->offset > 0)
        continue;

      Type *ty = var->ty;

      switch (ty->kind)
      {
      case TY_STRUCT:
      case TY_UNION:
        assert(ty->size <= 16);
        if (has_flonum(ty, 0, 8, 0))
          store_fp(fp++, var->offset, MIN(8, ty->size));
        else
          store_gp(gp++, var->offset, MIN(8, ty->size));

        if (ty->size > 8)
        {
          if (has_flonum(ty, 8, 16, 0))
            store_fp(fp++, var->offset + 8, ty->size - 8);
          else
            store_gp(gp++, var->offset + 8, ty->size - 8);
        }
        break;
      case TY_FLOAT:
      case TY_DOUBLE:
        store_fp(fp++, var->offset, ty->size);
        break;
      default:
        store_gp(gp++, var->offset, ty->size);
      }
    }

    // Emit code
    gen_stmt(fn->body);
    assert(depth == 0);

    // [https://www.sigbus.info/n1570#5.1.2.2.3p1] The C spec defines
    // a special rule for the main function. Reaching the end of the
    // main function is equivalent to returning 0, even though the
    // behavior is undefined for the other functions.
    if (strcmp(fn->name, "main") == 0)
    {
      emitCode(encodeA(vmmvi, vmzero, vmr3, 0));
      println("  zero r3");
    }

    // Epilogue
    println(".L.return.%s:", fn->name);
    char *lnss = malloc(128);
    sprintf(lnss, ".L.return.%s", fn->name);
    efnp[efnc++] = ecc;
    efns[efnc - 1] = lnss;
    emitCode(encodeB(vmmov, vmsp, vmfp));
    println("  mov sp, fp");
    emitCode(encodeB(vmmov, vmr2, vmfp));
    println("  mov r2, fp");

    emitCode(encodeB(vmmov, vmr1, vmsp));
    println("  mov r1, sp");
    emitCode(encodeA(vmldm, vmr1, vmr2, 0));
    println("  ldm [r1], r2");
    emitCode(encodeA(vmshl, vmr2, vmr0, 8));
    println("  shl r2, r0+8");
    emitCode(encodeA(vmldm, vmr1, vmr2, 0xff));
    println("  ldm [r1-1], r2");
    emitCode(encodeA(vmadd, vmr1, vmr0, 2));
    println("  add r1, r0+2");
    emitCode(encodeB(vmmov, vmsp, vmr1));
    println("  mov sp, r1");

    emitCode(encodeA(vmjmp, vmret, vmr0, 0));
    println("  ret");
  }
}

void codegen(Obj *prog, FILE *out)
{
  output_file = out;
  output_file1 = fopen("deba.out", "w");

  File **files = get_input_files();
  for (int i = 0; files[i]; i++)
    println("  .file %d \"%s\"", files[i]->file_no, files[i]->name);

  assign_lvar_offsets(prog);
  emit_data(prog);
  emit_text(prog);

  fclose(output_file1);
  output_file1 = fopen("deba.out", "r+");

  fseek(output_file1, 4, SEEK_SET);

  fwrite(&elkc, 2, 1, output_file1);
  fwrite(&ecc, 2, 1, output_file1);

  fseek(output_file1, ecc, SEEK_SET);

  for (int i = 0; i < elkc; i++)
  {
    fwrite(&(elkp[i]), 2, 1, output_file1);
    fwrite(&i, 2, 1, output_file1);
  }

  for (int i = 0; i < elkc; i++)
  {
    fwrite(elks[i], 1, strlen(elks[i]) + 1, output_file1);
  }

  unsigned char sz = ftell(output_file1);

  for (int i = 0; i < efnc; i++)
  {
    fwrite(&(efnp[i]), 2, 1, output_file1);
    fwrite(&i, 2, 1, output_file1);
  }

  for (int i = 0; i < efnc; i++)
  {
    fwrite(efns[i], 1, strlen(efns[i]) + 1, output_file1);
  }

  fseek(output_file1, 8, SEEK_SET);

  fwrite(&efnc, 2, 1, output_file1);
  fwrite(&sz, sizeof(sz), 1, output_file1);

  fclose(output_file1);
}
