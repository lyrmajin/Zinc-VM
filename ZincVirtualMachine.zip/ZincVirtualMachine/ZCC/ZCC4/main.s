  .file 1 "tst/main.c"
  .local: .L..1
  .data:
  .type: .L..1, @object
  .size: .L..1, 5
  .align: 1
.L..1:
  .byte: 109
  .byte: 97
  .byte: 105
  .byte: 110
  .byte: 0
  .local: .L..0
  .data:
  .type: .L..0, @object
  .size: .L..0, 5
  .align: 1
.L..0:
  .byte: 109
  .byte: 97
  .byte: 105
  .byte: 110
  .byte: 0
  .globl main
  .text
  .type main, @function
main:
  mvi r3, 0
  jmp 1$.L.return.main
  zero r3
.L.return.main:
  mov sp, fp
  mov r2, fp
  mov r1, sp
  ldm [r1], r2
  shl r2, r0+8
  ldm [r1-1], r2
  add r1, r0+2
  mov sp, r1
  ret
