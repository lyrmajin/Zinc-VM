#include <drivers/core/usart/usart.h>

void main(void){
}