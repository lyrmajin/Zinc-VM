#ifndef SPI_H
#define SPI_H

void spi_init(void);
void spi_enable(void);
void spi_disable(void);
void spi_config(void);
void spi_tx(unsigned char data);
unsigned char spi_rx(void);
void spi_wait(void);
unsigned char spi_status(void);
void spi_reset(void);

#endif