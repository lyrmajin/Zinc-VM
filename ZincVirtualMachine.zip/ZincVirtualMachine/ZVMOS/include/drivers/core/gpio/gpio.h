#ifndef GPIO_H
#define GPIO_H

void gpio_init(void);

void gpio_input(unsigned int pin);
void gpio_output(unsigned int pin);

void gpio_write(unsigned int pin, unsigned char value);
unsigned char gpio_read(unsigned int pin);

void gpio_toggle(unsigned int pin);

void gpio_analog_input(unsigned int pin);
unsigned int gpio_read_analog(unsigned int pin);

void gpio_analog_output(unsigned int pin);
void gpio_write_analog(unsigned int pin, unsigned int value);

void gpio_enable(unsigned int pin);
void gpio_disable(unsigned int pin);

void gpio_reset(unsigned int pin);

#endif