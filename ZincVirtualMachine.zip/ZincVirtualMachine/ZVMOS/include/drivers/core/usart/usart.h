#ifndef USART_H
#define USART_H

void usart_init(void);
void usart_enable(void);
void usart_disable(void);

void usart_config(unsigned long baud, unsigned char data_bits,
                  unsigned char stop_bits, unsigned char parity);

void usart_tx(unsigned char data);
unsigned char usart_rx(void);

void usart_wait_tx(void);
void usart_wait_rx(void);

unsigned char usart_status(void);

void usart_reset(void);

#endif