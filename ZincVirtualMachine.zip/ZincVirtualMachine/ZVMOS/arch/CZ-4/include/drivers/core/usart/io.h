#ifndef USART_IO_H
#define USART_IO_H

void usart_set_baud_rate(unsigned long baud);
void usart_set_data_size(unsigned char bits);
void usart_set_stop_bits(unsigned char bits);
void usart_set_parity(unsigned char parity);
void usart_set_mode(unsigned char mode);

void usart_set_tx_enable(int enable);
void usart_set_rx_enable(int enable);

void usart_set_clock_polarity(unsigned char polarity);
void usart_set_clock_phase(unsigned char phase);
void usart_set_clock_divider(unsigned int divider);

void usart_enable(void);
void usart_disable(void);

void usart_enable_tx_interrupt(void);
void usart_disable_tx_interrupt(void);
void usart_enable_rx_interrupt(void);
void usart_disable_rx_interrupt(void);

void usart_enable_dma_tx(void);
void usart_disable_dma_tx(void);
void usart_enable_dma_rx(void);
void usart_disable_dma_rx(void);

void usart_clear_flags(void);
void usart_reset(void);

#endif