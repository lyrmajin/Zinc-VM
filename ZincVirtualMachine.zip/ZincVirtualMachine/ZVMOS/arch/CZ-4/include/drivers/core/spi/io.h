#ifndef SPI_IO_H
#define SPI_IO_H

void spi_set_clock_divider(unsigned int divider);
void spi_set_mode(unsigned char mode);
void spi_set_bit_order(unsigned char order);
void spi_set_data_size(unsigned char bits);

void spi_enable(void);
void spi_disable(void);

void spi_set_master(void);
void spi_set_slave(void);

void spi_set_tx_enable(int enable);
void spi_set_rx_enable(int enable);

void spi_write_reg(unsigned char reg, unsigned char value);
unsigned char spi_read_reg(unsigned char reg);

void spi_write_data(unsigned char data);
unsigned char spi_read_data(void);

void spi_wait_tx_ready(void);
void spi_wait_rx_ready(void);
void spi_wait_complete(void);

void spi_clear_flags(void);

void spi_enable_interrupt(void);
void spi_disable_interrupt(void);

void spi_enable_dma(void);
void spi_disable_dma(void);

void spi_reset(void);

#endif