#ifndef GPIO_IO_H
#define GPIO_IO_H

void gpio_set_direction(unsigned int pin, unsigned char direction);
void gpio_set_mode(unsigned int pin, unsigned char mode);

void gpio_set_pull(unsigned int pin, unsigned char pull);
void gpio_set_drive(unsigned int pin, unsigned char drive);
void gpio_set_speed(unsigned int pin, unsigned char speed);

void gpio_set_output(unsigned int pin, unsigned char value);
unsigned char gpio_get_input(unsigned int pin);

void gpio_set_alt_function(unsigned int pin, unsigned char function);

void gpio_set_interrupt(unsigned int pin, unsigned char mode);
void gpio_enable_interrupt(unsigned int pin);
void gpio_disable_interrupt(unsigned int pin);
void gpio_clear_interrupt(unsigned int pin);

void gpio_set_analog(unsigned int pin, unsigned char enable);

void gpio_set_adc_channel(unsigned int pin, unsigned char channel);
unsigned int gpio_read_adc(unsigned int channel);

void gpio_set_dac_channel(unsigned int pin, unsigned char channel);
void gpio_write_dac(unsigned int channel, unsigned int value);

void gpio_enable(unsigned int pin);
void gpio_disable(unsigned int pin);

void gpio_reset(unsigned int pin);

#endif