ISA:

0 OP_MVI	r0 = inm
1 OP_MOV	r[dst] = r[src]
2 OP_ADD	alur0 = r[src] | alur1 = r[dst] | r[dst] = (alur0 + alur1)
3 OP_SUB	alur0 = r[src] | alur1 = r[dst] | r[dst] = (alur0 - alur1)
4 OP_AND	alur0 = r[src] | alur1 = r[dst] | r[dst] = (alur0 & alur1)
5 OP_OR		alur0 = r[src] | alur1 = r[dst] | r[dst] = (alur0 | alur1)
6 OP_XOT	alur0 = r[src] | alur1 = r[dst] | r[dst] = (alur0 ^ alur1)
7 OP_CMP	alur0 = r[src] | alur1 = r[dst] | fl = iszero(alur0 - alur1)
8 OP_LD		memory[r[dst]] = r[src]
9 OP_ST		r[dst] = memory[r[src]]
A OP_JMP	if fl & r; then alur0 = r[src] else alur0 = pc | alur1 = r[dst] | pc = (alur0 + alur1)
B OP_BRN	if fl & r; then alur0 = r[src] else alur0 = pc | alur1 = r[dst] | if fl & z; then pc = (alur0 + alur1)
C OP_SHL	alur0 = r[src] | alur1 = r[dst] | r[dst] = (alur0 << alur1)
D OP_SHR	alur0 = r[src] | alur1 = r[dst] | r[dst] = (alur0 >> alur1)
E OP_IN		r[dst] = io[r[src]]
F OP_OUT	oi[r[dst]] = r[src]

Encoding:

Opcode: 4bi
RegDst: 2bi
RegSrc: 2bi

Registers:

INM0 ID 0
GPR0 ID 1
GPR1 ID 2
RRET ID 3

IO Registers:

PC FL P0
