module register (bus, rid, mod, sel, clk);
    inout [7:0] bus;
    input [1:0] rid;
    input mod;
    input sel;
    input clk;

    reg [7:0] registers [3:0];

    assign bus = (sel && !mod) ? registers[rid] : 8'bz;

    always @ (posedge clk) begin
        if (mod && sel)
            registers[rid] <= bus;
    end

endmodule