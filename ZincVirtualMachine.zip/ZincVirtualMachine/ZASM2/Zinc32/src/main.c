#include <stdio.h>

#include "emit.h"
#include "encoder.h"
#include "parse.h"

int main(){
    emitError("I:[0x%X]\n", encodeMOV(0,0,0,1,3));
    return 0;
}