#include "parse.h"
#include <string.h>
#include <stdlib.h>

unsigned int emitToken(char *str, unsigned int size, char ***destStr, unsigned int index)
{
    char **tmp = realloc(destStr, (index + 1) * sizeof(char *));
    if (!tmp)
    {
        return 1;
    }
    *destStr = tmp;

    char *tmpStr = malloc(sizeof(char)* (size+1));
    if(!tmpStr){
        return 2;
    }
    (*destStr)[index] = tmpStr;

    strcpy((*destStr)[index], str);
    return 0;
}

#define TOKENSTRSIZE 256

unsigned int getTokens(char *str, unsigned int size, char ***tokenList)
{
    char token[TOKENSTRSIZE] = 0;
    unsigned int o = 0, index = 0;
    for (unsigned int i = 0; i < size; i++)
    {
        if (str[i] == ' ' || str[i] == '\n')
        {
            emitToken(token, o, tokenList, index++);
            o = 0;
        }
        token[o++] = str[i];
        token[o] = 0;
    }
}