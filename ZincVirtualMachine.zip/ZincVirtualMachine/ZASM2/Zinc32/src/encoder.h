#ifndef ENCODER_H
#define ENCODER_H

#include <stdio.h>
#include <stdint.h>

uint32_t encodeMOV(unsigned char opcode, unsigned char registerA, unsigned char registerB, unsigned char memoryDirection, unsigned char bytesCount);

#endif