#include <stdio.h>
#include <stdint.h>

#include "encoder.h"

uint32_t encodeMOV(unsigned char opcode, unsigned char registerA, unsigned char registerB, unsigned char memoryDirection, unsigned char bytesCount){
    uint32_t B1 = (opcode << 3);
    uint32_t B2 = (((memoryDirection & 1) << 5) | (registerA & 0x1F));
    uint32_t B3 = (((bytesCount & 0x03) << 5) | (registerA & 0x1F));
    uint32_t B4 = 0;

    return ((B4 << 24) | (B3 << 16) | (B2 << 8) | (B1));
}

uint32_t encodeALU(){
    uint32_t B1, B2, B3, B4;
    return ((B4 << 24) | (B3 << 16) | (B2 << 8) | (B1));
}

uint32_t encodeBRN(){
    uint32_t B1, B2, B3, B4;
    return ((B4 << 24) | (B3 << 16) | (B2 << 8) | (B1));
}

uint32_t encodeSYS(){
    uint32_t B1, B2, B3, B4;
    return ((B4 << 24) | (B3 << 16) | (B2 << 8) | (B1));
}