#include <stdio.h>
#include <stdint.h>
#include <stdarg.h>

#include "emit.h"

void emitError(const char *fmt, ...){
    va_list args;
    va_start(args, fmt);

    vprintf(fmt, args);

    va_end(args);
}

void emitInstruction(uint32_t bin, FILE *file){
    if(!file){
        emitError("Unable to open output file");
    }
    fwrite(&bin, sizeof(uint32_t), 1, file);
}