#ifndef EMIT_H
#define EMIT_H

#include <stdio.h>
#include <stdint.h>
#include <stdarg.h>

void emitError(const char *fmt, ...);

void emitInstruction(uint32_t bin, FILE *file);

#endif