#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <llvm-c/Core.h>
#include <llvm-c/IRReader.h>
#include <llvm-c/Target.h>
#include <llvm-c/TargetMachine.h>
#include <llvm-c/Analysis.h>

#include "parse.h"
#include "tokenize.h"

typedef enum
{
    FL,
    TK,
    P1,
    P2,
    P3,
    CI,
    CG
} STAGE;

STAGE STAGEIN = FL;
STAGE STAGEOUT = CG;

int FileBuffer = 1024;
int StrBuffer = 256;

int Verbose = 0; // verbosity (0:NONE 1:LOW 2:MID 3:HIGH :4ELEVATED 5:EXTREME)

int TokenMaxSize = 0;
char *TokenOutFile = NULL;

static int parse_stage(const char *s, STAGE *out)
{
    if (!strcmp(s, "FL"))
        *out = FL;
    else if (!strcmp(s, "TK"))
        *out = TK;
    else if (!strcmp(s, "P1"))
        *out = P1;
    else if (!strcmp(s, "P2"))
        *out = P2;
    else if (!strcmp(s, "P3"))
        *out = P3;
    else if (!strcmp(s, "CI"))
        *out = CI;
    else if (!strcmp(s, "CG"))
        *out = CG;
    else
        return 0;
    return 1;
}

long long getFileSize(FILE *file)
{
    fseek(file, 0, SEEK_END);
    size_t size = ftell(file);
    fseek(file, 0, SEEK_SET);
    return size;
}

int main(int argc, char **argv)
{
    if (argc < 2)
        return 1;

    char *InputFile = NULL;
    char *OutputFile = NULL;
    char *EntryPoint = NULL;

    for (int i = 1; i < argc; i++)
    {
        char *arg = argv[i];

        if (!strncmp(arg, "--Verbose=", 10))
        {
            Verbose = atoi(arg + 10);
        }
        else if (!strncmp(arg, "-SI=", 4))
        {
            if (!parse_stage(arg + 4, &STAGEIN))
                return 1;
        }
        else if (!strncmp(arg, "-SO=", 4))
        {
            if (!parse_stage(arg + 4, &STAGEOUT))
                return 1;
        }
        else if (!strncmp(arg, "--TokenFileBuffer=", 18))
        {
            FileBuffer = atoi(arg + 18);
        }
        else if (!strncmp(arg, "--TokenMaxSize=", 15))
        {
            TokenMaxSize = atoi(arg + 15); /* unused */
        }
        else if (!strncmp(arg, "--TokenStrSize=", 15))
        {
            StrBuffer = atoi(arg + 15);
        }
        else if (!strncmp(arg, "--TokenOutFile=", 15))
        {
            TokenOutFile = arg + 15;
        }
        else if (!strncmp(arg, "-TKOF=", 6))
        {
            TokenOutFile = arg + 6;
        }
        else if (!strncmp(arg, "-ENTRY=", 7))
        {
            EntryPoint = arg + 7;
        }
        else
        {
            /* last non-flag argument is input file */
            InputFile = arg;
        }
    }

    if (Verbose >= 2)
        printf("Compiling \"%s\"\n", InputFile);

    FILE *ifile = fopen(InputFile, "rb");
    if (!ifile)
    {
        return 1;
    }

    FILE *ofile = NULL;

    if (!OutputFile)
    {
        OutputFile = malloc(sizeof(char) * 6);
        strcpy(OutputFile, "a.s");
    }

    ofile = fopen("a.ll", "wb");

    if (!ofile)
    {
        return 1;
    }

    TOKEN *tokens = NULL;
    int tokenCount = 0;

    AST1 **nodes = NULL;
    int nodesCount = 0;

    AST2 *nodes2 = NULL;
    int nodes2Count = 0;

    if (tokenize(
            ifile,
            getFileSize(ifile),
            &tokens,
            &tokenCount))
        return 1;

    if (parse1(
            tokens,
            &tokenCount,
            &nodes,
            &nodesCount))
        return 1;

    if (parse2(
            nodes,
            &nodesCount,
            &nodes2,
            &nodes2Count))
        return 1;

    fprintf(ofile, "target triple = \"x86_64-pc-linux-gnu\"\n");

    fprintf(ofile,
            "@llvm.used = appending global [1 x i8*] "
            "[i8* bitcast (void ()* @_start to i8*)]\n\n");

    fprintf(ofile, "declare i8* @llvm.frameaddress(i32)\n\n");

    fprintf(ofile,
            "define dso_local void @_start() {\n"
            "entry:\n");

    if (!EntryPoint)
    {
        EntryPoint = malloc(sizeof(char) * 5);
        if (!EntryPoint)
            return 1;
        strcpy(EntryPoint, "main");
    }

    fprintf(ofile,
            "    %%fp = call i8* @llvm.frameaddress(i32 0)\n"
            "    call void @%s(i8* null, i8* null, i8* %%fp)\n"
            "    call void asm sideeffect \"syscall\", "
            "\"{rax},{rdi},~{rcx},~{r11}\"(i64 60, i64 0)\n"
            "    unreachable\n"
            "}\n\n",
            EntryPoint);

    if (parse3(
            nodes2,
            nodes2Count,
            ofile))
        return 1;

    fclose(ofile);

    if (STAGEOUT < CG)
        return 0;

    LLVMModuleRef module;
    LLVMContextRef context = LLVMContextCreate();
    LLVMMemoryBufferRef buffer;
    char *error = NULL;

    /* load IR */
    if (LLVMCreateMemoryBufferWithContentsOfFile("a.ll", &buffer, &error))
    {
        fprintf(stderr, "File error: %s\n", error);
        LLVMDisposeMessage(error);
        return 1;
    }

    /* parse IR */
    if (LLVMParseIRInContext(context, buffer, &module, &error))
    {
        fprintf(stderr, "Parse error: %s\n", error);
        LLVMDisposeMessage(error);
        return 1;
    }

    /* DEBUG: verify module exists */
    LLVMDumpModule(module);

    /* init target */
    LLVMInitializeNativeTarget();
    LLVMInitializeNativeAsmPrinter();
    LLVMInitializeNativeAsmParser();

    /* force triple (important) */
    LLVMSetTarget(module, LLVMGetDefaultTargetTriple());

    LLVMTargetRef target;
    if (LLVMGetTargetFromTriple(LLVMGetDefaultTargetTriple(), &target, &error))
    {
        fprintf(stderr, "Target error: %s\n", error);
        LLVMDisposeMessage(error);
        return 1;
    }

    LLVMTargetMachineRef tm = LLVMCreateTargetMachine(
        target,
        LLVMGetDefaultTargetTriple(),
        "",
        "",
        LLVMCodeGenLevelDefault,
        LLVMRelocDefault,
        LLVMCodeModelDefault);

    /* emit assembly */
    if (LLVMTargetMachineEmitToFile(
            tm,
            module,
            OutputFile,
            LLVMAssemblyFile,
            &error))
    {
        fprintf(stderr, "Emit error: %s\n", error);
        LLVMDisposeMessage(error);
        return 1;
    }
}