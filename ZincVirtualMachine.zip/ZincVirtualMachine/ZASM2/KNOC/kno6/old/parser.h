#ifndef PARSER_H
#define PARSER_H

#include "tokenize.h"

/* Primitive Identifiers
    Types:
        u8 FIXED WIDTH UNSIGNED
        u16
        u32
        u64

        i8 FIXED WIDTH SIGNED
        i16
        i32
        i64

        padd8 DINAMIC PADD TO SIZE
        padd16
        padd32
        padd64

        byte CPU BYTE SIZE
        word CPU WORD SIZE
        ptr CPU POINTER SIZE

    Cosntants:
        nU UNSIGNED INTEGER
        nI SIGNED INTEGER
        nX HEXADECIMAL
        nB BINARY

        'C' ASCII CHARACTER
        "str\00" ASCII STRING

    Operations CORE:
        Open
        Close
        Import
        Export
        CMD
        ASM
        Typedef

    Operations Logic:
        + ADD
        - SUB
        * MUL
        / DIV
        % MOD
        & AND
        | OR
        ^ XOR
        ~ NOT
        ! NOT
        = SET
        == CMP
        ? THEN
        > GREATER THAN
        < LESS THAN
        . SUBTYPE
        , NOP
        += SET ADD
        -= SET DUB
        *= SET MUL
        /= SET DIV
        %= SET MOD
        &= SET AND
        |= SET OR
        ^= SET XOR
        >= GREATER THAN or EQUAL
        <= LESS THAN or EQUAL
        +. FLOAT ADD
        -. FLOAT SUB
        *. FLOAT MUL
        /. FLOAT DIV
        %. FLOAT MOD
        ?. FLOAT CMP
        >. FLOAT GREATER THAN
        <. FLOAT LESS THAN
        >=. FLOAT GREATER THAN or EQUAL
        <=. FLOAT LESS THAN or EQUAL
*/

typedef enum
{
    U8 = 1,
    I8 = 1,

    U16 = 2,
    I16 = 2,

    U32 = 4,
    I32 = 4,

    U64 = 8,
    I64 = 8,

    PADD8 = 1,
    PADD16 = 2,
    PADD32 = 4,
    PADD64 = 8,


    VOID = 0,

#if defined(__i386__)
    BYTE = 1,
    WORD = 4,
    PTR = 4

#elif defined(__x86_64__) || defined(__amd64__)
    BYTE = 1,
    WORD = 8,
    PTR = 8

#elif defined(__arm__) && !defined(__aarch64__)
    BYTE = 1,
    WORD = 4,
    PTR = 4

#elif defined(__aarch64__)
    BYTE = 1,
    WORD = 8,
    PTR = 8

#elif defined(__riscv) && __riscv_xlen == 32
    BYTE = 1,
    WORD = 4,
    PTR = 4

#elif defined(__riscv) && __riscv_xlen == 64
    BYTE = 1,
    WORD = 8,
    PTR = 8

#elif defined(__powerpc64__)
    BYTE = 1,
    WORD = 8,
    PTR = 8

#elif defined(__powerpc__)
    BYTE = 1,
    WORD = 4,
    PTR = 4

#elif defined(__mips__) && _MIPS_SIM == _ABI64
    BYTE = 1,
    WORD = 8,
    PTR = 8

#elif defined(__mips__)
    BYTE = 1,
    WORD = 4,
    PTR = 4

#else
#error "Unsupported architecture"
#endif

} STD_TYPES;
 // ----------

typedef enum
{
    CALL,
    OPERATION,
    IDENTIFIER,
    SCOPE_SEP,
    SCOPE_NSEP,
    NEWLINE_SEP,
    CHARS_SEP,
    ARGUMENT_SEP
} AST1_TYPE;

typedef struct AST1
{
    AST1_TYPE type;
    char *str;

    TOKEN *token;

    struct AST1 **childrens;
    int childCount;

    struct AST1 *parent;
} AST1;

typedef enum
{
    ATOM,
    ATOMS,
    CAST,
    UNARY,
    BINARY,
    BEG_SEP,
    END_SEP
} AST2_TYPE;

typedef struct AST2
{
    AST2_TYPE type;
    AST1 *node;
} AST2;

typedef struct
{
    AST2 *node;
    unsigned char isTypeDef;
    unsigned int offset;
    STD_TYPES type;
} IDENT;

// -----

typedef enum
{
    ADD,
    SUB,
    MUL,
    DIV,
    MOD,
    AND,
    OR,
    XOR,
    NOT,
    NEG,
    SET,
    CMP,
    THEN,
    GREATER_THAN,
    LESS_THAN,
    SUBTYPE,
    NOP,
    SET_ADD,
    SET_DUB,
    SET_MUL,
    SET_DIV,
    SET_MOD,
    SET_AND,
    SET_OR,
    SET_XOR,
    GREATER_THAN_OR_EQUAL,
    LESS_THAN_OR_EQUAL,
    FLOAT_ADD,
    FLOAT_SUB,
    FLOAT_MUL,
    FLOAT_DIV,
    FLOAT_MOD,
    FLOAT_CMP,
    FLOAT_GREATER_THAN,
    FLOAT_REATER_THAN_OR_EQUAL,
    FLOAT_LESS_THAN_OR_EQUAL
} STD_OPERATION;

// ----


void parse1(AST1 ***nodes, int *nodesCount, TOKEN *tokens, int *tokensCount);

#endif