#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tokenizer.h"

typedef enum
{
    ID,
    SCOPE,
    ARGUMENT,
    INLINE_OPEN,
    INLINE_CLOSE,
    STRING,
    OPERATOR,
    CHARACTER,
    BLOCK_OPEN,
    BLOCK_CLOSE,
    TERMINATOR
} TOKEN_TYPE;

typedef struct
{
    TOKEN_TYPE type;
    char *str;
    int x, y;
} TOKEN;

TOKEN *tokens;
int tokensCount = 0;

int tokenizer(FILE *file)
{
    if (!file)
        return 1;

    char token[256] = {0};

    fseek(file, 0, SEEK_END);
    int filesize = ftell(file);
    fseek(file, 0, SEEK_SET);

    printf("FileSize:[%d] FilePosition:[%ld]\n", filesize, ftell(file));

    const int buffersize = 1024;
    char *buffer = (char *)malloc(buffersize * sizeof(char));

    if (!buffer)
    {
        printf("Inable to open buffer\n");
        return 1;
    }

    int bufferindex = 0;
    int bufferYindex = 0;
    int tokenindex = 0;

    int DoStringSpaceTrim = 0;
    int DoCharacterSpaceTrim = 0;

    while (bufferindex < ((filesize + buffersize - 1) / buffersize))
    {
        size_t readBytes = 0;
        if ((readBytes = (fread(buffer, sizeof(char), buffersize, file))) == 0)
        {
            if (feof(file))
            {
                return 0;
            }
            else
            {
                return 1;
            }
        }

        for (int index = 0; index < buffersize; index++)
        {
            if (buffer[index] == '\n')
                bufferYindex++;
            if ((index + 1) < buffersize)
            {
                if (buffer[index] == '#' && buffer[index + 1] == '/')
                {
                    while (buffer[++index] != '#' && buffer[index + (((index + 1) < buffersize) ? index + 1 : index)] != '\\')
                        if (index >= buffersize)
                            break;
                    index++;
                    continue;
                }
                else if (buffer[index] == ':' && buffer[index + 1] == ':')
                {
                    if (DoCharacterSpaceTrim || DoStringSpaceTrim)
                    {
                        if ((tokenindex + 2) < 256)
                        {
                            token[tokenindex++] = buffer[index];
                            token[tokenindex] = 0;
                        }
                        continue;
                    }
                    char *tmp = NULL;
                    if (tokenindex > 0)
                    {
                        tmp = malloc(sizeof(char) * (tokenindex + 1));

                        strcpy(tmp, token);

                        printf("%s\n", tmp);
                    }

                    token[0] = 0;
                    tokenindex = 0;

                    char *tmp2 = malloc(sizeof(char) * 3);

                    strcpy(tmp2, "::");

                    printf("%s\n", tmp2);

                    tokensCount += (tmp) ? 2 : 1;
                    TOKEN *tmpTK = (TOKEN *)realloc(tokens, sizeof(TOKEN) * tokensCount);

                    if (!tmpTK)
                    {
                        printf("Inable to create tokens\n");
                        return 1;
                    }
                    tokens = tmpTK;
                    if (tmp)
                    {
                        tokens[tokensCount - 2].type = ID;
                        tokens[tokensCount - 2].str = tmp;
                        tokens[tokensCount - 2].x = index;
                        tokens[tokensCount - 2].y = bufferYindex;
                    }
                    tokens[tokensCount - 1].type = SCOPE;
                    tokens[tokensCount - 1].str = tmp2;
                    tokens[tokensCount - 1].x = index;
                    tokens[tokensCount - 1].y = bufferYindex;

                    index++;
                    continue;
                }
                else if (buffer[index] == ';' && buffer[index + 1] == ';')
                {
                    if (DoCharacterSpaceTrim || DoStringSpaceTrim)
                    {
                        if ((tokenindex + 2) < 256)
                        {
                            token[tokenindex++] = buffer[index];
                            token[tokenindex] = 0;
                        }
                        continue;
                    }
                    char *tmp = NULL;
                    if (tokenindex > 0)
                    {
                        tmp = malloc(sizeof(char) * (tokenindex + 1));

                        strcpy(tmp, token);

                        printf("%s\n", tmp);
                    }

                    token[0] = 0;
                    tokenindex = 0;

                    char *tmp2 = malloc(sizeof(char) * 3);

                    strcpy(tmp2, ";;");

                    printf("%s\n", tmp2);

                    tokensCount += (tmp) ? 2 : 1;
                    TOKEN *tmpTK = (TOKEN *)realloc(tokens, sizeof(TOKEN) * tokensCount);

                    if (!tmpTK)
                    {
                        printf("Inable to create tokens\n");
                        return 1;
                    }
                    tokens = tmpTK;
                    if (tmp)
                    {
                        tokens[tokensCount - 2].type = ID;
                        tokens[tokensCount - 2].str = tmp;
                        tokens[tokensCount - 2].x = index;
                        tokens[tokensCount - 2].y = bufferYindex;
                    }
                    tokens[tokensCount - 1].type = TERMINATOR;
                    tokens[tokensCount - 1].str = tmp2;
                    tokens[tokensCount - 1].x = index;
                    tokens[tokensCount - 1].y = bufferYindex;

                    index++;
                    continue;
                }
            }

            if (buffer[index] == '#')
            {
                while (buffer[++index] != '\n')
                    if (index >= buffersize)
                        break;
                continue;
            }
            else

                if (buffer[index] == ':' || buffer[index] == '[' || buffer[index] == ']' || buffer[index] == '{' || buffer[index] == '}' || buffer[index] == '\"' || buffer[index] == '\'' || buffer[index] == '+' || buffer[index] == '-' || buffer[index] == '=' || buffer[index] == '*' || buffer[index] == '/' || buffer[index] == '%' || buffer[index] == '>' || buffer[index] == '<' || buffer[index] == '?' || buffer[index] == '&' || buffer[index] == '^' || buffer[index] == '!' || buffer[index] == '~' || buffer[index] == '|')
            {
                int TYPE, process = 1;
                switch (buffer[index])
                {
                case ':':
                    TYPE = ARGUMENT;
                    break;
                case '[':
                    TYPE = INLINE_OPEN;
                    break;
                case ']':
                    TYPE = INLINE_CLOSE;
                    break;
                case '{':
                    TYPE = BLOCK_OPEN;
                    break;
                case '}':
                    TYPE = BLOCK_CLOSE;
                    break;
                case '\"':
                    TYPE = STRING;
                    if (!DoCharacterSpaceTrim)
                    {
                        DoStringSpaceTrim = ~DoStringSpaceTrim;
                        process = 0;
                    }
                    break;
                case '\'':
                    TYPE = CHARACTER;
                    if (!DoStringSpaceTrim)
                    {
                        DoCharacterSpaceTrim = ~DoCharacterSpaceTrim;
                        process = 0;
                    }
                    break;
                case '+':
                case '-':
                case '=':
                case '*':
                case '%':
                case '>':
                case '<':
                case '?':
                case '&':
                case '^':
                case '!':
                case '~':
                case '|':
                    TYPE = OPERATOR;
                    break;
                default:
                    TYPE = ID;
                    break;
                }

                if ((DoCharacterSpaceTrim || DoStringSpaceTrim) && process)
                {
                    if ((tokenindex + 2) < 256)
                    {
                        token[tokenindex++] = buffer[index];
                        token[tokenindex] = 0;
                    }
                    continue;
                }

                char *tmp = NULL;
                if (tokenindex > 0)
                {
                    tmp = malloc(sizeof(char) * (tokenindex + 1));

                    strcpy(tmp, token);

                    printf("%s\n", tmp);
                }

                token[0] = 0;
                tokenindex = 0;

                char *tmp2 = malloc(sizeof(char) * 2);

                tmp2[0] = buffer[index];
                tmp2[1] = 0;

                printf("%s\n", tmp2);

                tokensCount += (tmp) ? 2 : 1;
                TOKEN *tmpTK = (TOKEN *)realloc(tokens, sizeof(TOKEN) * tokensCount);

                if (!tmpTK)
                {
                    printf("Inable to create tokens\n");
                    return 1;
                }
                tokens = tmpTK;

                if (tmp)
                {
                    tokens[tokensCount - 2].type = ID;
                    tokens[tokensCount - 2].str = tmp;
                    tokens[tokensCount - 2].x = index;
                    tokens[tokensCount - 2].y = bufferYindex;
                }

                tokens[tokensCount - 1].str = tmp2;
                tokens[tokensCount - 1].type = TYPE;
                tokens[tokensCount - 1].x = index;
                tokens[tokensCount - 1].y = bufferYindex;

                continue;
            }

            if ((tokenindex + 2) < 256 && (buffer[index] != ' ' && buffer[index] != '\n' || DoStringSpaceTrim || DoStringSpaceTrim))
            {
                token[tokenindex++] = buffer[index];
                token[tokenindex] = 0;
            }
        }

        bufferindex++;
    }

    char *tmp = NULL;
    if (tokenindex > 0 && token[0] != 0)
    {
        tmp = malloc(sizeof(char) * (tokenindex + 1));

        strcpy(tmp, token);

        printf("%s\n", tmp);
    }

    tokensCount += (tmp) ? 1 : 0;
    TOKEN *tmpTK = (TOKEN *)realloc(tokens, sizeof(TOKEN) * tokensCount);

    if (!tmpTK)
    {
        printf("Inable to create tokens\n");
        return 1;
    }
    tokens = tmpTK;

    if (tmp)
    {
        tokens[tokensCount - 1].type = ID;
        tokens[tokensCount - 1].str = tmp;
        tokens[tokensCount - 1].x = 0;
        tokens[tokensCount - 1].y = bufferYindex;
    }

    printf("TKC:[%d]\n", tokensCount);
    for (int i = 0; i < tokensCount; i++)
        printf("TOKEN[%d]:T:[%d]S:[%s]\n", i, tokens[i].type, tokens[i].str);

    for (int a = 0; a < 10; a++)
        printf("\n");

    return 0;
}

typedef enum
{
    CALL,
    OPERATION,
    IDENTIFIER,
    SCOPE_SEP,
    SCOPE_NSEP,
    ARGUMENT_SEP
} AST1_TYPE;

typedef struct AST1
{
    AST1_TYPE type;
    char *str;

    TOKEN *token;

    struct AST1 **childrens;
    int childCount;

    struct AST1 *parent;
} AST1;

AST1 **NODES1 = NULL;
int nodeCount = 0;

AST1 **addASTNode(AST1 **NODES1, int *count)
{
    /*printf("NC:COUNT:[%u]:NODE:[%p] = \n", *count, NODES1);
    for(int i = 0; i < (*count); i++)
        printf("%p;\n", (NODES1) ? NODES1[i]: NULL);
    fflush(stdout);*/

    (*count)++;
    AST1 **tmp = realloc(NODES1, (*count) * sizeof(AST1 *));
    if (!tmp)
    {
        printf("Unable to allocate AST Type:[1] tree node\n");
        (*count)--;
        return NODES1;
    }
    return tmp;
}

void parse2(AST1 **node, int count);

void parse1()
{
    int FAIL = 0; // Once the whole parsing is finish, this should be cleared if all is valid (Refering to {} [] ::;; pairs)
    int LEAD = 0;

    AST1 ***SCOPEND = &NODES1;
    int *CHILDCOUNT = &nodeCount;
    AST1 *PARENT = NULL;
    for (int index = 0; index < tokensCount; index++)
    {
        LEAD = 0;
        if ((index + 1) < tokensCount)
        {
            if (tokens[index].type == ID && tokens[index + 1].type == SCOPE)
            {
                printf("P1\n");
                FAIL += 1;
                LEAD = 1;
                *SCOPEND = addASTNode(*SCOPEND, CHILDCOUNT);
                (*SCOPEND)[*CHILDCOUNT - 1] = (AST1 *)malloc(sizeof(AST1));
                if ((*SCOPEND)[*CHILDCOUNT - 1] == NULL)
                {
                    printf("Error allocating AST Node\n");
                    return;
                }

                (*SCOPEND)[*CHILDCOUNT - 1]->type = CALL;
                (*SCOPEND)[*CHILDCOUNT - 1]->str = tokens[index].str;
                (*SCOPEND)[*CHILDCOUNT - 1]->token = &tokens[index];
                (*SCOPEND)[*CHILDCOUNT - 1]->childrens = NULL;
                (*SCOPEND)[*CHILDCOUNT - 1]->childCount = 0;
                (*SCOPEND)[*CHILDCOUNT - 1]->parent = PARENT;

                *SCOPEND = addASTNode(*SCOPEND, CHILDCOUNT);
                (*SCOPEND)[*CHILDCOUNT - 1] = (AST1 *)malloc(sizeof(AST1)); // new parent
                if ((*SCOPEND)[*CHILDCOUNT - 1] == NULL)
                {
                    printf("Error allocating AST Node\n");
                    return;
                }

                (*SCOPEND)[*CHILDCOUNT - 1]->type = SCOPE_SEP;
                (*SCOPEND)[*CHILDCOUNT - 1]->str = tokens[index + 1].str;
                (*SCOPEND)[*CHILDCOUNT - 1]->token = &tokens[index + 1];
                (*SCOPEND)[*CHILDCOUNT - 1]->childCount = 0;
                (*SCOPEND)[*CHILDCOUNT - 1]->childrens = NULL;
                (*SCOPEND)[*CHILDCOUNT - 1]->parent = PARENT; // Old parent

                PARENT = (*SCOPEND)[*CHILDCOUNT - 1]; // set new parent
                AST1 ***tmp = SCOPEND;
                SCOPEND = &((*SCOPEND)[*CHILDCOUNT - 1]->childrens);
                CHILDCOUNT = &((*tmp)[*CHILDCOUNT - 1]->childCount);

                printf("TOKEN[%u]: Call [\"%s\"] Arguments ---> \n", index, tokens[index].str);
                index += 1;
                continue;
            }
        }

        if (tokens[index].type == OPERATOR)
        {
            printf("P2\n");
            printf("TOKEN[%u]: Operation '", index);
            int po = index;
            char opStr[4 * 1024];
            int opindex = 0;
            for (; ((po + 1 < tokensCount) && tokens[po + 1].type != ID && tokens[po].type == OPERATOR); po++)
            {
                opStr[opindex++] = tokens[po].str[0];
            }
            if (po + 1 < tokensCount)
            {
                if (tokens[po + 1].type == ID && tokens[po].type == OPERATOR)
                    opStr[opindex++] = tokens[po++].str[0];

                opStr[opindex] = 0;

                char *tmpchr = (char *)calloc(opindex + 1, sizeof(char));

                memcpy(tmpchr, opStr, opindex + 1);

                *SCOPEND = addASTNode(*SCOPEND, CHILDCOUNT);
                (*SCOPEND)[*CHILDCOUNT - 1] = (AST1 *)malloc(sizeof(AST1));
                if ((*SCOPEND)[*CHILDCOUNT - 1] == NULL)
                {
                    printf("Error allocating AST Node\n");
                    return;
                }

                (*SCOPEND)[*CHILDCOUNT - 1]->type = OPERATION;
                (*SCOPEND)[*CHILDCOUNT - 1]->str = tmpchr;
                (*SCOPEND)[*CHILDCOUNT - 1]->token = &tokens[index];
                (*SCOPEND)[*CHILDCOUNT - 1]->childCount = 0;
                (*SCOPEND)[*CHILDCOUNT - 1]->childrens = NULL;
                (*SCOPEND)[*CHILDCOUNT - 1]->parent = PARENT;

                printf("%s", opStr);
                printf("' TO ---> \n");
                index = po;
            }
        }

        if (tokens[index].type == INLINE_OPEN)
        {
            printf("P3A\n");
            FAIL += 2;
            LEAD = 1;

            *SCOPEND = addASTNode(*SCOPEND, CHILDCOUNT);
            (*SCOPEND)[*CHILDCOUNT - 1] = (AST1 *)malloc(sizeof(AST1));
            if ((*SCOPEND)[*CHILDCOUNT - 1] == NULL)
            {
                printf("Error allocating AST Node\n");
                return;
            }

            (*SCOPEND)[*CHILDCOUNT - 1]->type = SCOPE_SEP;
            (*SCOPEND)[*CHILDCOUNT - 1]->str = tokens[index].str;
            (*SCOPEND)[*CHILDCOUNT - 1]->token = &tokens[index];
            (*SCOPEND)[*CHILDCOUNT - 1]->childCount = 0;
            (*SCOPEND)[*CHILDCOUNT - 1]->childrens = NULL;
            (*SCOPEND)[*CHILDCOUNT - 1]->parent = PARENT;

            PARENT = (*SCOPEND)[*CHILDCOUNT - 1];
            AST1 ***tmp = SCOPEND;
            SCOPEND = &((*SCOPEND)[*CHILDCOUNT - 1]->childrens);
            CHILDCOUNT = &((*tmp)[*CHILDCOUNT - 1]->childCount);

            printf("\nTOKEN[%u]: Inline Function ------> [\n\n", index);
            continue;
        }
        if (tokens[index].type == INLINE_CLOSE)
        {
            printf("P3B\n");
            FAIL -= 2;
            
            *SCOPEND = addASTNode(*SCOPEND, CHILDCOUNT);
            (*SCOPEND)[*CHILDCOUNT - 1] = (AST1 *)malloc(sizeof(AST1));
            if ((*SCOPEND)[*CHILDCOUNT - 1] == NULL)
            {
                printf("Error allocating AST Node\n");
                return;
            }

            (*SCOPEND)[*CHILDCOUNT - 1]->type = SCOPE_NSEP;
            (*SCOPEND)[*CHILDCOUNT - 1]->str = tokens[index].str;
            (*SCOPEND)[*CHILDCOUNT - 1]->token = &tokens[index];
            (*SCOPEND)[*CHILDCOUNT - 1]->childrens = NULL;
            (*SCOPEND)[*CHILDCOUNT - 1]->childCount = 0;
            (*SCOPEND)[*CHILDCOUNT - 1]->parent = PARENT;

            if (PARENT)
            {
                SCOPEND = &(PARENT->childrens);
                CHILDCOUNT = &(PARENT->childCount);
                PARENT = PARENT->parent;
            }
            else
            {
                SCOPEND = &NODES1;
                CHILDCOUNT = &nodeCount;
                PARENT = NULL;
            }

            printf("\n] <------ Inline Function :TOKEN[%u]\n\n", index);
            continue;
        }

        if (tokens[index].type == BLOCK_OPEN)
        {
            printf("P3C\n");
            FAIL += 3;
            LEAD = 1;

            *SCOPEND = addASTNode(*SCOPEND, CHILDCOUNT);
            (*SCOPEND)[*CHILDCOUNT - 1] = (AST1 *)malloc(sizeof(AST1));
            if ((*SCOPEND)[*CHILDCOUNT - 1] == NULL)
            {
                printf("Error allocating AST Node\n");
                return;
            }

            (*SCOPEND)[*CHILDCOUNT - 1]->type = SCOPE_SEP;
            (*SCOPEND)[*CHILDCOUNT - 1]->str = tokens[index].str;
            (*SCOPEND)[*CHILDCOUNT - 1]->token = &tokens[index];
            (*SCOPEND)[*CHILDCOUNT - 1]->childCount = 0;
            (*SCOPEND)[*CHILDCOUNT - 1]->childrens = NULL;
            (*SCOPEND)[*CHILDCOUNT - 1]->parent = PARENT;

            PARENT = (*SCOPEND)[*CHILDCOUNT - 1];
            AST1 ***tmp = SCOPEND;
            SCOPEND = &((*SCOPEND)[*CHILDCOUNT - 1]->childrens);
            CHILDCOUNT = &((*tmp)[*CHILDCOUNT - 1]->childCount);

            printf("\nTOKEN[%u]: Block ------> {\n\n", index);
            continue;
        }
        if (tokens[index].type == BLOCK_CLOSE)
        {
            printf("P3D\n");
            FAIL -= 3;

            *SCOPEND = addASTNode(*SCOPEND, CHILDCOUNT);
            (*SCOPEND)[*CHILDCOUNT - 1] = (AST1 *)malloc(sizeof(AST1));
            if ((*SCOPEND)[*CHILDCOUNT - 1] == NULL)
            {
                printf("Error allocating AST Node\n");
                return;
            }

            (*SCOPEND)[*CHILDCOUNT - 1]->type = SCOPE_NSEP;
            (*SCOPEND)[*CHILDCOUNT - 1]->str = tokens[index].str;
            (*SCOPEND)[*CHILDCOUNT - 1]->token = &tokens[index];
            (*SCOPEND)[*CHILDCOUNT - 1]->childrens = NULL;
            (*SCOPEND)[*CHILDCOUNT - 1]->childCount = 0;
            (*SCOPEND)[*CHILDCOUNT - 1]->parent = PARENT;

            if (PARENT)
            {
                SCOPEND = &(PARENT->childrens);
                CHILDCOUNT = &(PARENT->childCount);
                PARENT = PARENT->parent;
            }
            else
            {
                SCOPEND = &NODES1;
                CHILDCOUNT = &nodeCount;
                PARENT = NULL;
            }

            printf("\n} <------ Block :TOKEN[%u]\n\n", index);
            continue;
        }

        if (tokens[index].type == ARGUMENT)
        {
            printf("P4\n");
            *SCOPEND = addASTNode(*SCOPEND, CHILDCOUNT);
            (*SCOPEND)[*CHILDCOUNT - 1] = (AST1 *)malloc(sizeof(AST1));
            if ((*SCOPEND)[*CHILDCOUNT - 1] == NULL)
            {
                printf("Error allocating AST Node\n");
                return;
            }

            (*SCOPEND)[*CHILDCOUNT - 1]->type = ARGUMENT_SEP;
            (*SCOPEND)[*CHILDCOUNT - 1]->str = tokens[index].str;
            (*SCOPEND)[*CHILDCOUNT - 1]->token = &tokens[index];
            (*SCOPEND)[*CHILDCOUNT - 1]->childrens = NULL;
            (*SCOPEND)[*CHILDCOUNT - 1]->childCount = 0;
            (*SCOPEND)[*CHILDCOUNT - 1]->parent = PARENT;
            printf("TOKEN[%u]: Function Argument --->\n", index);
            continue;
        }
        if (tokens[index].type == TERMINATOR)
        {
            printf("P5\n");
            FAIL -= 1;

            *SCOPEND = addASTNode(*SCOPEND, CHILDCOUNT);
            (*SCOPEND)[*CHILDCOUNT - 1] = (AST1 *)malloc(sizeof(AST1));
            if ((*SCOPEND)[*CHILDCOUNT - 1] == NULL)
            {
                printf("Error allocating AST Node\n");
                return;
            }

            (*SCOPEND)[*CHILDCOUNT - 1]->type = SCOPE_NSEP;
            (*SCOPEND)[*CHILDCOUNT - 1]->str = tokens[index].str;
            (*SCOPEND)[*CHILDCOUNT - 1]->token = &tokens[index];
            (*SCOPEND)[*CHILDCOUNT - 1]->childrens = NULL;
            (*SCOPEND)[*CHILDCOUNT - 1]->childCount = 0;
            (*SCOPEND)[*CHILDCOUNT - 1]->parent = PARENT;

            if (PARENT)
            {
                SCOPEND = &(PARENT->childrens);
                CHILDCOUNT = &(PARENT->childCount);
                PARENT = PARENT->parent;
            }
            else
            {
                SCOPEND = &NODES1;
                CHILDCOUNT = &nodeCount;
                PARENT = NULL;
            }

            printf("^--- End of Arguments TOKEN[%u]\n", index);
            continue;
        }

        printf("P6\n");

        *SCOPEND = addASTNode(*SCOPEND, CHILDCOUNT);
        (*SCOPEND)[*CHILDCOUNT - 1] = (AST1 *)malloc(sizeof(AST1));
        if ((*SCOPEND)[*CHILDCOUNT - 1] == NULL)
        {
            printf("Error allocating AST Node\n");
            return;
        }

        (*SCOPEND)[*CHILDCOUNT - 1]->type = IDENTIFIER;
        (*SCOPEND)[*CHILDCOUNT - 1]->str = tokens[index].str;
        (*SCOPEND)[*CHILDCOUNT - 1]->token = &tokens[index];
        (*SCOPEND)[*CHILDCOUNT - 1]->childrens = NULL;
        (*SCOPEND)[*CHILDCOUNT - 1]->childCount = 0;
        (*SCOPEND)[*CHILDCOUNT - 1]->parent = PARENT;

        printf("Undefined Behaviour for TOKEN[%u]: ------------> \"%s\"\n", index, tokens[index].str);
    }
    printf("FAIL?:%u F:[%d]L:[%u]\n", FAIL || LEAD, FAIL, LEAD);

    for (int a = 0; a < 10; a++)
        printf("\n");

    parse2(NODES1, nodeCount);
}

typedef enum AST2_TYPE
{
    FUNCTION,
} AST2_TYPE;

typedef struct AST2
{
    AST2_TYPE type;

    AST1 *AST1;

    struct AST2 **childrens;
    int childCount;

    struct AST2 *parent;
} AST2;

void parse2(AST1 **node, int count)
{
    if (!node)
    {
        printf("Error while opening AST1 nodes tree\n");
        return;
    }
    for (int i = 0; i < count; i++)
    {
        if (node[i] != NULL){
            printf("NODE[%u]:\"%s\"\n", i, node[i]->str);
            if(node[i]->type == SCOPE_SEP){
                parse2(node[i]->childrens, node[i]->childCount);
            }
        }
    }
}