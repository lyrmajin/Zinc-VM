#include <stdio.h>
#include <stdlib.h>
#include "tokenizer.h"

int main(int argc, char **argv)
{
    if (argc < 2)
        return 1;

    printf("Compiling:%s\n", argv[argc - 1]);
    FILE *file = fopen(argv[argc - 1], "rb");
    if (!file)
        return 1;

    tokenizer(file);
    parse1();

    return 0;
}