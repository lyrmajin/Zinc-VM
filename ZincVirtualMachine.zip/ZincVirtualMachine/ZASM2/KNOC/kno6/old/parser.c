#include "parse.h"
#include "tokenize.h"

extern int Verbose;

AST1 **addASTNode(AST1 **NODES1, int *count)
{
    /*printf("NC:COUNT:[%u]:NODE:[%p] = \n", *count, NODES1);
    for(int i = 0; i < (*count); i++)
        printf("%p;\n", (NODES1) ? NODES1[i]: NULL);
    fflush(stdout);*/

    (*count)++;
    AST1 **tmp = realloc(NODES1, (*count) * sizeof(AST1 *));
    if (!tmp)
    {
        printf("Unable to allocate AST Type:[1] tree node\n");
        (*count)--;
        return NODES1;
    }
    return tmp;
}

void parse2(AST1 **node, int count);

void parse1(AST1 ***nodes, int *nodesCount, TOKEN *tokens, int *tokensCount)
{
    int FAIL = 0; // Once the whole parsing is finish, this should be cleared if all is valid (Refering to {} [] ::;; pairs)
    int LEAD = 0;

    AST1 ***SCOPEND = nodes;
    int *CHILDCOUNT = nodesCount;
    AST1 *PARENT = NULL;
    for (int index = 0; index < *tokensCount; index++)
    {
        LEAD = 0;
        if ((index + 1) < *tokensCount)
        {
            if (tokens[index].type == ID && tokens[index + 1].type == SCOPE)
            {
                printf("P1\n");
                FAIL += 1;
                LEAD = 1;
                *SCOPEND = addASTNode(*SCOPEND, CHILDCOUNT);
                (*SCOPEND)[*CHILDCOUNT - 1] = (AST1 *)malloc(sizeof(AST1));
                if ((*SCOPEND)[*CHILDCOUNT - 1] == NULL)
                {
                    printf("Error allocating AST Node\n");
                    return;
                }

                (*SCOPEND)[*CHILDCOUNT - 1]->type = CALL;
                (*SCOPEND)[*CHILDCOUNT - 1]->str = tokens[index].str;
                (*SCOPEND)[*CHILDCOUNT - 1]->token = &tokens[index];
                (*SCOPEND)[*CHILDCOUNT - 1]->childrens = NULL;
                (*SCOPEND)[*CHILDCOUNT - 1]->childCount = 0;
                (*SCOPEND)[*CHILDCOUNT - 1]->parent = PARENT;

                *SCOPEND = addASTNode(*SCOPEND, CHILDCOUNT);
                (*SCOPEND)[*CHILDCOUNT - 1] = (AST1 *)malloc(sizeof(AST1)); // new parent
                if ((*SCOPEND)[*CHILDCOUNT - 1] == NULL)
                {
                    printf("Error allocating AST Node\n");
                    return;
                }

                (*SCOPEND)[*CHILDCOUNT - 1]->type = SCOPE_SEP;
                (*SCOPEND)[*CHILDCOUNT - 1]->str = tokens[index + 1].str;
                (*SCOPEND)[*CHILDCOUNT - 1]->token = &tokens[index + 1];
                (*SCOPEND)[*CHILDCOUNT - 1]->childCount = 0;
                (*SCOPEND)[*CHILDCOUNT - 1]->childrens = NULL;
                (*SCOPEND)[*CHILDCOUNT - 1]->parent = PARENT; // Old parent

                PARENT = (*SCOPEND)[*CHILDCOUNT - 1]; // set new parent
                AST1 ***tmp = SCOPEND;
                SCOPEND = &((*SCOPEND)[*CHILDCOUNT - 1]->childrens);
                CHILDCOUNT = &((*tmp)[*CHILDCOUNT - 1]->childCount);

                printf("TOKEN[%u]: Call [\"%s\"] Arguments ---> \n", index, tokens[index].str);
                index += 1;
                continue;
            }
        }

        if (tokens[index].type == OPERATOR)
        {
            printf("P2\n");
            printf("TOKEN[%u]: Operation '", index);
            int po = index;
            char opStr[4 * 1024];
            int opindex = 0;
            for (; ((po + 1 < *tokensCount) && tokens[po + 1].type != ID && tokens[po].type == OPERATOR); po++)
            {
                opStr[opindex++] = tokens[po].str[0];
            }
            if (po + 1 < *tokensCount)
            {
                if (tokens[po + 1].type == ID && tokens[po].type == OPERATOR)
                    opStr[opindex++] = tokens[po++].str[0];

                opStr[opindex] = 0;

                char *tmpchr = (char *)calloc(opindex + 1, sizeof(char));

                memcpy(tmpchr, opStr, opindex + 1);

                *SCOPEND = addASTNode(*SCOPEND, CHILDCOUNT);
                (*SCOPEND)[*CHILDCOUNT - 1] = (AST1 *)malloc(sizeof(AST1));
                if ((*SCOPEND)[*CHILDCOUNT - 1] == NULL)
                {
                    printf("Error allocating AST Node\n");
                    return;
                }

                (*SCOPEND)[*CHILDCOUNT - 1]->type = OPERATION;
                (*SCOPEND)[*CHILDCOUNT - 1]->str = tmpchr;
                (*SCOPEND)[*CHILDCOUNT - 1]->token = &tokens[index];
                (*SCOPEND)[*CHILDCOUNT - 1]->childCount = 0;
                (*SCOPEND)[*CHILDCOUNT - 1]->childrens = NULL;
                (*SCOPEND)[*CHILDCOUNT - 1]->parent = PARENT;

                printf("%s", opStr);
                printf("' TO ---> \n");
                index = po;
            }
        }

        if (tokens[index].type == INLINE_OPEN)
        {
            printf("P3A\n");
            FAIL += 2;
            LEAD = 1;

            *SCOPEND = addASTNode(*SCOPEND, CHILDCOUNT);
            (*SCOPEND)[*CHILDCOUNT - 1] = (AST1 *)malloc(sizeof(AST1));
            if ((*SCOPEND)[*CHILDCOUNT - 1] == NULL)
            {
                printf("Error allocating AST Node\n");
                return;
            }

            (*SCOPEND)[*CHILDCOUNT - 1]->type = SCOPE_SEP;
            (*SCOPEND)[*CHILDCOUNT - 1]->str = tokens[index].str;
            (*SCOPEND)[*CHILDCOUNT - 1]->token = &tokens[index];
            (*SCOPEND)[*CHILDCOUNT - 1]->childCount = 0;
            (*SCOPEND)[*CHILDCOUNT - 1]->childrens = NULL;
            (*SCOPEND)[*CHILDCOUNT - 1]->parent = PARENT;

            PARENT = (*SCOPEND)[*CHILDCOUNT - 1];
            AST1 ***tmp = SCOPEND;
            SCOPEND = &((*SCOPEND)[*CHILDCOUNT - 1]->childrens);
            CHILDCOUNT = &((*tmp)[*CHILDCOUNT - 1]->childCount);

            printf("\nTOKEN[%u]: (%p) --> Inline Function ------> [\n\n", index, SCOPEND);
            continue;
        }
        if (tokens[index].type == INLINE_CLOSE)
        {
            printf("P3B\n");
            FAIL -= 2;

            *SCOPEND = addASTNode(*SCOPEND, CHILDCOUNT);
            (*SCOPEND)[*CHILDCOUNT - 1] = (AST1 *)malloc(sizeof(AST1));
            if ((*SCOPEND)[*CHILDCOUNT - 1] == NULL)
            {
                printf("Error allocating AST Node\n");
                return;
            }

            (*SCOPEND)[*CHILDCOUNT - 1]->type = SCOPE_NSEP;
            (*SCOPEND)[*CHILDCOUNT - 1]->str = tokens[index].str;
            (*SCOPEND)[*CHILDCOUNT - 1]->token = &tokens[index];
            (*SCOPEND)[*CHILDCOUNT - 1]->childrens = NULL;
            (*SCOPEND)[*CHILDCOUNT - 1]->childCount = 0;
            (*SCOPEND)[*CHILDCOUNT - 1]->parent = PARENT;

            printf("\n] <-- (%p)", SCOPEND);

            if (PARENT)
            {
                SCOPEND = &(PARENT->childrens);
                CHILDCOUNT = &(PARENT->childCount);
                PARENT = PARENT->parent;
            }
            else
            {
                SCOPEND = nodes;
                CHILDCOUNT = nodesCount;
                PARENT = NULL;
            }

            printf(" <------ Inline Function (%p) -->:TOKEN[%u]\n\n", SCOPEND, index);
            continue;
        }

        if (tokens[index].type == BLOCK_OPEN)
        {
            printf("P3C\n");
            FAIL += 3;
            LEAD = 1;

            *SCOPEND = addASTNode(*SCOPEND, CHILDCOUNT);
            (*SCOPEND)[*CHILDCOUNT - 1] = (AST1 *)malloc(sizeof(AST1));
            if ((*SCOPEND)[*CHILDCOUNT - 1] == NULL)
            {
                printf("Error allocating AST Node\n");
                return;
            }

            (*SCOPEND)[*CHILDCOUNT - 1]->type = SCOPE_SEP;
            (*SCOPEND)[*CHILDCOUNT - 1]->str = tokens[index].str;
            (*SCOPEND)[*CHILDCOUNT - 1]->token = &tokens[index];
            (*SCOPEND)[*CHILDCOUNT - 1]->childCount = 0;
            (*SCOPEND)[*CHILDCOUNT - 1]->childrens = NULL;
            (*SCOPEND)[*CHILDCOUNT - 1]->parent = PARENT;

            PARENT = (*SCOPEND)[*CHILDCOUNT - 1];
            AST1 ***tmp = SCOPEND;
            SCOPEND = &((*SCOPEND)[*CHILDCOUNT - 1]->childrens);
            CHILDCOUNT = &((*tmp)[*CHILDCOUNT - 1]->childCount);

            printf("\nTOKEN[%u]: (%p) --> Block ------> {\n\n", index, SCOPEND);
            continue;
        }
        if (tokens[index].type == BLOCK_CLOSE)
        {
            printf("P3D\n");
            FAIL -= 3;

            *SCOPEND = addASTNode(*SCOPEND, CHILDCOUNT);
            (*SCOPEND)[*CHILDCOUNT - 1] = (AST1 *)malloc(sizeof(AST1));
            if ((*SCOPEND)[*CHILDCOUNT - 1] == NULL)
            {
                printf("Error allocating AST Node\n");
                return;
            }

            (*SCOPEND)[*CHILDCOUNT - 1]->type = SCOPE_NSEP;
            (*SCOPEND)[*CHILDCOUNT - 1]->str = tokens[index].str;
            (*SCOPEND)[*CHILDCOUNT - 1]->token = &tokens[index];
            (*SCOPEND)[*CHILDCOUNT - 1]->childrens = NULL;
            (*SCOPEND)[*CHILDCOUNT - 1]->childCount = 0;
            (*SCOPEND)[*CHILDCOUNT - 1]->parent = PARENT;

            if (PARENT)
            {
                SCOPEND = &(PARENT->childrens);
                CHILDCOUNT = &(PARENT->childCount);
                PARENT = PARENT->parent;
            }
            else
            {
                SCOPEND = nodes;
                CHILDCOUNT = nodesCount;
                PARENT = NULL;
            }

            printf("\n} <------ Block (%p) -->:TOKEN[%u]\n\n", SCOPEND, index);
            continue;
        }

        if (tokens[index].type == ARGUMENT)
        {
            printf("P4\n");
            *SCOPEND = addASTNode(*SCOPEND, CHILDCOUNT);
            (*SCOPEND)[*CHILDCOUNT - 1] = (AST1 *)malloc(sizeof(AST1));
            if ((*SCOPEND)[*CHILDCOUNT - 1] == NULL)
            {
                printf("Error allocating AST Node\n");
                return;
            }

            (*SCOPEND)[*CHILDCOUNT - 1]->type = ARGUMENT_SEP;
            (*SCOPEND)[*CHILDCOUNT - 1]->str = tokens[index].str;
            (*SCOPEND)[*CHILDCOUNT - 1]->token = &tokens[index];
            (*SCOPEND)[*CHILDCOUNT - 1]->childrens = NULL;
            (*SCOPEND)[*CHILDCOUNT - 1]->childCount = 0;
            (*SCOPEND)[*CHILDCOUNT - 1]->parent = PARENT;
            printf("TOKEN[%u]: Function Argument --->\n", index);
            continue;
        }
        if (tokens[index].type == TERMINATOR)
        {
            printf("P5\n");
            FAIL -= 1;

            *SCOPEND = addASTNode(*SCOPEND, CHILDCOUNT);
            (*SCOPEND)[*CHILDCOUNT - 1] = (AST1 *)malloc(sizeof(AST1));
            if ((*SCOPEND)[*CHILDCOUNT - 1] == NULL)
            {
                printf("Error allocating AST Node\n");
                return;
            }

            (*SCOPEND)[*CHILDCOUNT - 1]->type = SCOPE_NSEP;
            (*SCOPEND)[*CHILDCOUNT - 1]->str = tokens[index].str;
            (*SCOPEND)[*CHILDCOUNT - 1]->token = &tokens[index];
            (*SCOPEND)[*CHILDCOUNT - 1]->childrens = NULL;
            (*SCOPEND)[*CHILDCOUNT - 1]->childCount = 0;
            (*SCOPEND)[*CHILDCOUNT - 1]->parent = PARENT;

            if (PARENT)
            {
                SCOPEND = &(PARENT->childrens);
                CHILDCOUNT = &(PARENT->childCount);
                PARENT = PARENT->parent;
            }
            else
            {
                SCOPEND = nodes;
                CHILDCOUNT = nodesCount;
                PARENT = NULL;
            }

            printf("^--- End of Arguments TOKEN[%u]\n", index);
            continue;
        }

        if (tokens[index].type == NEWLINE)
        {
            printf("P6M\n");

            *SCOPEND = addASTNode(*SCOPEND, CHILDCOUNT);
            (*SCOPEND)[*CHILDCOUNT - 1] = (AST1 *)malloc(sizeof(AST1));
            if ((*SCOPEND)[*CHILDCOUNT - 1] == NULL)
            {
                printf("Error allocating AST Node\n");
                return;
            }

            (*SCOPEND)[*CHILDCOUNT - 1]->type = NEWLINE_SEP;
            (*SCOPEND)[*CHILDCOUNT - 1]->str = tokens[index].str;
            (*SCOPEND)[*CHILDCOUNT - 1]->token = &tokens[index];
            (*SCOPEND)[*CHILDCOUNT - 1]->childrens = NULL;
            (*SCOPEND)[*CHILDCOUNT - 1]->childCount = 0;
            (*SCOPEND)[*CHILDCOUNT - 1]->parent = PARENT;

            printf("^--- NewLine TOKEN[%u]\n", index);
            continue;
        }

        if (tokens[index].type == STRING || tokens[index].type == CHARACTER)
        {
            printf("P7\n");

            *SCOPEND = addASTNode(*SCOPEND, CHILDCOUNT);
            (*SCOPEND)[*CHILDCOUNT - 1] = (AST1 *)malloc(sizeof(AST1));
            if ((*SCOPEND)[*CHILDCOUNT - 1] == NULL)
            {
                printf("Error allocating AST Node\n");
                return;
            }

            (*SCOPEND)[*CHILDCOUNT - 1]->type = CHARS_SEP;
            (*SCOPEND)[*CHILDCOUNT - 1]->str = tokens[index].str;
            (*SCOPEND)[*CHILDCOUNT - 1]->token = &tokens[index];
            (*SCOPEND)[*CHILDCOUNT - 1]->childrens = NULL;
            (*SCOPEND)[*CHILDCOUNT - 1]->childCount = 0;
            (*SCOPEND)[*CHILDCOUNT - 1]->parent = PARENT;

            printf("^--- STRING/CHARACTER TOKEN[%u]\n", index);
            continue;
        }

        printf("P8\n");

        *SCOPEND = addASTNode(*SCOPEND, CHILDCOUNT);
        (*SCOPEND)[*CHILDCOUNT - 1] = (AST1 *)malloc(sizeof(AST1));
        if ((*SCOPEND)[*CHILDCOUNT - 1] == NULL)
        {
            printf("Error allocating AST Node\n");
            return;
        }

        (*SCOPEND)[*CHILDCOUNT - 1]->type = IDENTIFIER;
        (*SCOPEND)[*CHILDCOUNT - 1]->str = tokens[index].str;
        (*SCOPEND)[*CHILDCOUNT - 1]->token = &tokens[index];
        (*SCOPEND)[*CHILDCOUNT - 1]->childrens = NULL;
        (*SCOPEND)[*CHILDCOUNT - 1]->childCount = 0;
        (*SCOPEND)[*CHILDCOUNT - 1]->parent = PARENT;

        printf("Undefined Behaviour for TOKEN[%u]:T:%u: ------------> \"%s\"\n", index, tokens[index].type, tokens[index].str);
    }
    printf("FAIL?:%u F:[%d]L:[%u]\n", FAIL || LEAD, FAIL, LEAD);

    if (FAIL || LEAD)
    {
        printf("ERROR: Incomplete Scope\n");
    }

    for (int a = 0; a < 10; a++)
        printf("\n");

    parse2(*nodes, *nodesCount);
}

AST2 *addAST2Node(AST2 *NODES1, int *count)
{
    /*printf("NC:COUNT:[%u]:NODE:[%p] = \n", *count, NODES1);
    for(int i = 0; i < (*count); i++)
        printf("%p;\n", (NODES1) ? NODES1[i]: NULL);
    fflush(stdout);*/

    (*count)++;
    AST2 *tmp = realloc(NODES1, (*count) * sizeof(AST2));
    if (!tmp)
    {
        printf("Unable to allocate AST Type:[1] tree node\n");
        (*count)--;
        return NODES1;
    }
    return tmp;
}

int isUnaryOp(char *str)
{
    switch (str[0])
    {
    case '*':
    case '&':
    case '.':
    case ',':
    case '!':
    case '~':
        return 1;
    default:
        return 0;
    }
}

const char *binOps[] = {"+", "-", "*", "/", "%%", "&", "|", "^", "=", "==", "?", ">", "<", ".", "+=", "-=", "*=", "/=", "%%=", "&=", "|=", "^=", ">=", "<=", "+.", "-.", "*.", "/.", "%%.", "?.", ">.", "<.", ">=.", "<=."};
#define binOpsSize 34

int isBinaryOp(char *str)
{
    for (int i = 0; i < binOpsSize; i++)
        if (!strcmp(str, binOps[i]))
            return 1;
    return 0;
}

AST2 *nodes2 = NULL;
int nodes2Count = 0;

void parse3(AST2 *nodes, int *count);

void parse2(AST1 **nodes, int count)
{
    if (!nodes)
    {
        printf("Error while opening AST1 nodes tree\n");
        return;
    }
    int doingStrings = 0;

    for (int i = 0; i < count; i++)
    {
        if (nodes[i] != NULL)
        {
            if (Verbose >= 4)
                printf("NODE[%u](%p):\"%s\" T:%u\n", i, nodes, nodes[i]->str, nodes[i]->type);

            if (nodes[i]->type == SCOPE_SEP)
            {
                if (Verbose >= 2)
                {
                    if (i != 0 && nodes[i - 1]->type == CALL)
                    {
                        printf("CALL(%s) --->[\n", nodes[i - 1]->str);
                    }
                    else
                        printf("CALL --->[\n");
                }
                nodes2 = addAST2Node(nodes2, &nodes2Count);

                if (!nodes2)
                {
                    printf("Unable to allocate AST2 Node\n");
                    return;
                }

                nodes2[nodes2Count - 1].type = BEG_SEP;
                nodes2[nodes2Count - 1].node = (i != 0 && nodes[i - 1]->type == CALL) ? nodes[i - 1] : nodes[i];

                parse2(nodes[i]->childrens, nodes[i]->childCount);
            }
            else if (nodes[i]->type == CHARS_SEP)
            {
                if (doingStrings)
                {
                    if (Verbose >= 2)
                        printf("<-- CEND\n");
                    doingStrings = 0;
                }
                else
                {
                    if (Verbose >= 2)
                        printf("CONST-->\n");
                    doingStrings = 1;
                }
            }
            else if (nodes[i]->type == IDENTIFIER)
            {
                if (Verbose >= 2)
                    printf("ATOM:\"%s\"\n", nodes[i]->str);

                nodes2 = addAST2Node(nodes2, &nodes2Count);

                if (!nodes2)
                {
                    printf("Unable to allocate AST2 Node\n");
                    return;
                }

                nodes2[nodes2Count - 1].type = ((doingStrings) ? ATOMS : ATOM);
                nodes2[nodes2Count - 1].node = nodes[i];
            }
            else if (nodes[i]->type == SCOPE_NSEP || nodes[i]->type == NEWLINE_SEP)
            {
                nodes2 = addAST2Node(nodes2, &nodes2Count);

                if (!nodes2)
                {
                    printf("Unable to allocate AST2 Node\n");
                    return;
                }

                nodes2[nodes2Count - 1].type = END_SEP;
                nodes2[nodes2Count - 1].node = nodes[i];
                if (Verbose >= 2 && nodes[i]->type == SCOPE_NSEP)
                {
                    printf("]<---\n");
                    return;
                }
                else if (Verbose >= 2 && nodes[i]->type == NEWLINE_SEP)
                    printf("\\n<---\n");
            }

            // UNARY
            if (i == 0 && (i + 1) < count)
            {
                if ((nodes[i]->type == OPERATION) && (nodes[i + 1]->type == IDENTIFIER || nodes[i + 1]->type == SCOPE_SEP))
                {
                    if (!isUnaryOp(nodes[i]->str))
                    {
                        printf("ERROR: Invalid Unary Operation\n");
                    }
                    if (Verbose >= 2)
                        printf("%s", nodes[i]->str);

                    nodes2 = addAST2Node(nodes2, &nodes2Count);

                    if (!nodes2)
                    {
                        printf("Unable to allocate AST2 Node\n");
                        return;
                    }

                    nodes2[nodes2Count - 1].type = UNARY;
                    nodes2[nodes2Count - 1].node = nodes[i];
                }
            }

            // BINARY
            if (i != 0 && (i + 1) < count)
            {
                if ((nodes[i - 1]->type == IDENTIFIER || nodes[i - 1]->type == CHARS_SEP || nodes[i - 1]->type == SCOPE_SEP) && (nodes[i]->type == OPERATION) && (nodes[i + 1]->type == IDENTIFIER || nodes[i + 1]->type == CHARS_SEP || nodes[i + 1]->type == SCOPE_SEP))
                {
                    if (!isBinaryOp(nodes[i]->str))
                    {
                        printf("ERROR: Invalid Binary Operation\n");
                    }
                    if (Verbose >= 2)
                        printf("%s\n", nodes[i]->str);

                    nodes2 = addAST2Node(nodes2, &nodes2Count);

                    if (!nodes2)
                    {
                        printf("Unable to allocate AST2 Node\n");
                        return;
                    }

                    nodes2[nodes2Count - 1].type = BINARY;
                    nodes2[nodes2Count - 1].node = nodes[i];
                }
            }

            // CAST
            if (i != 0)
            {
                if ((nodes[i - 1]->type == IDENTIFIER || nodes[i - 1]->type == SCOPE_SEP) && nodes[i]->type == SCOPE_SEP)
                {
                    if (Verbose >= 2)
                        printf("└─ CAST --->\n");

                    nodes2 = addAST2Node(nodes2, &nodes2Count);

                    if (!nodes2)
                    {
                        printf("Unable to allocate AST2 Node\n");
                        return;
                    }

                    nodes2[nodes2Count - 1].type = CAST;
                    nodes2[nodes2Count - 1].node = nodes[i];
                }
            }
        }
    }
    if (nodes[0]->parent == NULL)
    {
        printf("\n\n\n\n");
        for (int i = 0; i < nodes2Count; i++)
        {
            printf("AST2[%u]: Type: ", i);
            switch (nodes2[i].type)
            {
            case ATOM:
                printf("ATOM\n");
                break;
            case ATOMS:
                printf("ATOMS\n");
                break;
            case CAST:
                printf("CAST\n");
                break;
            case UNARY:
                printf("UNARY\n");
                break;
            case BINARY:
                printf("BINARY\n");
                break;
            case BEG_SEP:
                printf("BEG_SEP\n");
                break;
            case END_SEP:
                printf("END_SEP\n");
                break;
            default:
                printf("NAT\n");
                break;
            }
        }
        printf("\n\n\n\n");
        parse3(nodes2, &nodes2Count);
    }
}

/* cheat table:

    ATOM [a] | a
    CAST a[] | [][]
    UNARY [ OP a | [ OP [
    BINARY ] OP [ | a OP b | a OP [ | ] OP b

*/

IDENT *addIdentifier(IDENT *NODES1, int *count)
{
    /*printf("NC:COUNT:[%u]:NODE:[%p] = \n", *count, NODES1);
    for(int i = 0; i < (*count); i++)
        printf("%p;\n", (NODES1) ? NODES1[i]: NULL);
    fflush(stdout);*/

    (*count)++;
    IDENT *tmp = realloc(NODES1, (*count) * sizeof(IDENT));
    if (!tmp)
    {
        printf("Unable to allocate AST Type:[1] tree node\n");
        (*count)--;
        return NODES1;
    }
    return tmp;
}

const char *primitives[] = {"u8", "u16", "u32", "u64", "i8", "i16", "i32", "i64", "padd8", "padd16", "padd32", "padd64", "ptr", "word", "byte", "void"};
#define primitivesCount 16

int getcastType(char *str)
{
    for (int i = 0; i < primitivesCount; i++)
        if (!strcmp(str, primitives[i]))
            switch (i)
            {
            case 0:
                return U8;
            case 1:
                return U16;
            case 2:
                return U32;
            case 3:
                return U64;
            case 4:
                return I8;
            case 5:
                return I16;
            case 6:
                return I32;
            case 7:
                return I64;
            case 8:
                return PADD8;
            case 9:
                return PADD16;
            case 10:
                return PADD32;
            case 11:
                return PADD64;
            case 12:
                return PTR;
            case 13:
                return WORD;
            case 14:
                return BYTE;
            case 15:
                return VOID;
            }
    /*for (int i = 0; i < count; i++)
        if (!strcmp(str, ident[i].node->node->str))
            return ident[i].type;
    */
    return 0;
}

int getIdentType(char *str, IDENT *ident, int count)
{
    for (int i = 0; i < primitivesCount; i++)
        if (!strcmp(str, primitives[i]))
            switch (i)
            {
            case 0:
                return U8;
            case 1:
                return U16;
            case 2:
                return U32;
            case 3:
                return U64;
            case 4:
                return I8;
            case 5:
                return I16;
            case 6:
                return I32;
            case 7:
                return I64;
            case 8:
                return PADD8;
            case 9:
                return PADD16;
            case 10:
                return PADD32;
            case 11:
                return PADD64;
            case 12:
                return PTR;
            case 13:
                return WORD;
            case 14:
                return BYTE;
            case 15:
                return VOID;
            }
    for (int i = 0; i < count; i++)
        if (!strcmp(str, ident[i].node->node->str))
            return ident[i].type;
    return 1;
}

IDENT *identifiers = NULL;
int identifiersCount = 0;

int isNotDefined(char *str, IDENT *ident, int count)
{
    for (int i = 0; i < primitivesCount; i++)
        if (!strcmp(str, primitives[i]))
            return 0;

    for (int i = 0; i < count; i++)
        if (!strcmp(str, ident[i].node->node->str))
            return 0;
    return 1;
}

int getIdentifierIndex(char *str, IDENT *ident, int count)
{
    for (int i = 0; i < count; i++)
        if (!strcmp(str, ident[i].node->node->str))
            return i;
    return -1;
}

int isConstant(char *str)
{
    if (!str)
        return 0;

    int isHex = 0;
    for (int i = 0; str[i]; i++)
    {
        switch (str[i])
        {
        case 'U':
        case 'I':
        case 'B':
        case 'X':
            if (!str[i + 1])
            {
                if (isHex && str[i] != 'X')
                    return 0;
                return 1;
            }
            else if (str[i] == 'B')
                isHex = 1;
            else
                return 0;
            break;
        case 'A':
        case 'C':
        case 'D':
        case 'E':
        case 'F':
            isHex = 1;
            break;
        default:
            if ((str[i] - '0') >= 10)
                return 0;
        }
    }
    return 0;
}

void parse3(AST2 *nodes, int *count)
{
    int insideness = 0;
    int m = 0;
    for (int i = 0; i < *count; i++)
    {
        if (Verbose >= 4)
            printf("%s\n", nodes[i].node->str);

        if (nodes[i].type == BEG_SEP && !strcmp(nodes[i].node->str, "Open"))
        {
            if ((i + 1) >= *count)
            {
                printf("ERROR: Invalid Function Declaration (Missing Label)\n");
                return;
            }
            printf("Fun Def \"%s\"\n", nodes[i + 1].node->str);
            i = i + 2;
            m = i;
        }
        else if (nodes[i].type == BEG_SEP && !strcmp(nodes[i].node->str, "Close"))
        {
            printf("Fun Closure\n");
            m = i;
        }
        else if (nodes[i].type == BEG_SEP && !strcmp(nodes[i].node->str, "Typedef"))
        {
            printf("Def Type\n");
            while (i < *count && nodes[i].type != NEWLINE_SEP)
                ;
            m = i;
        }
        else if (nodes[i].type == BEG_SEP && !strcmp(nodes[i].node->str, "Inport"))
        {
            printf("Import Simbols\n");
            m = i;
        }
        else if (nodes[i].type == BEG_SEP && !strcmp(nodes[i].node->str, "Export"))
        {
            printf("Def Type\n");
            m = i;
        }

        if (nodes[i].type == BEG_SEP)
        {
            insideness++;
        }
        else if (nodes[i].type == END_SEP && nodes[i].node->str[0] == '\n' && insideness)
        {
            if (m < 0 || m >= i)
            {
                insideness = 0;
                return;
            }

            int casting = 0;
            int cast_t = 0;

            int binaring = 0;
            int binary_i = 0;

            int conditioning = 0;
            int conditioning_i = 0;

            for (int j = i; j > m && j > 0; j--)
            {
                if (insideness > 0)
                    insideness--;
                if (nodes[j].type != BEG_SEP && nodes[j].type != END_SEP)
                {
                    if (nodes[j].type == ATOM && isNotDefined(nodes[j].node->str, identifiers, identifiersCount) && !isConstant(nodes[j].node->str))
                    {
                        identifiers = addIdentifier(identifiers, &identifiersCount);

                        identifiers[identifiersCount - 1].node = &nodes[j];
                        if (!casting)
                            identifiers[identifiersCount - 1].type = PTR;
                        else
                            identifiers[identifiersCount - 1].type = cast_t;

                        identifiers[identifiersCount - 1].isTypeDef = 0;
                        int processBaseOffset = 1;
                        for (int m = identifiersCount - 2; m >= 0 && m < identifiersCount; m--)
                        {
                            if (!identifiers[m].isTypeDef)
                            {
                                identifiers[identifiersCount - 1].offset = ((identifiers[m].offset + identifiers[m].type) + (identifiers[identifiersCount - 1].type - 1)) & ~(identifiers[identifiersCount - 1].type - 1);
                                processBaseOffset = 0;
                                break;
                            }
                        }
                        if (processBaseOffset)
                        {
                            identifiers[identifiersCount - 1].offset = 0;
                            processBaseOffset = 0;
                        }

                        if (!casting)
                        {
                            printf("Var Def Ptr \"%s\" At off:0x%x\n", nodes[j].node->str, identifiers[identifiersCount - 1].offset);
                        }
                        else
                        {
                            printf("def_");
                        }
                    }

                    if (nodes[j].type == CAST)
                    {
                        printf("t%%%u = cast_", (binaring));
                        casting = 2;
                    }
                    else if (casting == 2)
                    {
                        printf("%s_", nodes[j].node->str);
                        cast_t = getcastType(nodes[j].node->str);
                        casting = 1;
                    }
                    else if (casting == 1)
                    {
                        int index = getIdentifierIndex(nodes[j].node->str, identifiers, identifiersCount);
                        if (index != -1)
                            printf("((%s) at 0x%x)\n", nodes[j].node->str, identifiers[index].offset);
                        else
                            printf("(%s)\n", nodes[j].node->str);
                        casting = 0;
                    }
                    else if (nodes[j].type == UNARY)
                    {
                        if (binaring)
                            printf("t%%0 = t%%1 %s t%%0\n", nodes[binary_i].node->str);
                        binaring = 0;

                        printf("t%%0 = %st%%0\n", nodes[j].node->str);
                    }
                    else if (nodes[j].type == BINARY)
                    {
                        if (binaring)
                            printf("t%%0 = t%%1 %s t%%0\n", nodes[binary_i].node->str);

                        if (!strcmp(nodes[j].node->str, "?"))
                        {
                            if ((j - 1) > m && (j - 1) > 0)
                            {
                                if (nodes[j - 1].type != ATOM)
                                    conditioning = 1;
                                else
                                    conditioning = 2;
                            }
                            printf("If t%%0 Then:\n");
                            binaring = 0;
                        }
                        else
                        {
                            binaring = 1;
                            binary_i = j;
                        }
                    }
                    else
                    {
                        if (isConstant(nodes[j].node->str) || nodes[j].type == ATOMS)
                        {
                            if (conditioning == 2)
                            {
                                printf("EndIf\n");
                                conditioning = 0;
                            }
                            if (nodes[j].type == ATOMS)
                                printf("t%%%u = T8B(\"%s\")\n", (binaring), nodes[j].node->str);
                            else
                                printf("t%%%u = (%s)\n", (binaring), nodes[j].node->str);
                        }
                        else
                        {
                            int index = getIdentifierIndex(nodes[j].node->str, identifiers, identifiersCount);
                            if (index != -1)
                                printf("t%%%u = T%uB(%s) at 0x%x\n", (binaring), getIdentType(nodes[j].node->str, identifiers, identifiersCount), nodes[j].node->str, identifiers[index].offset);
                            else
                                printf("t%%%u = T%uB(%s)\n", (binaring), getIdentType(nodes[j].node->str, identifiers, identifiersCount), nodes[j].node->str);
                        }
                    }
                }
                else if (nodes[j].type == BEG_SEP)
                {
                    if (conditioning_i && conditioning)
                    {
                        conditioning_i--;
                    }
                    if (!conditioning_i && conditioning)
                    {
                        conditioning = 0;
                        printf("EndIf\n");
                    }
                }
                else if (conditioning)
                    conditioning_i++;
            }
            if (binaring)
                printf("t%%0 = t%%1 %s t%%0\n", nodes[binary_i].node->str);
            if (conditioning)
                printf("EndIf\n");
            m = i;
            printf("______\n");
        }
    }
}