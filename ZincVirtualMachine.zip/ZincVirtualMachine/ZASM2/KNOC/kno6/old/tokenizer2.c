#include "tokenize.h"

extern int Verbose;

long getFileSize(FILE *file)
{
    long position = ftell(file);
    fseek(file, 0, SEEK_END);
    long fileSize = ftell(file);     // get the file size
    fseek(file, position, SEEK_SET); // set back to last position

    return fileSize;
}
int addToken(TOKEN **tokensList, int *tokenCount, TOKEN token)
{
    (*tokenCount)++;

    TOKEN *tmp = (TOKEN *)realloc(*tokensList, sizeof(TOKEN) * (*tokenCount)); // Allocate a new elements

    if (!tmp)
    {
        printf("Unable to create tokensList\n");
        (*tokenCount)--;
        return 1;
    }
    *tokensList = tmp; // set tokensList to new array

    (*tokensList)[(*tokenCount) - 1].type = token.type; // set new element to token
    (*tokensList)[(*tokenCount) - 1].str = token.str;
    (*tokensList)[(*tokenCount) - 1].y = token.y;

    return 0;
}
void emitToken(TOKEN **tokensList, int *tokenCount, char **token, int *tokenIndex, const char *str2in, int bufferYIndex, TOKEN_TYPE TYPE)
{
    char *str1 = NULL;

    if ((*tokenIndex) > 0 && (*token)[0] != 0) // If Token Str isnt empty
    {
        str1 = malloc(sizeof(char) * ((*tokenIndex) + 1));

        if (!str1)
            printf("Unable to create string\n");
        else
        {
            strcpy(str1, (*token));
            if (Verbose >= 3)
                printf("STR1:\"%s\"\n", str1);
        }
    }

    (*token)[0] = 0; // Reset Token Str
    (*tokenIndex) = 0;

    char *str2 = NULL;
    str2 = malloc(sizeof(char) * (strlen(str2in) + 1));

    if (!str2)
        printf("Unable to create string\n");
    else
    {
        strcpy(str2, str2in);
        if (Verbose >= 3)
                printf("STR2:\"%s\"\n", str2);
    }

    TOKEN opToken = {TYPE, str2, bufferYIndex};

    if (str1)
    {
        TOKEN idToken = {ID, str1, bufferYIndex};
        addToken(tokensList, tokenCount, idToken);
    }

    addToken(tokensList, tokenCount, opToken);
}
int opType(int size, char *str)
{
    int TYPE = ID;
    if (size == 1)
    {
        switch (str[0])
        {
        case ':':
            TYPE = ARGUMENT;
            break;
        case '[':
            TYPE = INLINE_OPEN;
            break;
        case ']':
            TYPE = INLINE_CLOSE;
            break;
        case '{':
            TYPE = BLOCK_OPEN;
            break;
        case '}':
            TYPE = BLOCK_CLOSE;
            break;
        case '\"':
            TYPE = STRING;
            break;
        case '\'':
            TYPE = CHARACTER;
            break;
        case '+':
        case '-':
        case '=':
        case '*':
        case '%':
        case '>':
        case '<':
        case '?':
        case '&':
        case '^':
        case '!':
        case '~':
        case '|':
        case '.':
        case ',':
            TYPE = OPERATOR;
            break;
        case '\n':
            TYPE = NEWLINE;
            break;
        default:
            TYPE = ID;
            break;
        }
    }
    else if (size == 2)
    {
        if (!strcmp(str, "::"))
            TYPE = SCOPE;
        else if (!strcmp(str, ";;"))
            TYPE = TERMINATOR;
    }
    return TYPE;
}
int isValid(void *ptr, const char *msg, ...)
{
    if (!ptr && msg)
    {
        va_list list;
        va_start(list, msg);

        vprintf(msg, list);
        printf("\n");

        va_end(list);
    }
    return (ptr) ? 0 : 1;
}

int tokenize(FILE *file, TOKEN **tokensList, int *tokenCount, int bufferSize, int tokenStringSize)
{
    if (isValid(file, "Unable to access file"))
        return 1;
    if (isValid(tokenCount, "Unable to read Token Count"))
        return 1;

    long fileSize = getFileSize(file); // this has internal checks to return to original fseek

    if (Verbose >= 5)
        printf("FileSize:[%ld]\n", fileSize);

    char *buffer = (char *)malloc(bufferSize * sizeof(char));

    if (isValid(buffer, "Unable to open buffer"))
        return 1;

    int tokenIndex = 0; // index for token str
    char *tokenStr = malloc(sizeof(char) * tokenStringSize);

    if (isValid(tokenStr, "Unable to create tokenStr"))
        return 1;

    int bufferSectionIndex = 0;
    int bufferYIndex = 1; // index inc per each '\n'

    // Components for string and char tokenizing
    int doStringSpaceTrim = 0;
    int doCharacterSpaceTrim = 0;

    // Components for comment processing
    int doCommentTrim = 0;

    // Control flow ceiling rounding base value
    int averageFileSize = (fileSize + bufferSize - 1);

    while (bufferSectionIndex < (averageFileSize / bufferSize))
    {
        size_t readBytes = 0;
        if ((readBytes = (fread(buffer, sizeof(char), bufferSize, file))) == 0)
        {
            if (feof(file))
            {
                bufferSectionIndex = (averageFileSize / bufferSize); // make sure the code exist ONLY out of the loop.
                continue;
            }
            else
            {
                if (isValid(NULL, "Unable to read file"))
                    return 1;
            }
        }

        if (Verbose >= 5)
            printf("ReadBytes:[%ld]\n", readBytes);

        int isBufferEnd = 0;

        for (int index = 0; index < bufferSize; index++)
        {
            isBufferEnd = ((index + 1) >= bufferSize);

            if (buffer[index] == '\n')
            {
                bufferYIndex++;
                if (Verbose >= 5)
                    printf("bufferYIndex:[%d]\n", bufferYIndex);
            }

            if (buffer[index] == '#' || doCommentTrim) // Coment checking section
            {
                doCommentTrim = 1;
                if (!isBufferEnd)
                {
                    if (buffer[index + 1] == '/')
                    { // Block Comments '#/' '#\'
                        while (buffer[++index] != '#' && buffer[index + (((index + 1) < bufferSize) ? index + 1 : index)] != '\\')
                        {
                            if (index < bufferSize)
                                continue;
                            break;
                        }
                        index++;
                        doCommentTrim = 0;
                        continue;
                    }

                    while (buffer[++index] != '\n')
                    {
                        if (index < bufferSize)
                            continue;
                        break;
                    }
                    doCommentTrim = 0;
                    continue;
                }
            }

            // replace all this logic here to mv the last chars to the buffer start, and read only what can be read.

#define OPLENGTH 2
#define opFitBuffer ((index + (OPLENGTH - 1)) >= bufferSize)
#define opLenIfOverflow (bufferSize - index)

            int TYPE = ID;
            int opLen = ((!opFitBuffer) ? OPLENGTH : opLenIfOverflow) + 1;
            char str[OPLENGTH + 1] = {0};

            do
            {
                opLen--;
                for (int i = 0; i < opLen; i++)
                {
                    str[i] = buffer[index + i];
                    str[i + 1] = 0;
                }
                TYPE = opType(opLen, str);
            } while (TYPE == ID && opLen > 1);

            if (TYPE != ID)
            {
                int process = 1;
                switch (TYPE)
                {
                case STRING:
                    if (!doCharacterSpaceTrim)
                    {
                        doStringSpaceTrim = ~doStringSpaceTrim;
                        process = 0;
                    }
                    break;
                case CHARACTER:
                    if (!doStringSpaceTrim)
                    {
                        doCharacterSpaceTrim = ~doCharacterSpaceTrim;
                        process = 0;
                    }
                    break;
                }

                if ((doCharacterSpaceTrim || doStringSpaceTrim) && process) // If Inside a string or character, Do not process as operation
                {
                    if ((tokenIndex + (opLen + 1)) < tokenStringSize)
                    {
                        strcat(tokenStr, str);
                        tokenIndex += (opLen);
                        index += (opLen - 1);
                        continue;
                    }
                    if (Verbose >= 3)
                        printf("token buffer full\n");
                    index++;
                    continue;
                }

                emitToken(tokensList, tokenCount, &tokenStr, &tokenIndex, str, bufferYIndex, TYPE);
                index += (opLen - 1);
                continue;
            }

            if ((tokenIndex + 2) < tokenStringSize && (buffer[index] != ' ' && buffer[index] != '\n' || doStringSpaceTrim || doStringSpaceTrim))
            {
                tokenStr[tokenIndex++] = buffer[index];
                tokenStr[tokenIndex] = 0;
            }
        }

        bufferSectionIndex++;
    }

    char *str1 = NULL;

    if (tokenIndex > 0 && tokenStr[0] != 0) // If Token Str isnt empty
    {
        str1 = malloc(sizeof(char) * (tokenIndex + 1));

        if (!str1)
            printf("Unable to create string\n");
        else
        {
            strcpy(str1, tokenStr);

            if (Verbose >= 3)
                printf("STR1:\"%s\"\n", str1);
        }
    }

    TOKEN idToken = {ID, str1, bufferYIndex};

    if (str1)
        addToken(tokensList, tokenCount, idToken);

    if (Verbose >= 6)
    {
        printf("TKC:[%d]\n", (*tokenCount));
        for (int i = 0; i < (*tokenCount); i++)
            printf("TOKEN[%d]:T:[%02d]S:[%s]\n", i, (*tokensList)[i].type, (*tokensList)[i].str);
    }

    free(tokenStr);
    free(buffer);
    fclose(file);

    printf("--- TOKENIZER END ---\n");

    return 0;
}