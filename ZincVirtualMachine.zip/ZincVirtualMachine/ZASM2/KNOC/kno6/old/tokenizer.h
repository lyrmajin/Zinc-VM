#ifndef TOKENIZER_H
#define TOKENIZER_H

int tokenizer(FILE *file);
void parse1();

#endif // TOKENIZER_H