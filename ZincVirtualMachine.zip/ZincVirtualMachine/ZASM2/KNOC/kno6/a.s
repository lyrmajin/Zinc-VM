	.text
	.file	"a.ll"
	.section	.text._start,"axR",@progbits
	.globl	_start
	.p2align	4, 0x90
	.type	_start,@function
_start:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	xorl	%edi, %edi
	xorl	%esi, %esi
	movq	%rbp, %rdx
	callq	main@PLT
	movl	$60, %eax
	xorl	%edi, %edi
	#APP
	syscall
	#NO_APP
.Lfunc_end0:
	.size	_start, .Lfunc_end0-_start
	.cfi_endproc

	.text
	.globl	main
	.p2align	4, 0x90
	.type	main,@function
main:
	.cfi_startproc
	retq
.Lfunc_end1:
	.size	main, .Lfunc_end1-main
	.cfi_endproc

	.section	".note.GNU-stack","",@progbits
