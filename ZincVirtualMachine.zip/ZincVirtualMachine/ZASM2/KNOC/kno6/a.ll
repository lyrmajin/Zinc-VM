target triple = "x86_64-pc-linux-gnu"
@llvm.used = appending global [1 x i8*] [i8* bitcast (void ()* @_start to i8*)]

declare i8* @llvm.frameaddress(i32)

define dso_local void @_start() {
entry:
    %fp = call i8* @llvm.frameaddress(i32 0)
    call void @main(i8* null, i8* null, i8* %fp)
    call void asm sideeffect "syscall", "{rax},{rdi},~{rcx},~{r11}"(i64 60, i64 0)
    unreachable
}


define void @main(i8* %aptr, i8* %rptr, i8* %fptr) {
entry:

    ret void
}
