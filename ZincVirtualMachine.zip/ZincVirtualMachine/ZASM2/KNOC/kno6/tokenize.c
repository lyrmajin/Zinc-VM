#include "tokenize.h"

extern int Verbose;

TOKEN *addTokens(TOKEN *tokens, int *tokensCount)
{
    (*tokensCount)++;

    TOKEN *tmp = realloc(tokens, sizeof(TOKEN) * (*tokensCount));

    if (!tmp)
    {
        printf("Unable to create tokensList\n");
        (*tokensCount)--;
        return tokens;
    }
    return tmp;
}

void addToken(TOKEN **tokens, int *tokensCount, char *str, int x, int y, TOKEN_TYPE type)
{
    *tokens = addTokens(*tokens, tokensCount);

    if (!(*tokens))
    {
        printf("Unable to allocate Tokens\n");
        return;
    }

    (*tokens)[*tokensCount - 1].str = str;
    (*tokens)[*tokensCount - 1].type = type;
    (*tokens)[*tokensCount - 1].x = x;
    (*tokens)[*tokensCount - 1].y = y;
}

char *allocTokenStr(char *buffer)
{
    char *tmp = (char *)malloc(sizeof(char) * strlen(buffer) + 1);
    if (!tmp)
    {
        printf("Unable to allocate Token String\n");
        return NULL;
    }
    strcpy(tmp, buffer);
    return tmp;
}

int getType(char c)
{
    int type = IDENTIFIER;
    switch (c)
    {
    case ':':
        type = FUNCTION_OPEN;
        break;
    case ';':
        type = FUNCTION_CLOSE;
        break;
    case '[':
        type = INLINE_OPEN;
        break;
    case ']':
        type = INLINE_CLOSE;
        break;
    case '{':
        type = BLOCK_OPEN;
        break;
    case '}':
        type = BLOCK_CLOSE;
        break;
    case '\"':
        type = STRING;
        break;
    case '\'':
        type = CHARACTER;
        break;
    case '\\':
        type = BREAK;
        break;
    case '\n':
        type = NEWLINE;
        break;
    case '#':
        type = COMMENT;
        break;
    case ' ':
        type = SPACE;
        break;
    case '+':
    case '-':
    case '=':
    case '*':
    case '%':
    case '>':
    case '<':
    case '?':
    case '&':
    case '^':
    case '!':
    case '~':
    case '|':
    case '.':
    case ',':
        type = OPERATOR;
        break;
    default:
        type = IDENTIFIER;
        break;
    }
    return type;
}

int isTokenStrValidity(char *str, TOKEN_TYPE type)
{
    switch (type)
    {
    case FUNCTION_OPEN:
        return (!strcmp(str, "::") || !strcmp(str, ":"));
    case FUNCTION_CLOSE:
        return (!strcmp(str, ";;"));
    default:
        return 1;
    }
}

int isDividibleNeedfull(TOKEN_TYPE type)
{
    switch (type)
    {
    case INLINE_OPEN:
    case INLINE_CLOSE:
    case BLOCK_OPEN:
    case BLOCK_CLOSE:
        return 1;
    default:
        return 0;
    }
}

#define tokenStrBufferSize 1024
#define bufferSize 1024

int tokenize(FILE *file, int fileSize, TOKEN **tokens, int *tokensCount)
{
    if (Verbose >= 1)
        printf("--- TOKENIZER START ---\n");

    if (!file || !tokensCount)
    {
        printf("Internal Unresolved Error\n");
        return 1;
    }

    if (!fileSize)
        return 0;

    char *tokenStrBuffer = (char *)malloc(sizeof(char) * tokenStrBufferSize);
    char *buffer = (char *)malloc(sizeof(char) * bufferSize);

    if (!tokenStrBuffer || !buffer)
    {
        printf("Unable to create internal buffers\n");
        return 1;
    }

    int tokenStrBufferIndex = 0;

    int xFileIndex = 1;
    int yFileIndex = 1;

    int doCommentTrim = 0;
    int doChar = 0;
    int doString = 0;
    int doSpaceTrim = 1;
    int doSpecialScape = 0;

    int lastType = 0;

    int fileIndex = 0;

    while (fileIndex < fileSize)
    {
        int remainder = (fileSize - fileIndex);
        int writtenToBuffer = (((fileIndex + bufferSize) < fileSize) ? bufferSize : remainder);

        if (!fread(buffer, sizeof(char), writtenToBuffer, file))
        {
            printf("File Read Error\n");
            return 1;
        }

        int bufferIndex = 0;

        for (; bufferIndex < (writtenToBuffer); bufferIndex++)
        {
            char tokenChar = buffer[bufferIndex];
            int tokenType = getType(tokenChar);

            if (tokenType == NEWLINE)
            {
                xFileIndex = 1;
                yFileIndex++;

                if (doString)
                {
                    printf("Newline in string literal\n");
                    return 1;
                }
                else if (doChar)
                {
                    printf("Newline in character literal\n");
                    return 1;
                }
            }

            if (doCommentTrim && tokenType == NEWLINE)
                doCommentTrim = 0;

            if (doCommentTrim)
                continue;

            if (tokenType == SPACE && doSpaceTrim)
            {
                continue;
            }

            if (tokenType == COMMENT)
            {
                doCommentTrim = 1;
                continue;
            }

            if (tokenType == BREAK)
            {
                if (!doSpecialScape)
                {
                    doSpecialScape = 1;
                    continue;
                }
                else
                    doSpecialScape = 0;
            }

            // flushing last token if the buffer isnt empty, and we arent processing a string or character

            if ((lastType != tokenType && !doString && !doChar) || isDividibleNeedfull(tokenType) && tokenStrBufferIndex && !doString && !doChar)
            {
                char *allocatedTokenStr = allocTokenStr(tokenStrBuffer);

                if (!isTokenStrValidity(allocatedTokenStr, lastType))
                {
                    printf("%u:%u: ERROR: Invalid Token (%s)\n", yFileIndex, xFileIndex + tokenStrBufferIndex, allocatedTokenStr);
                    return 1;
                }

                addToken(tokens, tokensCount, allocatedTokenStr, xFileIndex, yFileIndex, ((!strcmp(allocatedTokenStr, ":")) ? ARGUMENT : lastType));

                xFileIndex += tokenStrBufferIndex;
                lastType = tokenType;
                tokenStrBufferIndex = 0;

                if (Verbose >= 4)
                    printf("[TK:%4u] ", *tokensCount - 1);
                if (Verbose >= 3)
                    printf("(%s)\n", ((!strcmp(allocatedTokenStr, "\n")) ? "\\n" : allocatedTokenStr));
            }

            // String Lexing

            if (tokenType == STRING && !doChar)
            {
                if (!doSpecialScape)
                {
                    doString = !doString;
                    doSpaceTrim = !doSpaceTrim;
                    lastType = STRING;
                    continue; // skip (")
                }
                else
                    doSpecialScape = 0;
            }
            if (tokenType == CHARACTER && !doString)
            {
                if (!doSpecialScape)
                {
                    doChar = !doChar;
                    doSpaceTrim = !doSpaceTrim;
                    lastType = CHARACTER;
                    continue; // skip (')
                }
                else
                    doSpecialScape = 0;
            }

            // Addiing new char to the buffer

            if (tokenStrBufferIndex < (tokenStrBufferSize - 1))
            {
                tokenStrBuffer[tokenStrBufferIndex++] = tokenChar;
                tokenStrBuffer[tokenStrBufferIndex] = 0;
            }
            else
            {
                printf("%u:%u: ERROR: String too long\n", yFileIndex, xFileIndex);
                return 1;
            }
        }

        // after buffer was used succesfully

        fileIndex += bufferIndex;
    }

    if (tokenStrBufferIndex)
    {
        char *allocatedTokenStr = allocTokenStr(tokenStrBuffer);

        if (!isTokenStrValidity(allocatedTokenStr, lastType))
        {
            printf("%u:%u: ERROR: Invalid Token (%s)\n", yFileIndex, xFileIndex + tokenStrBufferIndex, allocatedTokenStr);
            return 1;
        }

        addToken(tokens, tokensCount, allocatedTokenStr, xFileIndex, yFileIndex, ((!strcmp(allocatedTokenStr, ":")) ? ARGUMENT : lastType));

        if (Verbose >= 4)
            printf("[TK:%4u] ", *tokensCount - 1);
        if (Verbose >= 3)
            printf("(%s)\n", ((!strcmp(allocatedTokenStr, "\n")) ? "\\n" : allocatedTokenStr));
    }

    if (Verbose >= 1)
        printf("--- TOKENIZER END ---\n");

    return 0;
}