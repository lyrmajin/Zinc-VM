#include "parse.h"
#include "tokenize.h"

extern int Verbose;

void debug(const char *tc, const char *op, const char *str, int index, int verbosity, int depth)
{
    if (verbosity >= 4)
        printf("(%s)", tc);
    if (verbosity >= 5)
        printf("[TK:%4u]", index);
    // if (verbosity >= 6)
    //     printf("[ND:%16p]", NULL);

    for (int i = 0; i < depth; i++)
        printf("    ");

    if (verbosity >= 2 && verbosity < 3)
        printf("(%s)\n", str);
    else if (verbosity >= 3)
        printf("(%s)(%s)\n", op, str);
}

void *srealloc(void *nodes, int *count, int size)
{
    (*count)++;
    void *tmp = realloc(nodes, (*count) * size);
    if (!tmp)
    {
        printf("Error: Unable to allocate element\n");
        (*count)--;
        return nodes;
    }
    return tmp;
}

void addASTNode(AST1 ***nodes, int *nodesCount, TOKEN *token, AST1_TYPE type)
{
    *nodes = srealloc(*nodes, nodesCount, sizeof(AST1 *));
    (*nodes)[*nodesCount - 1] = malloc(sizeof(AST1));

    if ((*nodes)[*nodesCount - 1] == NULL)
    {
        printf("Error allocating AST Node\n");
        return;
    }

    (*nodes)[*nodesCount - 1]->type = type;
    (*nodes)[*nodesCount - 1]->str = token->str;
    (*nodes)[*nodesCount - 1]->token = token;
}

int parse1(TOKEN *tokens, int *tokensCount, AST1 ***nodes, int *nodesCount)
{
    if (Verbose >= 1)
        printf("--- PARSER START ---\n");

    if (!tokens)
    {
        printf("Error: Unable to read Tokens\n");
        return 1;
    }

    int depth = 0;

    for (int index = 0; index < *tokensCount; index++)
    {
        if ((index + 1) < *tokensCount)
        {
            if (tokens[index].type == IDENTIFIER && tokens[index + 1].type == FUNCTION_OPEN)
            {
                debug("TC0A", "FUNCTION_OPEN", tokens[index].str, index, Verbose, depth);
                addASTNode(nodes, nodesCount, &tokens[index], CALL);
                addASTNode(nodes, nodesCount, &tokens[index + 1], SCOPE_SEP);
                index += 1;
                continue;
            }
        }

        if (tokens[index].type == ARGUMENT)
        {
            debug("TC0B", "ARGUMENT", tokens[index].str, index, Verbose, depth);
            addASTNode(nodes, nodesCount, &tokens[index], ARGUMENT_SEP);
            continue;
        }

        if (tokens[index].type == OPERATOR)
        {
            debug("TC1 ", "OPERATOR", tokens[index].str, index, Verbose, depth);
            addASTNode(nodes, nodesCount, &tokens[index], OPERATION);
            continue;
        }

        if (tokens[index].type == INLINE_OPEN)
        {
            debug("TC2A", "OPEN", tokens[index].str, index, Verbose, depth++);
            addASTNode(nodes, nodesCount, &tokens[index], SCOPE_SEP);
            continue;
        }

        if (tokens[index].type == INLINE_CLOSE)
        {
            debug("TC2B", "CLOSE", tokens[index].str, index, Verbose, depth--);
            addASTNode(nodes, nodesCount, &tokens[index], SCOPE_NSEP);
            continue;
        }

        if (tokens[index].type == BLOCK_OPEN)
        {

            debug("TC3A", "OPEN", tokens[index].str, index, Verbose, depth++);
            addASTNode(nodes, nodesCount, &tokens[index], SCOPE_SEP);
            continue;
        }

        if (tokens[index].type == BLOCK_CLOSE)
        {
            debug("TC3B", "CLOSE", tokens[index].str, index, Verbose, depth--);
            addASTNode(nodes, nodesCount, &tokens[index], SCOPE_NSEP);
            continue;
        }

        if (tokens[index].type == FUNCTION_CLOSE)
        {
            debug("TC4 ", "FUNCTION_CLOSE", tokens[index].str, index, Verbose, depth);
            addASTNode(nodes, nodesCount, &tokens[index], SCOPE_NSEP);
            continue;
        }

        if (tokens[index].type == NEWLINE)
        {

            debug("TC5 ", "NEWLINE", "\\n", index, Verbose, depth);
            addASTNode(nodes, nodesCount, &tokens[index], NEWLINE_SEP);
            continue;
        }

        if (tokens[index].type == STRING)
        {
            debug("TC6 ", "STRING", tokens[index].str, index, Verbose, depth);
            addASTNode(nodes, nodesCount, &tokens[index], LSTRING);
            continue;
        }

        if (tokens[index].type == CHARACTER)
        {
            debug("TC6 ", "CHARACTER", tokens[index].str, index, Verbose, depth);
            addASTNode(nodes, nodesCount, &tokens[index], LCHAR);
            continue;
        }

        debug("TC7 ", "UNRESOLVED", tokens[index].str, index, Verbose, depth);
        addASTNode(nodes, nodesCount, &tokens[index], UNRESOLVED);
    }

    if (Verbose >= 1)
        printf("--- PARSER1 END ---\n");
    return 0;
}

// ===========================================================================================
// ===========================================================================================
// ===========================================================================================
// ===========================================================================================
// PARSE 2
// ===========================================================================================
// ===========================================================================================
// ===========================================================================================
// ===========================================================================================

void addAST2Node(AST2 **nodes2, int *nodes2Count, AST1 *nodes, AST2_TYPE type)
{
    *nodes2 = srealloc(*nodes2, nodes2Count, sizeof(AST2));

    if (!(*nodes2))
    {
        printf("Unable to allocate AST2 Node\n");
        return;
    }

    (*nodes2)[*nodes2Count - 1].type = type;
    (*nodes2)[*nodes2Count - 1].node = nodes;
}

int isUnaryOp(char *str)
{
    switch (str[0])
    {
    case '*':
    case '&':
    case '.':
    case ',':
    case '!':
    case '~':
    case '+':
    case '-':
        return 1;
    default:
        return 0;
    }
}

const char *binOps[] = {"+", "-", "*", "/", "%%", "&", "|", "^", "=", "==", "?", ">", "<", ".", "+=", "-=", "*=", "/=", "%%=", "&=", "|=", "^=", ">=", "<=", "+.", "-.", "*.", "/.", "%%.", "?.", ">.", "<.", ">=.", "<=."};
#define binOpsSize 34

int isBinaryOp(char *str)
{
    for (int i = 0; i < binOpsSize; i++)
        if (!strcmp(str, binOps[i]))
            return 1;
    return 0;
}

void debug2(char *str, char *node, int index, int verbosity)
{
    if (verbosity >= 4)
        printf("[ND1:%4u]", index);
    if (verbosity >= 2)
        printf("%s(%s)\n", str, node);
}

int parse2(AST1 **nodes, int *nodesCount, AST2 **nodes2, int *nodes2Count)
{
    if (Verbose >= 1)
        printf("--- PARSER2 START ---\n");

    if (!nodes)
    {
        printf("Error while opening AST1 nodes tree\n");
        return 1;
    }
    int doingStrings = 0;

    for (int i = 0; i < *nodesCount; i++)
    {
        if (nodes[i] == NULL)
            continue; // Error case

        if (nodes[i]->type == UNRESOLVED || nodes[i]->type == LCHAR || nodes[i]->type == LSTRING)
        {
            debug2("ATOM ----> ", nodes[i]->str, i, Verbose);
            addAST2Node(nodes2, nodes2Count, nodes[i], ((nodes[i]->type != UNRESOLVED) ? LATOM : ATOM));
            continue;
        }
        else if (nodes[i]->type == SCOPE_NSEP || nodes[i]->type == NEWLINE_SEP)
        {
            if (Verbose >= 2 && !strcmp(nodes[i]->str, "\n"))
                printf("\n");
            addAST2Node(nodes2, nodes2Count, nodes[i], END_SEP);
            continue;
        }

        // UNARY
        if (i > 0 && (i + 1) < *nodesCount)
        {
            if ((nodes[i - 1]->type == SCOPE_SEP) && (nodes[i]->type == OPERATION) && (nodes[i + 1]->type == UNRESOLVED || nodes[i + 1]->type == SCOPE_SEP))
            {
                if (!isUnaryOp(nodes[i]->str))
                    printf("ERROR: Invalid Unary Operation\n");

                debug2("UNARY ---> ", nodes[i]->str, i, Verbose);
                addAST2Node(nodes2, nodes2Count, nodes[i], UNARY);
                continue;
            }
        }

        // BINARY
        if (i > 0 && (i + 1) < *nodesCount)
        {
            if ((nodes[i - 1]->type == UNRESOLVED || nodes[i - 1]->type == LCHAR || nodes[i - 1]->type == LSTRING || nodes[i - 1]->type == SCOPE_NSEP) && (nodes[i]->type == OPERATION) && (nodes[i + 1]->type == UNRESOLVED || nodes[i + 1]->type == LCHAR || nodes[i + 1]->type == LSTRING || nodes[i + 1]->type == SCOPE_SEP))
            {
                if (!isBinaryOp(nodes[i]->str))
                    printf("ERROR: Invalid Binary Operation\n");

                debug2("BINARY --> ", nodes[i]->str, i, Verbose);
                addAST2Node(nodes2, nodes2Count, nodes[i], BINARY);
                continue;
            }
        }

        if (nodes[i]->type == OPERATION)
        {
            printf("Error: Invalid Operation\n");
        }

        // CAST
        if (i > 0)
        {
            if ((nodes[i - 1]->type == UNRESOLVED || nodes[i - 1]->type == SCOPE_NSEP) && nodes[i]->type == SCOPE_SEP)
            {
                debug2("CAST ----> ", nodes[i]->str, i, Verbose);
                addAST2Node(nodes2, nodes2Count, nodes[i], CAST);
                continue;
            }
        }

        if (nodes[i]->type == SCOPE_SEP)
        {
            addAST2Node(nodes2, nodes2Count, (i > 0 && nodes[i - 1]->type == CALL) ? nodes[i - 1] : nodes[i], BEG_SEP);
            continue;
        }
        else if (nodes[i]->type == ARGUMENT_SEP)
        {
            addAST2Node(nodes2, nodes2Count, nodes[i], ARG_SEP);
            continue;
        }
    }
    if (Verbose >= 1)
        printf("--- PARSER2 END ---\n");
    return 0;
}

/* cheat table for when u remeber this is horribly coded:

    ATOM [a] | a
    CAST a[] | [][]
    UNARY [ OP a | [ OP [
    BINARY ] OP [ | a OP b | a OP [ | ] OP b

*/

// ===========================================================================================
// ===========================================================================================
// ===========================================================================================
// ===========================================================================================
// PARSE 3
// ===========================================================================================
// ===========================================================================================
// ===========================================================================================
// ===========================================================================================

// Primitive Sizes Helpers

const char *primitives[] = {"u8", "u16", "u32", "u64", "i8", "i16", "i32", "i64", "padd8", "padd16", "padd32", "padd64", "ptr", "word", "byte", "void"};
#define primitivesCount 16

int getTypeIndex(char *str)
{
    for (int i = 0; i < primitivesCount; i++)
        if (!strcmp(str, primitives[i]))
            return i;
    return -1;
}

const int primitivesSize[] = {U8, U16, U32, U64, I8, I16, I32, I64, PADD8, PADD16, PADD32, PADD64, PTR, WORD, BYTE, VOID};
#define primitivesSizeCount 16

int getTypeSize(int i)
{
    if (i >= primitivesSizeCount)
        return VOID;
    else
        return primitivesSize[i];
}

// Primitive Operations helpers

const char *operations[] = {"+", "-", "*", "/", "%", "&", "|", "^", "~", "!", "=", "==", "?", ">", "<", ".", ",", "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=", ">=", "<=", "+.", "-.", "*.", "/.", "%.", "?.", ">.", "<.", ">=.", "<=."};
#define operationsCount 37

int getOperationIndex(char *str)
{
    for (int i = 0; i < operationsCount; i++)
        if (!strcmp(str, operations[i]))
            return i;
    return -1;
}
const char *operationsString[] = {
    "add",  // ADD
    "sub",  // SUB
    "mul",  // MUL
    "sdiv", // DIV (signed division in LLVM)
    "srem", // MOD (signed remainder)

    "and", // AND
    "or",  // OR
    "xor", // XOR
    "xor", // NOT (LLVM doesn't have NOT; usually xor with -1 / true mask)
    "sub", // NEG (LLVM: 0 - x)

    "store", // SET (not a pure op; depends on context)
    "icmp",  // CMP
    "",      // THEN (no direct LLVM op; control-flow keyword)

    "icmp sgt", // GREATER_THAN
    "icmp slt", // LESS_THAN
    "",         // SUBTYPE (no direct LLVM IR equivalent)
    "nop",      // NOP (LLVM has no real nop; often omitted)

    "fadd", // SET_ADD (assuming float ops stored result)
    "fsub", // SET_DUB (likely typo for SET_SUB)
    "fmul", // SET_MUL
    "fdiv", // SET_DIV
    "frem", // SET_MOD

    "and", // SET_AND (same bitwise ops)
    "or",  // SET_OR
    "xor", // SET_XOR

    "icmp sge", // GREATER_THAN_OR_EQUAL
    "icmp sle", // LESS_THAN_OR_EQUAL

    "fadd", // FLOAT_ADD
    "fsub", // FLOAT_SUB
    "fmul", // FLOAT_MUL
    "fdiv", // FLOAT_DIV
    "frem", // FLOAT_MOD

    "fcmp",     // FLOAT_CMP
    "fcmp ogt", // FLOAT_GREATER_THAN
    "fcmp oge", // FLOAT_REATER_THAN_OR_EQUAL (typo preserved)
    "fcmp ole"  // FLOAT_LESS_THAN_OR_EQUAL
};
#define operationStringCount 36

char *getOperationString(int index)
{
    if (index < operationsCount)
        return operationsString[index];
    else
        return NULL;
}

// Constants Helpers

int isConstant(char *str)
{
    if (!str)
        return 0;

    int isHex = 0;
    int isDec = 0;
    for (int i = 0; str[i]; i++)
    {
        switch (str[i])
        {
        case 'U':
        case 'I':
        case 'B':
        case 'X':
            if (!str[i + 1])
            {
                if ((isHex && str[i] != 'X') || (isDec && str[i] == 'B'))
                    return 0;
                return i;
            }
            else if (str[i] == 'B')
                isHex = 1;
            else
                return 0;
            break;
        case 'A':
        case 'C':
        case 'D':
        case 'E':
        case 'F':
            isHex = 1;
            break;
        default:
            if ((unsigned int)(str[i] - '0') >= 10)
                return 0;
            else if ((unsigned int)(str[i] - '0') >= 2)
                isDec = 1;
        }
    }
    return 0;
}

unsigned long long getConstant(const char *str)
{
    if (!str)
        return 0;

    int pos = isConstant((char *)str);
    if (!pos)
        return 0; // Not a constant

    int base;
    switch (str[pos])
    {
    case 'U':
    case 'I':
        base = 10;
        break;
    case 'B':
        base = 2;
        break;
    case 'X':
        base = 16;
        break;
    default:
        return 0; // Not a constant
        break;
    }

    return strtol(str, NULL, base);
}

// Identifiers Helpers

void addIdentifier(IDENT **identifiers, int *identifiersCount, int kind, IDENT_TYPE type, char *str)
{
    *identifiers = srealloc(*identifiers, identifiersCount, sizeof(IDENT));

    if (!(*identifiers))
    {
        printf("Unable to allocate Identifier\n");
        return;
    }

    (*identifiers)[*identifiersCount - 1].kind = kind;
    (*identifiers)[*identifiersCount - 1].type = type;
    (*identifiers)[*identifiersCount - 1].str = str;
}

void addVariable(VAR_TYPES **variables, int *variablesCount, int kind, VAR_TYPE type, char *str)
{
    *variables = srealloc(*variables, variablesCount, sizeof(VAR_TYPES));

    if (!(*variables))
    {
        printf("Unable to allocate Variable\n");
        return;
    }

    (*variables)[*variablesCount - 1].kind = kind;
    (*variables)[*variablesCount - 1].type = type;
    (*variables)[*variablesCount - 1].str = str;
}

void addStructure(STR_TYPES **structures, int *structuresCount, NSTD_TYPES *fields, int fieldsCount, char *str)
{
    *structures = srealloc(*structures, structuresCount, sizeof(STR_TYPES));

    if (!(*structures))
    {
        printf("Unable to allocate Variable\n");
        return;
    }

    (*structures)[*structuresCount - 1].fields = fields;
    (*structures)[*structuresCount - 1].fieldsCount = fieldsCount;
    (*structures)[*structuresCount - 1].str = str;
}

void addFields(NSTD_TYPES **fields, int *fieldsCount, STD_TYPES type, unsigned long long offset, char *str)
{
    *fields = srealloc(*fields, fieldsCount, sizeof(NSTD_TYPES));

    if (!(*fields))
    {
        printf("Unable to allocate Variable\n");
        return;
    }

    (*fields)[*fieldsCount - 1].type = type;
    (*fields)[*fieldsCount - 1].offset = offset;
    (*fields)[*fieldsCount - 1].str = str;
}

int getIdentifierIndex(char *str, IDENT *identifiers, int identifiersCount)
{
    if (!identifiers)
        return -1;
    for (int i = 0; i < identifiersCount; i++)
        if (!strcmp(str, identifiers[i].str))
            return i;
    return -1;
}

int getIdentifierKind(IDENT *identifiers, int index)
{
    return identifiers[index].kind;
}

int parse3(AST2 *nodes, int count, FILE *file)
{
    if (Verbose >= 1)
        printf("--- PARSER3 START ---\n");

    if (!nodes)
    {
        printf("Error: Unable to read nodes AST2 Type\n");
    }

    // the control variables for LLVM IR emition:
    int isUnclosedFunction = 0;

    // the control variables for Semantical analizis:
    int lastBlockIndex = 0;
    int doAligment = 0;

    IDENT *identifiers = NULL;
    int identifiersCount = 0;

    for (int i = 0; i < count; i++)
    {
        if (Verbose >= 6)
            printf("%s\n", nodes[i].node->str);

        if (nodes[i].type == BEG_SEP && !strcmp(nodes[i].node->str, "Open"))
        {
            if ((i + 1) < count)
            {
                if (nodes[i + 1].type != ATOM)
                {
                    printf("[%u:%u]: ERROR: Invalid Function Declaration (Missing Label)\n", nodes[i + 1].node->token->y, nodes[i + 1].node->token->x);
                    return 1;
                }
            }
            if (isUnclosedFunction)
            {
                fprintf(file, "\n}\n\n");
                isUnclosedFunction = 0;
            }
            else
                isUnclosedFunction = 1;
            fprintf(file, "\ndefine void @%s(i8* %%aptr, i8* %%rptr, i8* %%fptr) {\nentry:\n\n", nodes[i + 1].node->str);
            i = i + 2;
            lastBlockIndex = i;
        }
        else if (nodes[i].type == BEG_SEP && !strcmp(nodes[i].node->str, "Close"))
        {
            if ((i + 1) < count)
                if (nodes[i + 1].type != END_SEP)
                    printf("[%u:%u]: WARNING: Function Closure Does Not Take Arguments\n", nodes[i + 1].node->token->y, nodes[i + 1].node->token->x);

            fprintf(file, "    ret void\n");
            lastBlockIndex = i;
        }
        else if (nodes[i].type == BEG_SEP && !strcmp(nodes[i].node->str, "CMD"))
        {
            if ((i + 1) < count)
                if (nodes[i + 1].type != LATOM)
                    printf("[%u:%u]: WARNING: Invalid Argument for CMD\n", nodes[i + 1].node->token->y, nodes[i + 1].node->token->x);

            if (isUnclosedFunction)
                fprintf(file, "    ");
            fprintf(file, "%s\n", nodes[i + 1].node->str);
            i = i + 2;
            lastBlockIndex = i;
        }
        else if (nodes[i].type == BEG_SEP && !strcmp(nodes[i].node->str, "Typedef"))
        {
            char *structureStr = NULL;
            if (nodes[i + 1].type == ATOM && nodes[i + 2].type == ARG_SEP)
            {
                structureStr = nodes[i + 1].node->str;
                i += 3;
            }
            else
            {
                printf("[%u:%u]: Error: Struct name space wrong defined\n", nodes[i].node->token->y, nodes[i].node->token->x);
                return 1;
            }
            NSTD_TYPES *fields = NULL;
            int fieldsCount = 0;

            int isSet = 0;
            while (nodes[i].node->token->type != FUNCTION_CLOSE && nodes[i].node->type != NEWLINE_SEP)
            {
                // [ ATOM : ATOM ]
                // 5   0  7  0   6
                if ((i + 5) < count)
                {
                    if (nodes[i].node->type == SCOPE_SEP && nodes[i + 1].type == ATOM && nodes[i + 2].type == ARG_SEP && nodes[i + 3].type == ATOM && nodes[i + 4].node->type == SCOPE_NSEP)
                    {
                        int index = getIdentifierIndex(nodes[i + 3].node->str, identifiers, identifiersCount);
                        int type = getTypeIndex(nodes[i + 3].node->str);
                        if (index != -1)
                        {
                            KIND kind = getIdentifierKind(identifiers, index);
                            switch (kind)
                            {
                            case NSTD_TYPE:
                                type = identifiers[index].type.nstd->type;
                            case VARS_TYPE:
                                if (identifiers[index].type.var->kind == NSTD_TYPE)
                                {
                                    type = identifiers[index].type.var->type.std;
                                    break;
                                }
                            case STR_TYPE:
                                printf("[%u:%u]: Error: Illegal type assignation of structure '%s'\n", nodes[i].node->token->y, nodes[i].node->token->x, nodes[i].node->str);
                                return 1;
                            }
                        }

                        int offset = 0;
                        if (fields)
                        {
                            int size = getTypeSize(type);
                            offset = (doAligment) ? ((fields[fieldsCount - 1].offset + size) + (size - 1)) & ~(size - 1) : (fields[fieldsCount - 1].offset + size);
                        }
                        addFields(&fields, &fieldsCount, type, offset, nodes[i + 1].node->str);
                        i += 5;
                        continue;
                    }
                }

                if ((i + 2) < count)
                {
                    if (nodes[i].type == ATOM && nodes[i + 1].node->token->type == FUNCTION_CLOSE)
                    {
                        int index = getIdentifierIndex(nodes[i].node->str, identifiers, identifiersCount);
                        int type = getTypeIndex(nodes[i].node->str);
                        if (index != -1)
                        {
                            KIND kind = getIdentifierKind(identifiers, index);
                            switch (kind)
                            {
                            case NSTD_TYPE:
                                type = identifiers[index].type.nstd->type;
                            case VARS_TYPE:
                                if (identifiers[index].type.var->kind == NSTD_TYPE)
                                {
                                    type = identifiers[index].type.var->type.std;
                                    break;
                                }
                            case STR_TYPE:
                                printf("[%u:%u]: Error: Illegal type assignation of structure '%s'\n", nodes[i].node->token->y, nodes[i].node->token->x, nodes[i].node->str);
                                return 1;
                            }
                        }
                        int offset = 0;
                        addFields(&fields, &fieldsCount, type, offset, structureStr);
                        i += 1;
                        isSet = 1;

                        printf("Type Defined '%s'\n", structureStr);
                        continue;
                    }
                }
                printf("[%u:%u]: Error: Invalid Struct Construct\n", nodes[i].node->token->y, nodes[i].node->token->x);
                return 1;
            }
            if (!isSet)
            {
                STR_TYPES *structure = NULL;
                int structureCount = 0;

                addStructure(&structure, &structureCount, fields, fieldsCount, structureStr);

                IDENT_TYPE idenType;
                idenType.str = structure;

                addIdentifier(&identifiers, &identifiersCount, STR_TYPE, idenType, structureStr);

                printf("Struct Defined '%s'\n", structureStr);
            }
        }
    }

    if (isUnclosedFunction)
        fprintf(file, "}\n");

    if (Verbose >= 1)
        printf("--- PARSER3 END ---\n");
    return 0;
}