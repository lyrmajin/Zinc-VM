@ar0 = global i64 0
@ar1 = global i64 0
@ar2 = global i64 0
@ar3 = global i64 0

define i64 @main() {
entry:
    ; %t4 = ar0
    %t4 = load i64, i64* @ar0

    ; %t5 = 15
    %t5 = add i64 15, 0

    ; store %t5 into ar0
    store i64 %t5, i64* @ar0

    ; ret
    %ret = load i64, i64* @ar0
    ret i64 %ret
}