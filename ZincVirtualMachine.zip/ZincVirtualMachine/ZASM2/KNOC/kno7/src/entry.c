#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <llvm-c/Core.h>
#include <llvm-c/IRReader.h>
#include <llvm-c/Target.h>
#include <llvm-c/TargetMachine.h>
#include <llvm-c/Analysis.h>

#include "../headers/parse.h"
#include "../headers/tokenize.h"

typedef enum
{
    FL,
    TK,
    P1,
    P2,
    P3,
    P4,
    CG
} STAGE;

STAGE STAGEIN = FL;
STAGE STAGEOUT = CG;

int FileBuffer = 1024;
int StrBuffer = 256;

int Verbose = 0; // verbosity (0:NONE 1:LOW 2:MID 3:HIGH :4ELEVATED 5:EXTREME)

int TokenMaxSize = 0;
char *TokenOutFile = NULL;

static int parse_stage(const char *s, STAGE *out)
{
    if (!strcmp(s, "FL"))
        *out = FL;
    else if (!strcmp(s, "TK"))
        *out = TK;
    else if (!strcmp(s, "P1"))
        *out = P1;
    else if (!strcmp(s, "P2"))
        *out = P2;
    else if (!strcmp(s, "P3"))
        *out = P3;
    else if (!strcmp(s, "P4"))
        *out = P4;
    else if (!strcmp(s, "CG"))
        *out = CG;
    else
        return 0;
    return 1;
}

long long getFileSize(FILE *file)
{
    fseek(file, 0, SEEK_END);
    size_t size = ftell(file);
    fseek(file, 0, SEEK_SET);
    return size;
}

int main(int argc, char **argv)
{
    if (argc < 2)
        return 1;

    char *InputFile = NULL;
    char *OutputFile = NULL;
    char *EntryPoint = NULL;

    for (int i = 1; i < argc; i++)
    {
        char *arg = argv[i];

        if (!strncmp(arg, "--Verbose=", 10))
        {
            Verbose = atoi(arg + 10);
        }
        else if (!strncmp(arg, "-SI=", 4))
        {
            if (!parse_stage(arg + 4, &STAGEIN))
                return 1;
        }
        else if (!strncmp(arg, "-SO=", 4))
        {
            if (!parse_stage(arg + 4, &STAGEOUT))
                return 1;
        }
        else if (!strncmp(arg, "--TokenFileBuffer=", 18))
        {
            FileBuffer = atoi(arg + 18);
        }
        else if (!strncmp(arg, "--TokenMaxSize=", 15))
        {
            TokenMaxSize = atoi(arg + 15); /* unused */
        }
        else if (!strncmp(arg, "--TokenStrSize=", 15))
        {
            StrBuffer = atoi(arg + 15);
        }
        else if (!strncmp(arg, "--TokenOutFile=", 15))
        {
            TokenOutFile = arg + 15;
        }
        else if (!strncmp(arg, "-TKOF=", 6))
        {
            TokenOutFile = arg + 6;
        }
        else if (!strncmp(arg, "-ENTRY=", 7))
        {
            EntryPoint = arg + 7;
        }
        else
        {
            /* last non-flag argument is input file */
            InputFile = arg;
        }
    }

    if (Verbose >= 2)
        printf("Compiling \"%s\"\n", InputFile);

    char cwd[512];
    getcwd(cwd, sizeof(cwd));

    char cmd[512];
    snprintf(cmd, sizeof(cmd), "m4 \"%s/%s\"", cwd, InputFile);

    FILE *ifile = popen(cmd, "r");

    if (!ifile)
    {
        return 1;
    }

    TOKEN *tokens = NULL;
    int tokenCount = 0;

    AST1 *nodes = NULL;
    int nodesCount = 0;

    AST2 *nodes2 = NULL;
    int nodes2Count = 0;

    AST3 *nodes3 = NULL;
    int nodes3Count = 0;

    SYMBOLS *symbolsGlobal = NULL;
    int symbolsGlobalCount = 0;

    KNOIR *knoir = NULL;
    int knoirCount = 0;

    if (tokenize(ifile, 0, &tokens, &tokenCount))
        return 1;

    if (STAGEOUT == TK)
        return 0;

    if (parse1(tokens, &tokenCount, &nodes, &nodesCount))
        return 1;

    if (STAGEOUT == P1)
        return 0;

    if (parse2(nodes, &nodesCount, &nodes2, &nodes2Count))
        return 1;

    if (STAGEOUT == P2)
        return 0;

    if (parse3(nodes2, &nodes2Count, &nodes3, &nodes3Count))
        return 1;

    if (STAGEOUT == P3)
        return 0;

    if (parse4(nodes3, &nodes3Count, &symbolsGlobal, &symbolsGlobalCount, &knoir, &knoirCount))
        return 1;

    //if (STAGEOUT == P4)
        return 0;

    FILE *ofile = NULL;

    if (!OutputFile)
    {
        OutputFile = malloc(sizeof(char) * 6);
        strcpy(OutputFile, "out.kir");
    }

    ofile = fopen(OutputFile, "wb");

    if (!ofile)
    {
        return 1;
    }

    fclose(ofile);

    return 0;
}