#include "../headers/parse.h"
#include "../headers/tokenize.h"

#include <stdarg.h>

extern int Verbose;

void *srealloc(void *nodes, int *count, int size)
{
    (*count)++;
    void *tmp = realloc(nodes, (*count) * size);
    if (!tmp)
    {
        printf("\x1b[1;31mError:\x1b[1;0m Unable to allocate element\n");
        (*count)--;
        return nodes;
    }
    return tmp;
}

void emitCompilerError(int y, int x, char *fmt, ...)
{
    va_list args;
    va_start(args, fmt);

    printf("\x1b[1;0m[%u:%u]: \x1b[1;31mError:\x1b[1;0m ", y, x);
    vprintf(fmt, args);
    printf("\n");

    va_end(args);
}

void emitCompilerWarning(int y, int x, char *fmt, ...)
{
    va_list args;
    va_start(args, fmt);

    printf("\x1b[1;0m[%u:%u]: \x1b[1;35mWarning:\x1b[1;0m ", y, x);
    vprintf(fmt, args);
    printf("\n");

    va_end(args);
}

void emitProgramError(char *fmt, ...)
{
    va_list args;
    va_start(args, fmt);

    printf("\x1b[1;31mError:\x1b[1;0m ");
    vprintf(fmt, args);
    printf("\n");

    va_end(args);
}

// ===========================================================================================
// ===========================================================================================
// ===========================================================================================
// ===========================================================================================
// PARSE 1
// ===========================================================================================
// ===========================================================================================
// ===========================================================================================
// ===========================================================================================

void addAST1Node(AST1 **nodes, int *nodesCount, TOKEN *token, long long payload, int depth, AST1_TYPE type)
{
    *nodes = srealloc(*nodes, nodesCount, sizeof(AST1));

    if ((*nodes) == NULL)
    {
        printf("Error allocating AST Node\n");
        return;
    }

    (*nodes)[*nodesCount - 1].type = type;
    (*nodes)[*nodesCount - 1].depth = depth;
    (*nodes)[*nodesCount - 1].payload = payload;
    (*nodes)[*nodesCount - 1].token = token;
}

// Primitive Sizes Helpers

const char *primitives[] = {"u8", "u16", "u32", "u64", "i8", "i16", "i32", "i64", "padd8", "padd16", "padd32", "padd64", "ptr", "word", "byte", "void"};
#define primitivesCount 16

int getPrimitiveTypeIndex(char *str)
{
    for (int i = 0; i < primitivesCount; i++)
        if (!strcmp(str, primitives[i]))
            return i;
    return -1;
}

int isPrimitiveType(char *str)
{
    return (getPrimitiveTypeIndex(str) != -1);
}

const char *registers[] = {"ar0", "ar1", "ar2", "ar3", "abr"};
#define registersCount 5

int getRegisterIndex(char *str)
{
    for (int i = 0; i < registersCount; i++)
        if (!strcmp(str, registers[i]))
            return i;
    return -1;
}

int isRegister(char *str)
{
    return (getRegisterIndex(str) != -1);
}

// Primitive Operations helpers

const char *operations[] = {"+", "-", "*", "/", "%", "&", "|", "^", "~", "!", "==", ">", "<", ">=", "<=", "?", "=", ".", ",", "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^="};
#define operationsCount 27

int getOperationIndex(char *str)
{
    for (int i = 0; i < operationsCount; i++)
        if (!strcmp(str, operations[i]))
            return i;
    return -1;
}

// Constants Helpers

int isConstant(char *str)
{
    if (!str)
        return 0;

    int isHex = 0;
    int isDec = 0;
    for (int i = 0; str[i]; i++)
    {
        switch (str[i])
        {
        case 'U':
        case 'I':
        case 'B':
        case 'X':
            if (!str[i + 1])
            {
                if ((isHex && str[i] != 'X') || (isDec && str[i] == 'B'))
                    return 0;
                return i;
            }
            else if (str[i] == 'B')
                isHex = 1;
            else
                return 0;
            break;
        case 'A':
        case 'C':
        case 'D':
        case 'E':
        case 'F':
            isHex = 1;
            break;
        default:
            if ((unsigned int)(str[i] - '0') >= 10)
                return 0;
            else if ((unsigned int)(str[i] - '0') >= 2)
                isDec = 1;
        }
    }
    return 0;
}

unsigned long long getConstant(const char *str)
{
    if (!str)
        return 0;

    int pos = isConstant((char *)str);
    if (!pos)
        return 0; // Not a constant

    int base;
    switch (str[pos])
    {
    case 'U':
    case 'I':
        base = 10;
        break;
    case 'B':
        base = 2;
        break;
    case 'X':
        base = 16;
        break;
    default:
        return 0; // Not a constant
        break;
    }

    return strtol(str, NULL, base);
}

// Checks

int isUnaryOp(char *str)
{
    switch (str[0])
    {
    case '*':
    case '&':
    case '.':
    case ',':
    case '!':
    case '~':
    case '+':
    case '-':
        return 1;
    default:
        return 0;
    }
}

const char *binOps[] = {"+", "-", "*", "/", "%", "&", "|", "^", "==", ">", "<", ">=", "<=", "?", "=", ".", "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^="};
#define binOpsSize 24

int isBinaryOp(char *str)
{
    for (int i = 0; i < binOpsSize; i++)
        if (!strcmp(str, binOps[i]))
            return 1;
    return 0;
}

void debug1(char *str, char *node, int index, long long payload, int doPayload, int verbosity)
{
    if (verbosity >= 4)
        printf("[TK:%4u]", index);
    if (verbosity >= 4 && doPayload)
        printf("[PL:%10llu]", payload);
    if (verbosity >= 2)
        printf("%s(%s)\n", str, node);
}

/* cheat table for when u remeber this is horribly coded:

    ATOM [a] | a
    CAST a[] | [][]
    UNARY [ OP a | [ OP [
    BINARY ] OP [ | a OP b | a OP [ | ] OP b

*/

/*
    ERROR: Invalid Syntax
    ERROR: Invalid Operator
    ERROR: Invalid Unary operator
    ERROR: Invalid Binary operator
    ERROR: Invalid Numeric Literal

    WARNING: Numeric Literal Too Large
*/

// ===========================================================================================

int parse1(TOKEN *tokens, int *tokensCount, AST1 **nodes, int *nodesCount)
{
    if (Verbose >= 1)
        printf("--- PARSER1 START ---\n");

    if (!tokens)
    {
        printf("\x1b[1;31mError:\x1b[1;0m Unable to read Tokens\n");
        return 1;
    }

    int depth = 0;

    for (int i = 0; i < *tokensCount; i++)
    {
        int type = LITERAL;
        int payload = 0;
        switch (tokens[i].type)
        {
        case CHARACTER:
        case STRING:
            type = LITERAL;
            debug1("LITERAL -> ", tokens[i].str, i, 0, 0, Verbose);
            break;
        case IDENTIFIER:
            if (isConstant(tokens[i].str))
            {
                int pos = isConstant(tokens[i].str);
                type = LITERAL;
                payload = getConstant(tokens[i].str);

                switch (tokens[i].str[pos])
                {
                case 'U':
                case 'I':
                    if (strlen(tokens[i].str) > 21)
                        printf("\x1b[1;0m[%u:%u]: \x1b[1;35mWarning:\x1b[1;0m Numeric Literal Too Large '%s'\n", tokens[i].y, tokens[i].x, tokens[i].str);
                    break;
                case 'X':
                    if (strlen(tokens[i].str) > 17)
                        printf("\x1b[1;0m[%u:%u]: \x1b[1;35mWarning:\x1b[1;0m Numeric Literal Too Large '%s'\n", tokens[i].y, tokens[i].x, tokens[i].str);
                    break;
                case 'B':
                    if (strlen(tokens[i].str) > 65)
                        printf("\x1b[1;0m[%u:%u]: \x1b[1;35mWarning:\x1b[1;0m Numeric Literal Too Large '%s'\n", tokens[i].y, tokens[i].x, tokens[i].str);
                    break;
                default:
                    printf("\x1b[1;0m[%u:%u]: \x1b[1;31mError:\x1b[1;0m Invalid Numeric Literal '%s'\n", tokens[i].y, tokens[i].x, tokens[i].str);
                    return 1;
                }
                debug1("LITERAL -> ", tokens[i].str, i, payload, 1, Verbose);
            }
            else if (isPrimitiveType(tokens[i].str))
            {
                type = TYPE;
                payload = getPrimitiveTypeIndex(tokens[i].str);
                debug1("TYPE ----> ", tokens[i].str, i, payload, 1, Verbose);
            }
            else if (isRegister(tokens[i].str))
            {
                type = REGISTER;
                payload = getRegisterIndex(tokens[i].str);
                debug1("REGISTER > ", tokens[i].str, i, payload, 1, Verbose);
            }
            else
            {
                type = SYMBOL;
                debug1("SYMBOL --> ", tokens[i].str, i, 0, 0, Verbose);
            }
            break;
        case FUNCTION_OPEN:
            depth++;
            type = FUNCTION_SEP;
            break;
        case ARGUMENT:
            type = ARGUMENT_SEP;
            break;
        case FUNCTION_CLOSE:
            depth--;
            type = FUNCTION_NSEP;
            break;
        case INLINE_OPEN:
            depth++;

            // CAST
            // A [
            // ] [
            if (i > 0)
            {
                if ((tokens[i - 1].type == IDENTIFIER || tokens[i - 1].type == INLINE_CLOSE))
                {
                    debug1("REIT ----> ", tokens[i].str, i, 0, 0, Verbose);
                    type = REINTERPRETATION;
                    break;
                }
            }

            type = INLINE_SEP;
            break;
        case INLINE_CLOSE:
            depth--;
            type = INLINE_NSEP;
            break;
        case BLOCK_OPEN:
            depth++;
            type = BLOCK_SEP;
            break;
        case BLOCK_CLOSE:
            depth--;
            type = BLOCK_NSEP;
            break;
        case OPERATOR:
            if (i > 0 && (i + 1) < *tokensCount)
            {
                // UNARY
                // [ OP [
                // [ OP A
                if ((tokens[i - 1].type == INLINE_OPEN) && (tokens[i + 1].type == IDENTIFIER || tokens[i + 1].type == INLINE_OPEN))
                {
                    if (!isUnaryOp(tokens[i].str))
                    {
                        printf("\x1b[1;0m[%u:%u]: \x1b[1;31mError:\x1b[1;0m Invalid Unary Operation '%s'\n", tokens[i].y, tokens[i].x, tokens[i].str);
                        return 1;
                    }

                    payload = getOperationIndex(tokens[i].str);
                    debug1("UNARY ---> ", tokens[i].str, i, payload, 1, Verbose);
                    type = UNARY;
                    break;
                }

                // BINARY
                // ] OP [
                // ] OP "
                // ] OP '
                // ] OP B
                // " OP [
                // " OP "
                // " OP '
                // " OP B
                // ' OP [
                // ' OP "
                // ' OP '
                // ' OP B
                // A OP [
                // A OP "
                // A OP '
                // A OP B
                if ((tokens[i - 1].type == IDENTIFIER || tokens[i - 1].type == STRING || tokens[i - 1].type == CHARACTER || tokens[i - 1].type == INLINE_CLOSE) && (tokens[i + 1].type == IDENTIFIER || tokens[i + 1].type == STRING || tokens[i + 1].type == CHARACTER || tokens[i + 1].type == INLINE_OPEN))
                {
                    if (!isBinaryOp(tokens[i].str))
                    {
                        printf("\x1b[1;0m[%u:%u]: \x1b[1;31mError:\x1b[1;0m Invalid Binary Operation '%s'\n", tokens[i].y, tokens[i].x, tokens[i].str);
                        return 1;
                    }

                    payload = getOperationIndex(tokens[i].str);
                    debug1("BINARY --> ", tokens[i].str, i, payload, 1, Verbose);
                    type = BINARY;
                    break;
                }
            }

            // INVALID
            printf("\x1b[1;0m[%u:%u]: \x1b[1;31mError:\x1b[1;0m Invalid Operation '%s'\n", tokens[i].y, tokens[i].x, tokens[i].str);
            return 1;
        case NEWLINE:
            printf("\n");
            type = NEWLINE_SEP;
            break;
        default:
            printf("\x1b[1;0m[%u:%u]: \x1b[1;31mError:\x1b[1;0m Invalid Syntax '%s'\n", tokens[i].y, tokens[i].x, tokens[i].str);
            return 1;
        }
        addAST1Node(nodes, nodesCount, &(tokens[i]), payload, depth, type);
    }

    if (Verbose >= 1)
        printf("--- PARSER1 END ---\n");
    return 0;
}

// ===========================================================================================
// ===========================================================================================
// ===========================================================================================
// ===========================================================================================
// PARSE 2
// ===========================================================================================
// ===========================================================================================
// ===========================================================================================
// ===========================================================================================

void addAST2Node(AST2 **nodes, int *nodesCount, AST1 *node, int depth, AST2_TYPE type)
{
    *nodes = srealloc(*nodes, nodesCount, sizeof(AST2));

    if ((*nodes) == NULL)
    {
        printf("Error allocating AST Node\n");
        return;
    }

    (*nodes)[*nodesCount - 1].type = type;
    (*nodes)[*nodesCount - 1].depth = depth;
    (*nodes)[*nodesCount - 1].node = node;
}

// ===========================================================================================

int parse2(AST1 *nodes, int *nodesCount, AST2 **nodes2, int *nodes2Count)
{
    if (Verbose >= 1)
        printf("--- PARSER2 START ---\n");

    if (!nodes)
    {
        printf("Error while opening AST1 nodes tree\n");
        return 1;
    }

    int beg = 0;
    int maxDepth = 0;
    int end = 0;

    for (int i = 0; i < *nodesCount; i++)
    {
        if (nodes[i].type == NEWLINE_SEP || (i + 1 == *nodesCount))
        {
            end = i + 1;
            for (int j = beg; j < end; j++)
            {
                if (nodes[j].depth > maxDepth)
                    maxDepth = nodes[j].depth;
            }

            int begDepth = nodes[beg].depth;

            int doCall = 0;
            int callDepth = 0;
            int didInside = 0;
            int cast = 0;
            int castDepth = 0;

            for (int depth = maxDepth; depth >= begDepth; depth--)
            {
                int type = 0;
                for (int j = beg; j < end; j++)
                {
                    if (nodes[j].depth == depth)
                    {
                        if ((depth < (callDepth - 1)) && doCall)
                        {
                            printf("\x1b[1;0m[%u:%u]: \x1b[1;35mWarning:\x1b[1;0m Call Has No Callee '%s'\n", nodes[j].token->y, nodes[j].token->x, nodes[j].token->str);
                            doCall = 0;
                        }
                        switch (nodes[j].type)
                        {
                        case SYMBOL:
                            if (depth == (callDepth - 1))
                            {
                                callDepth = 0;
                                doCall = 0;
                                if (Verbose >= 4)
                                    printf("CALL(%s)\n", nodes[j].token->str);

                                type = CALL_SEP;
                                break;
                            }
                        case REGISTER:
                        case LITERAL:
                        case TYPE:
                            if (Verbose >= 4)
                                printf("A(%s)\n", nodes[j].token->str);
                            type = ATOM;
                            break;
                        case UNARY:
                            if (Verbose >= 4)
                                printf("UNARY(%s)\n", nodes[j].token->str);
                            type = UNARY_OP;
                            if (nodes[j].payload == MUL && depth <= castDepth && cast)
                            {
                                cast = 0;
                                type = UNARY_OP_C;
                                if (Verbose >= 4)
                                    printf("^-- CAST\n");
                            }
                            break;
                        case BINARY:
                            if (Verbose >= 4)
                                printf("BINARY(%s)\n", nodes[j].token->str);
                            type = BINARY_OP;
                            if (nodes[j].payload == SET && depth <= castDepth && cast)
                            {
                                cast = 0;
                                type = BINARY_OP_C;
                                if (Verbose >= 4)
                                    printf("^-- CAST\n");
                            }
                            break;
                        case FUNCTION_SEP:
                            doCall = 1;
                            callDepth = depth;
                            continue;
                        case ARGUMENT_SEP:
                            if (Verbose >= 4)
                                printf("ARGUMENT\n");
                            type = ARGUMENT_SEP2;
                            break;
                        case REINTERPRETATION:
                            cast = 1;
                            castDepth = depth;
                            if (Verbose >= 4)
                                printf("CAST:\n");
                            type = REINTERPRETATION_OP;
                            break;
                        default:
                            continue;
                        }
                        didInside = 1;
                        addAST2Node(nodes2, nodes2Count, &(nodes[j]), depth, type);
                    }
                }
                if (didInside)
                {
                    addAST2Node(nodes2, nodes2Count, NULL, depth, BLOCK_SEP2);
                    if (Verbose >= 4)
                        printf("---\n");
                    didInside = 0;
                }
            }
            beg = end;

            if (doCall)
            {
                printf("\x1b[1;0m[%u:%u]: \x1b[1;35mWarning:\x1b[1;0m Call Has No Callee\n", nodes[i].token->y, nodes[i].token->x);
                doCall = 0;
            }
            if (Verbose >= 4)
                printf("----------------------------------------NEWLINE\n");
            addAST2Node(nodes2, nodes2Count, &(nodes[i]), nodes[i].depth, NEWLINE_SEP2);
        }
    }

    if (Verbose >= 1)
        printf("--- PARSER2 END ---\n");
    return 0;
}

// ===========================================================================================
// ===========================================================================================
// ===========================================================================================
// ===========================================================================================
// PARSE 3
// ===========================================================================================
// ===========================================================================================
// ===========================================================================================
// ===========================================================================================

const char *knoIrStrOperandsBin[] = {
    "add",
    "sub",
    "mul",
    "div",
    "mod",

    "and",
    "or",
    "xor",
    "not",

    "neg",

    "cmpz",
    "cmpg",
    "cmpl",
    "cmpgz",
    "cmplz",
    "brn",

    "store",
    "offset",

    "nop",

    "storeadd",
    "storesub",
    "storemul",
    "storediv",
    "storemod",

    "storeand",
    "storeor",
    "storexor",
    "storeshl",
    "storeshr"};

const char *knoIrStrOperandsUn[] = {
    "pos",
    "neg",
    "load",
    "div",
    "mod",

    "store",
    "or",
    "xor",
    "not",

    "neg",

    "cmpz",
    "cmpg",
    "cmpl",
    "cmpgz",
    "cmplz",
    "brn",

    "store",
    "sizeof",

    "nop",

    "add",
    "sub",
    "mul",
    "div",
    "mod",

    "and",
    "or",
    "xor",
    "shl",
    "shr"};

#define knoIrStrOperandsCount 28

void addAST3Node(AST3 **nodes, int *nodesCount, AST2 *node, int r, int a, int b, AST3_TYPE type)
{
    *nodes = srealloc(*nodes, nodesCount, sizeof(AST3));

    if ((*nodes) == NULL)
    {
        printf("Error allocating AST Node\n");
        return;
    }

    (*nodes)[*nodesCount - 1].type = type;
    (*nodes)[*nodesCount - 1].tr = r;
    (*nodes)[*nodesCount - 1].ta = a;
    (*nodes)[*nodesCount - 1].tb = b;
    (*nodes)[*nodesCount - 1].node = node;
}

// ===========================================================================================

int parse3(AST2 *nodes2, int *nodes2Count, AST3 **nodes3, int *nodes3Count)
{
    if (Verbose >= 1)
        printf("--- PARSER3 START ---\n");

    if (!nodes2)
    {
        emitProgramError("Unable to read nodes AST2 Type");
        return 1;
    }

    int tempStack[1024] = {0};
    int tempStackPointer = 0;
    int temp = 0;
    int temp2 = 0;
    int used = 0;
    for (int i = 0; i < *nodes2Count; i++)
    {
        if (nodes2[i].type == NEWLINE_SEP2)
        {
            printf("\n");
            addAST3Node(nodes3, nodes3Count, &(nodes2[i]), 0, 0, 0, NEWL_IR);
            continue;
        }

        if (nodes2[i].type == BLOCK_SEP2)
        {
            printf("-\n");
            addAST3Node(nodes3, nodes3Count, &(nodes2[i]), 0, 0, 0, BLOCK_IR);
            continue;
        }

        if (nodes2[i].type == ARGUMENT_SEP2)
        {
            printf("|\n");
            addAST3Node(nodes3, nodes3Count, &(nodes2[i]), 0, 0, 0, ARG_IR);
            continue;
        }

        if (nodes2[i].type == REINTERPRETATION_OP)
        {
            printf("cast{\n");
            tempStack[tempStackPointer++] = temp;
            temp2 = tempStackPointer;
            addAST3Node(nodes3, nodes3Count, &(nodes2[i]), 0, 0, 0, CAST_IR);
            continue;
        }

        if (nodes2[i].type == ATOM && (i > used || i == 0))
        {
            tempStack[tempStackPointer++] = temp++;
            if (nodes2[i].node->type == SYMBOL || nodes2[i].node->type == REGISTER || nodes2[i].node->type == TYPE)
                printf("%%t%u = %s\n", temp, nodes2[i].node->token->str);
            else if (nodes2[i].node->token->type == IDENTIFIER)
                printf("%%t%u = %llXX\n", temp, nodes2[i].node->payload);
            else
            {
                printf("%%s = \"%s\"\n%%t%u = %%s\n", nodes2[i].node->token->str, temp);
                addAST3Node(nodes3, nodes3Count, &(nodes2[i]), 0, 0, 0, STR_IR);
            }
            addAST3Node(nodes3, nodes3Count, &(nodes2[i]), temp, 0, 0, SET_IR);
            continue;
        }

        if (nodes2[i].type == CALL_SEP)
        {
            temp++;
            if (nodes2[i].node->type == SYMBOL || nodes2[i].node->type == REGISTER || nodes2[i].node->type == TYPE)
                printf("%%t%u = %s\n", temp, nodes2[i].node->token->str);
            else if (nodes2[i].node->token->type == IDENTIFIER)
                printf("%%t%u = %llXX\n", temp, nodes2[i].node->payload);
            else
            {
                printf("%%s = \"%s\"\n%%t%u = %%s\n", nodes2[i].node->token->str, temp);
                addAST3Node(nodes3, nodes3Count, &(nodes2[i]), 0, 0, 0, STR_IR);
            }
            addAST3Node(nodes3, nodes3Count, &(nodes2[i]), temp, 0, 0, SET_IR);

            int temporal = temp;
            tempStack[tempStackPointer++] = temp++;

            printf("%%t%u = call %%t%u\n", temp, temporal);
            addAST3Node(nodes3, nodes3Count, &(nodes2[i]), temp, temporal, 0, CALL_IR);
            continue;
        }

        if (nodes2[i].type == UNARY_OP || nodes2[i].type == UNARY_OP_C)
        {
            if (i > 0)
            {
                if (nodes2[i - 1].type == BLOCK_SEP2)
                {
                    if (nodes2[i].type == UNARY_OP_C)
                    {
                        tempStackPointer = temp2;
                        temp = tempStack[tempStackPointer];
                        printf("}\n");
                        addAST3Node(nodes3, nodes3Count, &(nodes2[i]), 0, 0, 0, CAST_IR);
                    }
                    int temporal = tempStack[--tempStackPointer];
                    tempStack[tempStackPointer++] = temp++;

                    printf("%%t%u = %s %%t%u\n", temp, knoIrStrOperandsUn[nodes2[i].node->payload], temporal);
                    used = i;
                    addAST3Node(nodes3, nodes3Count, &(nodes2[i]), temp, temporal, 0, UNARY_IR);
                    continue;
                }
            }
            if ((i + 1) < *nodes2Count)
            {
                if (nodes2[i + 1].type == BLOCK_SEP2)
                {
                    if (nodes2[i].type == UNARY_OP_C)
                    {
                        tempStackPointer = temp2;
                        temp = tempStack[tempStackPointer];
                        printf("}\n");
                        addAST3Node(nodes3, nodes3Count, &(nodes2[i]), 0, 0, 0, CAST_IR);
                    }
                    int temporal = tempStack[--tempStackPointer];
                    tempStack[tempStackPointer++] = temp++;

                    printf("%%t%u = %s %%t%u\n", temp, knoIrStrOperandsUn[nodes2[i].node->payload], temporal);
                    addAST3Node(nodes3, nodes3Count, &(nodes2[i]), temp, temporal, 0, UNARY_IR);
                    used = i;
                }
                else if (nodes2[i + 1].type == ATOM)
                {
                    if (nodes2[i].type == UNARY_OP_C)
                    {
                        tempStackPointer = temp2;
                        temp = tempStack[tempStackPointer];
                        printf("}\n");
                        addAST3Node(nodes3, nodes3Count, &(nodes2[i]), 0, 0, 0, CAST_IR);
                    }

                    temp++;

                    if (nodes2[i + 1].node->type == SYMBOL || nodes2[i + 1].node->type == REGISTER || nodes2[i + 1].node->type == TYPE)
                        printf("%%t%u = %s\n", temp, nodes2[i + 1].node->token->str);
                    else if (nodes2[i + 1].node->token->type == IDENTIFIER)
                        printf("%%t%u = %llXX\n", temp, nodes2[i + 1].node->payload);
                    else if (nodes2[i + 1].node->token->type == CHARACTER || nodes2[i + 1].node->token->type == STRING)
                    {
                        printf("%%s = \"%s\"\n%%t%u = %%s\n", nodes2[i + 1].node->token->str, temp);
                        addAST3Node(nodes3, nodes3Count, &(nodes2[i + 1]), 0, 0, 0, STR_IR);
                    }
                    addAST3Node(nodes3, nodes3Count, &(nodes2[i + 1]), temp, 0, 0, SET_IR);

                    int temporal = temp;
                    tempStack[tempStackPointer++] = temp++;

                    printf("%%t%u = %s %%t%u\n", temp, knoIrStrOperandsUn[nodes2[i].node->payload], temporal);
                    addAST3Node(nodes3, nodes3Count, &(nodes2[i]), temp, temporal, 0, UNARY_IR);
                    used = i + 1;
                }
                else
                {
                    emitCompilerError(nodes2[i + 1].node->token->y, nodes2[i + 1].node->token->x, "Invalid Unary Operator '%s'", nodes2[i + 1].node->token->str);
                    return 1;
                }
            }
            continue;
        }

        if (nodes2[i].type == BINARY_OP || nodes2[i].type == BINARY_OP_C)
        {
            if (i > 0 && (i + 1) < *nodes2Count)
            {
                if (nodes2[i - 1].type == BLOCK_SEP2 && nodes2[i + 1].type == BLOCK_SEP2)
                {
                    if (nodes2[i].type == BINARY_OP_C)
                    {
                        tempStackPointer = temp2;
                        temp = tempStack[tempStackPointer];
                        printf("}\n");
                        addAST3Node(nodes3, nodes3Count, &(nodes2[i]), 0, 0, 0, CAST_IR);
                    }
                    int temporalR = tempStack[--tempStackPointer];
                    int temporalL = tempStack[--tempStackPointer];
                    tempStack[tempStackPointer++] = temp++;

                    printf("%%t%u = %s %%t%u, %%t%u\n", temp, knoIrStrOperandsBin[nodes2[i].node->payload], temporalL, temporalR);
                    addAST3Node(nodes3, nodes3Count, &(nodes2[i]), temp, temporalL, temporalR, BINARY_IR);
                    used = i;
                }
                else
                {
                    if (nodes2[i - 1].type == ATOM || nodes2[i + 1].type == ATOM)
                    {
                        if (nodes2[i - 1].type == BLOCK_SEP2 && nodes2[i + 1].type == ATOM)
                        {
                            if (nodes2[i].type == BINARY_OP_C)
                            {
                                tempStackPointer = temp2;
                                temp = tempStack[tempStackPointer];
                                printf("}\n");
                                addAST3Node(nodes3, nodes3Count, &(nodes2[i]), 0, 0, 0, CAST_IR);
                            }

                            tempStack[tempStackPointer++] = temp++;

                            if (nodes2[i + 1].node->type == SYMBOL || nodes2[i + 1].node->type == REGISTER || nodes2[i + 1].node->type == TYPE)
                                printf("%%t%u = %s\n", temp, nodes2[i + 1].node->token->str);
                            else if (nodes2[i + 1].node->token->type == IDENTIFIER)
                                printf("%%t%u = %llXX\n", temp, nodes2[i + 1].node->payload);
                            else if (nodes2[i + 1].node->token->type == CHARACTER || nodes2[i + 1].node->token->type == STRING)
                            {
                                printf("%%s = \"%s\"\n%%t%u = %%s\n", nodes2[i + 1].node->token->str, temp);
                                addAST3Node(nodes3, nodes3Count, &(nodes2[i + 1]), 0, 0, 0, STR_IR);
                            }
                            addAST3Node(nodes3, nodes3Count, &(nodes2[i + 1]), temp, 0, 0, SET_IR);

                            int temporalL = tempStack[--tempStackPointer];
                            int temporalR = temp;
                            tempStack[tempStackPointer++] = temp++;

                            printf("%%t%u = %s %%t%u, %%t%u\n", temp, knoIrStrOperandsBin[nodes2[i].node->payload], temporalL, temporalR);
                            addAST3Node(nodes3, nodes3Count, &(nodes2[i]), temp, temporalL, temporalR, BINARY_IR);
                            used = i + 1;
                        }
                        else if (nodes2[i - 1].type == ATOM && nodes2[i + 1].type == BLOCK_SEP2)
                        {
                            if (nodes2[i].type == BINARY_OP_C)
                            {
                                tempStackPointer = temp2;
                                temp = tempStack[tempStackPointer];
                                printf("}\n");
                                addAST3Node(nodes3, nodes3Count, &(nodes2[i]), 0, 0, 0, CAST_IR);
                            }
                            int temporalR = tempStack[--tempStackPointer];
                            int temporalL = temp;
                            tempStack[tempStackPointer++] = temp++;

                            printf("%%t%u = %s %%t%u, %%t%u\n", temp, knoIrStrOperandsBin[nodes2[i].node->payload], temporalL, temporalR);
                            addAST3Node(nodes3, nodes3Count, &(nodes2[i]), temp, temporalL, temporalR, BINARY_IR);
                            used = i;
                        }
                        else if (nodes2[i - 1].type == ATOM && nodes2[i + 1].type == ATOM)
                        {
                            if (nodes2[i].type == BINARY_OP_C)
                            {
                                tempStackPointer = temp2;
                                temp = tempStack[tempStackPointer];
                                printf("}\n");
                                addAST3Node(nodes3, nodes3Count, &(nodes2[i]), 0, 0, 0, CAST_IR);
                            }

                            tempStack[tempStackPointer++] = temp++;

                            if (nodes2[i + 1].node->type == SYMBOL || nodes2[i + 1].node->type == REGISTER || nodes2[i + 1].node->type == TYPE)
                                printf("%%t%u = %s\n", temp, nodes2[i + 1].node->token->str);
                            else if (nodes2[i + 1].node->token->type == IDENTIFIER)
                                printf("%%t%u = %llXX\n", temp, nodes2[i + 1].node->payload);
                            else if (nodes2[i + 1].node->token->type == CHARACTER || nodes2[i + 1].node->token->type == STRING)
                            {
                                printf("%%s = \"%s\"\n%%t%u = %%s\n", nodes2[i + 1].node->token->str, temp);
                                addAST3Node(nodes3, nodes3Count, &(nodes2[i + 1]), 0, 0, 0, STR_IR);
                            }
                            addAST3Node(nodes3, nodes3Count, &(nodes2[i + 1]), temp, 0, 0, SET_IR);

                            int temporalL = tempStack[--tempStackPointer];
                            int temporalR = temp;
                            tempStack[tempStackPointer++] = temp++;

                            printf("%%t%u = %s %%t%u, %%t%u\n", temp, knoIrStrOperandsBin[nodes2[i].node->payload], temporalL, temporalR);
                            addAST3Node(nodes3, nodes3Count, &(nodes2[i]), temp, temporalL, temporalR, BINARY_IR);
                            used = i + 1;
                        }
                        else
                        {
                            emitCompilerError(nodes2[i + 1].node->token->y, nodes2[i + 1].node->token->x, "Invalid Binary Operator '%s'", nodes2[i + 1].node->token->str);
                        }
                    }
                    else
                    {
                        emitCompilerError(nodes2[i + 1].node->token->y, nodes2[i + 1].node->token->x, "Invalid Binary Operator");
                        return 1;
                    }
                }
            }
            continue;
        }
    }

    if (Verbose >= 1)
        printf("--- PARSER3 END ---\n");
    return 0;
}

// ===========================================================================================
// ===========================================================================================
// ===========================================================================================
// ===========================================================================================
// PARSE 4
// ===========================================================================================
// ===========================================================================================
// ===========================================================================================
// ===========================================================================================

const int primitivesSize[] = {U8, U16, U32, U64, I8, I16, I32, I64, PADD8, PADD16, PADD32, PADD64, PTR, WORD, BYTE, VOID};
#define primitivesSizeCount 16

int getTypeSize(int i)
{
    if (i >= primitivesSizeCount)
        return VOID;
    else
        return primitivesSize[i];
}

void addSymbol(SYMBOLS **symbols, int *symbolsCount, int size, long long offset, char *name, SYMBOL_TYPE type)
{
    *symbols = srealloc(*symbols, symbolsCount, sizeof(SYMBOLS));

    if ((*symbols) == NULL)
    {
        printf("Error allocating KNO IR Node\n");
        return;
    }

    (*symbols)[*symbolsCount - 1].type = type;
    (*symbols)[*symbolsCount - 1].size = size;
    (*symbols)[*symbolsCount - 1].offset = offset;
    (*symbols)[*symbolsCount - 1].name = name;
}

int getSymbolIndex(SYMBOLS *symbols, int symbolsCount, char *name)
{
    if (!symbols)
        return -1;
    for (int i = 0; i < symbolsCount; i++)
        if (!strcmp(symbols[i].name, name))
            return i;
    return -1;
}

int isDefniedSymbol(SYMBOLS *symbols, int symbolsCount, char *name)
{
    if (getSymbolIndex(symbols, symbolsCount, name) != -1)
        return 1;
    return 0;
}

void addKNOIRNode(KNOIR **nodes, int *nodesCount, KNOIR_TYPE type, CONST_IR constir, int tr, int pr, int ta, int pa, int tb, int pb)
{
    *nodes = srealloc(*nodes, nodesCount, sizeof(KNOIR));

    if ((*nodes) == NULL)
    {
        printf("Error allocating KNO IR Node\n");
        return;
    }

    (*nodes)[*nodesCount - 1].type = type;
    (*nodes)[*nodesCount - 1].constantinopla = constir;
    (*nodes)[*nodesCount - 1].tempR = tr;
    (*nodes)[*nodesCount - 1].pragmaR = pr;
    (*nodes)[*nodesCount - 1].tempA = ta;
    (*nodes)[*nodesCount - 1].pragmaA = pa;
    (*nodes)[*nodesCount - 1].tempB = tb;
    (*nodes)[*nodesCount - 1].pragmaB = pb;
}

// ===========================================================================================

int parse4(AST3 *nodes3, int *nodes3Count, SYMBOLS **globalSymbols, int *globalSymbolsCount, KNOIR **knoir, int *knoirCount)
{
    if (Verbose >= 1)
        printf("--- PARSER4 START ---\n");

    if (!nodes3)
    {
        emitProgramError("Unable to read nodes AST3 Type");
        return 1;
    }

    for (int i = 0; i < *nodes3Count; i++)
    {

        if ((i + 5) < *nodes3Count)
        {
            if (nodes3[i].type == SET_IR && nodes3[i + 1].type == ARG_IR && nodes3[i + 2].type == BLOCK_IR && nodes3[i + 3].type == SET_IR && nodes3[i + 4].type == CALL_IR)
            {
                if (nodes3[i + 3].node->node != NULL)
                    if (!strcmp(nodes3[i + 3].node->node->token->str, "Open"))
                    {
                        if (nodes3[i].node->node != NULL)
                            printf("%s:\n", nodes3[i].node->node->token->str);

                        CONST_IR temp = {STRING_CONST, nodes3[i].node->node->token->str};
                        addKNOIRNode(knoir, knoirCount, FUNDEF, temp, 0, PRAGMA_CONST, 0, 0, 0, 0);
                        i += 5;
                        continue;
                    }
            }
        }
        if ((i + 2) < *nodes3Count)
        {
            if (nodes3[i].type == NEWL_IR)
            {
                if (nodes3[i + 1].type == SET_IR && nodes3[i + 2].type == CALL_IR)
                {
                    if (nodes3[i + 1].node->node != NULL)
                        if (!strcmp(nodes3[i + 1].node->node->token->str, "Close"))
                        {
                            printf("\nret\n");
                            CONST_IR temp = {NULL_CONST, 0};
                            addKNOIRNode(knoir, knoirCount, FUNUDEF, temp, 0, 0, 0, 0, 0, 0);
                            i += 2;
                            continue;
                        }
                }
            }
            else if (nodes3[i].type == BLOCK_IR)
            {
                if (nodes3[i + 1].type == SET_IR && nodes3[i + 2].type == CALL_IR)
                {
                    if (nodes3[i + 1].node->node != NULL)
                        if (!strcmp(nodes3[i + 1].node->node->token->str, "Close"))
                        {
                            printf("\n");
                            for (int index = i; index > 0 && nodes3[index].type != NEWL_IR; index--)
                            {
                                if (nodes3[index].type == ARG_IR || nodes3[index].type == BLOCK_IR && (index - 1) > 0)
                                {
                                    if (nodes3[index - 1].type != ARG_IR && nodes3[index - 1].type != BLOCK_IR)
                                    {
                                        printf("arg: %%t%u\n", nodes3[index - 1].tr);
                                        CONST_IR temp = {NULL_CONST, 0};
                                        addKNOIRNode(knoir, knoirCount, FUNARG, temp, nodes3[index - 1].tr, PRAGMA_TEMPORAL, 0, 0, 0, 0);
                                    }
                                }
                            }
                            printf("ret\n");
                            CONST_IR temp = {NULL_CONST, 0};
                            addKNOIRNode(knoir, knoirCount, FUNUDEF, temp, nodes3[i].tr, 0, 0, 0, 0, 0);
                            i += 2;
                            continue;
                        }
                }
            }
        }
        if (nodes3[i].node->node != NULL)
        {

            if (nodes3[i].type == SET_IR)
            {
                if (nodes3[i].node->node->type == TYPE || nodes3[i].node->node->type == REGISTER)
                {
                    printf("%%t%u = %s\n", nodes3[i].tr, nodes3[i].node->node->token->str);
                    CONST_IR temp = {STRING_CONST, nodes3[i].node->node->token->str};
                    if (nodes3[i].node->node->type == REGISTER)
                        addKNOIRNode(knoir, knoirCount, LOAD_LITERAL, temp, nodes3[i].tr, PRAGMA_REGISTER, 0, 0, 0, 0);
                    else
                        addKNOIRNode(knoir, knoirCount, LOAD_LITERAL, temp, nodes3[i].tr, PRAGMA_LD_ST_SIZE, 0, 0, 0, 0);
                    continue;
                }
                else if (nodes3[i].node->node->type == LITERAL && nodes3[i].node->node->token->type == IDENTIFIER)
                {
                    printf("%%t%u = %llXX\n", nodes3[i].tr, nodes3[i].node->node->payload);
                    CONST_IR temp = {NUMERIC_CONST, nodes3[i].node->node->payload};
                    addKNOIRNode(knoir, knoirCount, LOAD_LITERAL, temp, nodes3[i].tr, PRAGMA_TEMPORAL, 0, 0, 0, 0);
                    continue;
                }
                else
                {
                    if ((i - 1) > 0)
                    {
                        if (nodes3[i - 1].type == STR_IR)
                            continue;
                    }
                    if ((i + 1) < *nodes3Count)
                        if (nodes3[i + 1].ta == nodes3[i].tr)
                            continue;
                    printf("%%t%u = %s\n", nodes3[i].tr, nodes3[i].node->node->token->str);
                    CONST_IR temp = {STRING_CONST, nodes3[i].node->node->token->str};
                    addKNOIRNode(knoir, knoirCount, LOAD_LITERAL, temp, nodes3[i].tr, PRAGMA_TEMPORAL, 0, 0, 0, 0);
                    continue;
                }
            }
        }

        if (nodes3[i].type == STR_IR)
        {
            printf("%%t%u = '%s'\n", nodes3[i + 1].tr, nodes3[i].node->node->token->str);
            CONST_IR temp = {STRING_CONST, nodes3[i].node->node->token->str};
            addKNOIRNode(knoir, knoirCount, LOAD_CONST, temp, nodes3[i + 1].tr, PRAGMA_CONST, 0, 0, 0, 0);
            continue;
        }

        if (nodes3[i].type == UNARY_IR && nodes3[i].node->node != NULL)
        {
            if ((i - 1) > 0 && nodes3[i].node->node->payload == SUBTYPE)
            {
                int index = i - 1;
                for (; index > 0 && nodes3[index].type != NEWL_IR; index--)
                {
                    if (nodes3[index].type == ARG_IR || nodes3[index].type == BLOCK_IR && (index - 1) > 0)
                        if (nodes3[index - 1].type != ARG_IR && nodes3[index - 1].type != BLOCK_IR)
                        {
                            printf("%%t%u = alloc %%t%u\n", nodes3[i].tr, nodes3[index - 1].tr);
                            CONST_IR temp = {NULL_CONST, 0};
                            addKNOIRNode(knoir, knoirCount, ALLOC_OPIR, temp, nodes3[index - 1].tr, PRAGMA_TEMPORAL, 0, 0, 0, 0);
                            break;
                        }
                }
                continue;
            }
            printf("%%t%u = %s %%t%u\n", nodes3[i].tr, knoIrStrOperandsUn[nodes3[i].node->node->payload], nodes3[i].ta);
            CONST_IR temp = {NULL_CONST, 0};
            addKNOIRNode(knoir, knoirCount, UNARY_OPIR, temp, nodes3[i].tr, PRAGMA_TEMPORAL, nodes3[i].ta, PRAGMA_TEMPORAL, 0, 0);
        }
        if (nodes3[i].type == BINARY_IR && nodes3[i].node->node != NULL)
        {
            printf("%%t%u = %s %%t%u, %%t%u\n", nodes3[i].tr, knoIrStrOperandsBin[nodes3[i].node->node->payload], nodes3[i].ta, nodes3[i].tb);
            CONST_IR temp = {NULL_CONST, 0};
            addKNOIRNode(knoir, knoirCount, BINARY_OPIR, temp, nodes3[i].tr, PRAGMA_TEMPORAL, nodes3[i].ta, PRAGMA_TEMPORAL, nodes3[i].tb, PRAGMA_TEMPORAL);
        }

        if (nodes3[i].type == CALL_IR && nodes3[i].node->node != NULL)
        {
            if ((i - 2) > 0)
            {
                if (nodes3[i - 2].type == BLOCK_IR)
                {
                    for (int index = i - 2; index > 0 && nodes3[index].type != NEWL_IR; index--)
                    {
                        if (nodes3[index].type == ARG_IR || nodes3[index].type == BLOCK_IR && (index - 1) > 0)
                        {
                            if (nodes3[index - 1].type != ARG_IR && nodes3[index - 1].type != BLOCK_IR)
                            {
                                printf("arg: %%t%u\n", nodes3[index - 1].tr);
                                CONST_IR temp = {NULL_CONST, 0};
                                addKNOIRNode(knoir, knoirCount, FUNARG, temp, nodes3[index - 1].tr, PRAGMA_TEMPORAL, 0, 0, 0, 0);
                            }
                        }
                    }
                }
            }
            if (nodes3[i].ta == nodes3[i - 1].tr)
            {

                printf("%%t%u = call %s\n\n", nodes3[i].tr, nodes3[i - 1].node->node->token->str);
                CONST_IR temp = {STRING_CONST, nodes3[i - 1].node->node->token->str};
                addKNOIRNode(knoir, knoirCount, FUNCALL, temp, nodes3[i].tr, PRAGMA_TEMPORAL, nodes3[i].ta, PRAGMA_CONST, 0, 0);
            }
            else
            {

                printf("%%t%u = call %%t%u\n\n", nodes3[i].tr, nodes3[i].ta);
                CONST_IR temp = {NULL_CONST, 0};
                addKNOIRNode(knoir, knoirCount, FUNCALL, temp, nodes3[i].tr, PRAGMA_TEMPORAL, nodes3[i].ta, PRAGMA_CONST, 0, 0);
            }
        }
    }

    if (Verbose >= 1)
        printf("--- PARSER4 END ---\n");

    codegen(*knoir, knoirCount);

    return 0;
}

int codegen(KNOIR *opir, int *opirCount)
{
    if (Verbose >= 1)
        printf("--- CODEGEN START ---\n");

    if (!opir)
    {
        emitProgramError("Unable to read nodes AST3 Type");
        return 1;
    }

    fprintf(stdout, "@r0 = global i64 0\n@r1 = global i64 0\n@r2 = global i64 0\n@r3 = global i64 0\n@r4 = global i64 0\n@r5 = global i64 0\n@r6 = global i64 0\n@r7 = global i64 0\n@r8 = global i64 0\n@r9 = global i64 0\n@r10 = global i64 0\n@r11 = global i64 0\n@r12 = global i64 0\n@r13 = global i64 0\n@r14 = global i64 0\n@r15 = global i64 0\n\n");

    int fundepth = 0;
    int argspace = 0;
    int gstr = 0;
    char *sstr[128] = {NULL};

    for (int i = 0; i < *opirCount; i++)
    {
        if (Verbose >= 5)
        {
            printf("[IR:%4u][T:%2u][TR:%4u|PR:%4u][TA:%4u|PA:%4u][TB:%4u|PB:%4u]", i, opir[i].type, opir[i].tempR, opir[i].pragmaR, opir[i].tempA, opir[i].pragmaA, opir[i].tempB, opir[i].pragmaB);
            switch (opir[i].constantinopla.type)
            {
            case NUMERIC_CONST:
                printf("[CN:%u]\n", opir[i].constantinopla.constant.numeric);
                break;
            case STRING_CONST:
                printf("[CN:%s]\n", opir[i].constantinopla.constant.string);
                break;
            default:
                printf("\n");
                break;
            }
        }

        if (opir[i].type == FUNARG)
        {
            fprintf(stdout, "store i64 %%t%u, i64* @r%u\n", opir[i].tempR, argspace);
            fprintf(stdout, "%%r%u = load i64, i64* @r%u\n", argspace, argspace++);
        }

        if (opir[i].type == FUNCALL)
        {
            fprintf(stdout, "\n%%t%u = call void @%s(", opir[i].tempR, opir[i].constantinopla.constant.string);
            for (int l = 0; l < argspace; l++)
            {
                if (l)
                    fprintf(stdout, ", ");
                fprintf(stdout, "i64 %%r%u", l);
            }
            fprintf(stdout, ")\n\n");
            argspace = 0;
        }

        if (opir[i].type == FUNDEF)
        {
            if (fundepth)
            {
                fprintf(stdout, "}\n\n");
                fundepth--;
            }
            fprintf(stdout, "define void @%s() {\nentry:\n", opir[i].constantinopla.constant.string);
            fundepth++;
        }
        if (opir[i].type == FUNUDEF)
        {
            fprintf(stdout, "ret void\n", opir[i].constantinopla.constant.string);
        }

        if (opir[i].type == LOAD_CONST)
        {
            if (opir[i].constantinopla.type == STRING_CONST)
            {
                int strlenght = strlen(opir[i].constantinopla.constant.string);
                fprintf(stdout, "%%t%u = getelementptr [%u x i8], [%u x i8]* @.str%u, i64 0, i64 0\n", opir[i].tempR, strlenght, strlenght, gstr);
                sstr[gstr++] = opir[i].constantinopla.constant.string;
            }
        }
    }

    if (fundepth)
    {
        fprintf(stdout, "}\n\n");
        fundepth--;
    }

    for(int i = 0; i < gstr; i++){
        fprintf(stdout, "@.str%u = private constant [%u x i8] c\"%s\"\n", i, strlen(sstr[i]), sstr[i]);
    }

    if (Verbose >= 1)
        printf("--- CODEGEN END ---\n");
    return 0;
}

/*

Usefull garbage

if ((i + 5) < *nodes3Count)
        {
            if (nodes3[i].type == SET_IR && nodes3[i + 1].type == UNARY_IR && nodes3[i + 2].type == BLOCK_IR && nodes3[i + 3].type == SET_IR && nodes3[i + 4].type == BINARY_IR)
            {
                if (nodes3[i].node->node == NULL || nodes3[i + 1].node->node == NULL || nodes3[i + 4].node->node == NULL)
                    continue;
                if (nodes3[i].node->node->type == TYPE && nodes3[i + 1].node->node->payload == SUBTYPE && nodes3[i + 4].node->node->payload == SET)
                {
                    if (nodes3[i + 4].ta == nodes3[i + 3].tr && nodes3[i + 4].tb == nodes3[i + 1].tr)
                    {
                        if (!isDefniedSymbol(symbols, symbolsCount, nodes3[i + 3].node->node->token->str) && symbols)
                        {
                            printf("alloc .0x%llX at 0x%llX\n", nodes3[i].node->node->payload, symbols[symbolsCount-1].offset + symbols[symbolsCount-1].size);
                            printf("%%t%u = %s\n", nodes3[i+3].tr, nodes3[i+3].node->node->token->str);
                            printf("%%t%u = (fp + %llXX)\n", nodes3[i+4].tr, symbols[symbolsCount-1].offset + symbols[symbolsCount-1].size);
                            i += 5;
                            continue;
                        }

                        int varSize = getTypeSize(nodes3[i].node->node->payload);
                        int varOffset = 0;

                        for (int m = symbolsCount - 1; m >= 0 && symbols; m--)
                        {
                            if (symbols[m].type == SYMBOL_OFF_T)
                            {
                                varOffset = symbols[m].offset + symbols[m].size;
                                break;
                            }
                        }

                        addSymbol(&symbols, &symbolsCount, varSize, ((varOffset + (varSize - 1)) & ~(varSize - 1)), nodes3[i + 3].node->node->token->str, SYMBOL_OFF_T);
                        printf("alloc %s as .%s at 0x%X\n", nodes3[i + 3].node->node->token->str, nodes3[i].node->node->token->str, ((varOffset + (varSize - 1)) & ~(varSize - 1)));
                        i += 5;
                        continue;
                    }
                }
            }
        }

*/