#ifndef PARSER_H
#define PARSER_H

#include "tokenize.h"

/* Primitive Identifiers
    Types:
        u8 FIXED WIDTH UNSIGNED
        u16
        u32
        u64

        i8 FIXED WIDTH SIGNED
        i16
        i32
        i64

        padd8 DINAMIC PADD TO SIZE
        padd16
        padd32
        padd64

        byte CPU BYTE SIZE
        word CPU WORD SIZE
        ptr CPU POINTER SIZE

    Cosntants:
        nU UNSIGNED INTEGER
        nI SIGNED INTEGER
        nX HEXADECIMAL
        nB BINARY

        'C' ASCII CHARACTER
        "str\00" ASCII STRING

    Operations CORE:
        Open
        Close
        Import
        Export
        CMD
        ASM
        Typedef
        Namedef

    Operations Logic:
        + ADD
        - SUB
        * MUL | DEFERENCE
        / DIV
        % MOD
        & AND | REFERENCE
        | OR
        ^ XOR
        ~ NOT
        ! NEG
        == CMP
        > GREATER THAN
        < LESS THAN
        >= GREATER THAN or EQUAL
        <= LESS THAN or EQUAL
        ? THEN
        = SET
        . SUBTYPE
        , NOP
        += SET ADD
        -= SET DUB
        *= SET MUL
        /= SET DIV
        %= SET MOD
        &= SET AND
        |= SET OR
        ^= SET XOR

    KNO IR ISA:
        add
        sub
        mul
        div
        mod

        and
        or
        xor
        not

        neg

        cmp
        brn
        brnz
        brng
        brnl
        brngz
        brnlz

        store
        load

        nop
*/

typedef enum
{
    U8 = 1,
    I8 = 1,

    U16 = 2,
    I16 = 2,

    U32 = 4,
    I32 = 4,

    U64 = 8,
    I64 = 8,

    PADD8 = 1,
    PADD16 = 2,
    PADD32 = 4,
    PADD64 = 8,

    VOID = 0,

#if defined(__i386__)
    BYTE = 1,
    WORD = 4,
    PTR = 4

#elif defined(__x86_64__) || defined(__amd64__)
    BYTE = 1,
    WORD = 8,
    PTR = 8

#elif defined(__arm__) && !defined(__aarch64__)
    BYTE = 1,
    WORD = 4,
    PTR = 4

#elif defined(__aarch64__)
    BYTE = 1,
    WORD = 8,
    PTR = 8

#elif defined(__riscv) && __riscv_xlen == 32
    BYTE = 1,
    WORD = 4,
    PTR = 4

#elif defined(__riscv) && __riscv_xlen == 64
    BYTE = 1,
    WORD = 8,
    PTR = 8

#elif defined(__powerpc64__)
    BYTE = 1,
    WORD = 8,
    PTR = 8

#elif defined(__powerpc__)
    BYTE = 1,
    WORD = 4,
    PTR = 4

#elif defined(__mips__) && _MIPS_SIM == _ABI64
    BYTE = 1,
    WORD = 8,
    PTR = 8

#elif defined(__mips__)
    BYTE = 1,
    WORD = 4,
    PTR = 4

#else
#error "Unsupported architecture"
#endif

} STD_TYPE_SIZE;

typedef enum
{
    U8T,
    U16T,
    U32T,
    U64T,
    I8T,
    I16T,
    I32T,
    I64T,
    PADD8T,
    PADD16T,
    PADD32T,
    PADD64T,
    PTRT,
    WORDT,
    BYTET,
    VOIDT
} STD_TYPES;

// -----

typedef enum
{
    ADD,
    SUB,
    MUL,
    DIV,
    MOD,

    AND,
    OR,
    XOR,
    NOT,

    NEG,

    EQUAL,
    GREATER_THAN,
    LESS_THAN,
    GREATER_THAN_OR_EQUAL,
    LESS_THAN_OR_EQUAL,

    THEN,
    SET,
    SUBTYPE,
    NOP,
    SET_ADD,
    SET_DUB,
    SET_MUL,
    SET_DIV,
    SET_MOD,
    SET_AND,
    SET_OR,
    SET_XOR
} STD_OPERATION;

// ----------

typedef enum
{
    LITERAL,
    REGISTER,
    SYMBOL,
    TYPE,

    UNARY,
    BINARY,

    REINTERPRETATION,

    FUNCTION_SEP,
    ARGUMENT_SEP,
    FUNCTION_NSEP,
    INLINE_SEP,
    INLINE_NSEP,
    BLOCK_SEP,
    BLOCK_NSEP,
    NEWLINE_SEP

} AST1_TYPE;

typedef struct
{
    AST1_TYPE type;
    int depth;
    long long payload;
    TOKEN *token;
} AST1;

typedef enum
{
    ATOM,

    UNARY_OP,
    BINARY_OP,

    REINTERPRETATION_OP,
    UNARY_OP_C,
    BINARY_OP_C,

    CALL_SEP,
    ARGUMENT_SEP2,
    BLOCK_SEP2,
    NEWLINE_SEP2

} AST2_TYPE;

typedef struct
{
    AST2_TYPE type;
    int depth;
    AST1 *node;
} AST2;

typedef enum
{
    STR_IR,
    SET_IR,
    UNARY_IR,
    BINARY_IR,
    CAST_IR,
    ARG_IR,
    CALL_IR,
    BLOCK_IR,
    NEWL_IR  
} AST3_TYPE;

typedef struct
{
    AST3_TYPE type;
    int tr;
    int ta;
    int tb;
    AST2 *node;
} AST3;

typedef enum
{
    SYMBOL_OFF_T,
    SYMBOL_ALLOC_T,
    SYMBOL_TYPE_T,
    SYMBOL_CONST_T,
    SYMBOL_LABEL_T
} SYMBOL_TYPE;

typedef struct
{
    SYMBOL_TYPE type;
    int size;
    long long offset;
    char *name;
} SYMBOLS;

typedef enum {
    NUMERIC_CONST,
    NULL_CONST,
    STRING_CONST
} CONST_TYPE;

typedef struct {
    CONST_TYPE type;
    union {
        long long numeric;
        char *string;
    } constant;
} CONST_IR;

typedef enum {
    PRAGMA_NULL, // General use
    PRAGMA_CONST,
    PRAGMA_TEMPORAL,
    PRAGMA_REGISTER, // ^- tempR use
    PRAGMA_LD_ST_SIZE // Operator pragma
} PRAGMA_OPERATION;

typedef enum
{
    FUNDEF,
    FUNCALL,
    FUNARG,
    FUNUDEF,

    LOAD_CONST,
    LOAD_LITERAL,

    ALLOC_OPIR,

    UNARY_OPIR,
    BINARY_OPIR
} KNOIR_TYPE;

typedef struct
{
    KNOIR_TYPE type;

    int tempR;
    PRAGMA_OPERATION pragmaR;

    CONST_IR constantinopla;

    int tempA;
    PRAGMA_OPERATION pragmaA;

    STD_OPERATION operation;

    int tempB;
    PRAGMA_OPERATION pragmaB;
} KNOIR;

// ----

int parse1(TOKEN *tokens, int *tokensCount, AST1 **nodes, int *nodesCount);
int parse2(AST1 *nodes, int *nodesCount, AST2 **nodes2, int *nodes2Count);
int parse3(AST2 *nodes2, int *nodesCount2, AST3 **nodes3, int *nodes3Count);
int parse4(AST3 *nodes3, int *nodes3Count, SYMBOLS **globalSymbols, int *globalSymbolsCount, KNOIR **knoir, int *knoirCount);

int codegen(KNOIR *opir, int *opirCount);

#endif