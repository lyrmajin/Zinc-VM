#ifndef TOKENIZE_H
#define TOKENIZE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

typedef enum
{
    IDENTIFIER,
    OPERATOR,
    ARGUMENT,
    STRING,
    CHARACTER,
    BREAK,
    NEWLINE,
    COMMENT,
    SPACE,
    FUNCTION_OPEN,
    FUNCTION_CLOSE,
    INLINE_OPEN,
    INLINE_CLOSE,
    BLOCK_OPEN,
    BLOCK_CLOSE
} TOKEN_TYPE;

typedef struct
{
    TOKEN_TYPE type;
    char *str;
    int x, y;
} TOKEN;

int tokenize(FILE *file, int stop, TOKEN **tokens, int *tokenCount);

#endif